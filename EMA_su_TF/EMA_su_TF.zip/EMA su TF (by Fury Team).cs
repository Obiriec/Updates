using cAlgo.API;
using cAlgo.API.Indicators;
using cAlgo.API.Internals;
using cAlgo.Indicators;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using static cAlgo.EMASuTF;

namespace cAlgo
{
    // Enum personalizzato per i colori
    public enum ColoreIndicatore
    {
        AliceBlue,
        AntiqueWhite,
        Aqua,
        Aquamarine,
        Azure,
        Beige,
        Bisque,
        Black,
        Blue,
        BlueViolet,
        Brown,
        BurlyWood,
        CadetBlue,
        Chartreuse,
        Chocolate,
        Coral,
        CornflowerBlue,
        Crimson,
        Cyan,
        DarkBlue,
        DarkCyan,
        DarkGoldenrod,
        DarkGray,
        DarkGreen,
        DarkKhaki,
        DarkMagenta,
        DarkOliveGreen,
        DarkOrange,
        DarkOrchid,
        DarkRed,
        DarkSalmon,
        DarkSeaGreen,
        DarkSlateBlue,
        DarkSlateGray,
        DarkTurquoise,
        DarkViolet,
        DeepPink,
        DeepSkyBlue,
        DimGray,
        DodgerBlue,
        Firebrick,
        ForestGreen,
        Fuchsia,
        Gold,
        Goldenrod,
        Gray,
        Green,
        GreenYellow,
        HotPink,
        IndianRed,
        Indigo,
        LightBlue,
        LightCoral,
        LightGreen,
        LightPink,
        LightSalmon,
        LightSeaGreen,
        LightSkyBlue,
        LightSteelBlue,
        Lime,
        LimeGreen,
        Magenta,
        Maroon,
        MediumBlue,
        MediumPurple,
        MediumSeaGreen,
        MediumSlateBlue,
        MediumTurquoise,
        MidnightBlue,
        Navy,
        Olive,
        Orange,
        OrangeRed,
        Orchid,
        PaleGreen,
        Pink,
        Plum,
        Purple,
        Red,
        RoyalBlue,
        SaddleBrown,
        Salmon,
        SeaGreen,
        Silver,
        SkyBlue,
        SlateBlue,
        SlateGray,
        SpringGreen,
        SteelBlue,
        Tan,
        Teal,
        Tomato,
        Turquoise,
        Violet,
        White,
        Yellow,
        YellowGreen
    }

    [Indicator(IsOverlay = true, TimeZone = TimeZones.UTC, AccessRights = AccessRights.FullAccess)]
    public class EMASuTF : Indicator
    {
        [Parameter("Periodo EMA", DefaultValue = 200)]
        public int EmaPeriod { get; set; }

        [Parameter("TimeFrame", DefaultValue = "h1")]
        public TimeFrame SelectedTimeFrame { get; set; }

        [Parameter("Fonte", DefaultValue = SourcePrice.Close)]
        public SourcePrice Source { get; set; }

        [Output("EMA", LineColor = "Orange", PlotType = PlotType.Line, LineStyle = LineStyle.Lines, Thickness = 2)]
        public IndicatorDataSeries EmaResult { get; set; }

        // Nuovi parametri per l'etichetta informativa
        [Parameter("Mostra Etichetta Info EMA", DefaultValue = true)]
        public bool MostraEtichettaInfo { get; set; }

        [Parameter("Posizione Verticale", DefaultValue = VerticalAlignment.Top)]
        public VerticalAlignment PosizioneVerticale { get; set; }

        [Parameter("Posizione Orizzontale", DefaultValue = HorizontalAlignment.Right)]
        public HorizontalAlignment PosizioneOrizzontale { get; set; }

        [Parameter("Colore Etichetta", DefaultValue = ColoreIndicatore.Orange)]
        public ColoreIndicatore ColoreEtichetta { get; set; }

        [Parameter("Nascondi info licenza dopo (secondi)", Group = "★ Display Settings ★", DefaultValue = 60, MinValue = 0, MaxValue = 600)]
        public int LicenseInfoDisplaySeconds { get; set; }

        private ExponentialMovingAverage ema;
        private Bars timeFrameBars;
        private string etichetaId = "EMA_Info_Label";

        public class License
        {
            public string account_id { get; set; }
            public string expiration_date { get; set; }
            public string product_name { get; set; }
            public string license_key { get; set; }
            public string license_type { get; set; }
            public string integrity_hash { get; set; }
            public int max_verification_attempts { get; set; }
            public bool allow_offline_mode { get; set; }
        }

        public class UpdateInfo
        {
            public string version { get; set; }
            public string build_date { get; set; }
            public string download_url { get; set; }
            public bool required { get; set; }
            public string message { get; set; }
            public string[] changelog { get; set; }
        }

        public enum SourcePrice
        {
            Close,
            Open,
            High,
            Low,
            Median,
            Typical,
            Weighted
        }

        // VARIABILI PER LA GESTIONE DELLA LICENZA
        private bool isLicenseValid = false;
        private DateTime licenseExpirationDate = DateTime.MinValue;
        private const string LICENSE_SERVER_URL = "https://obiriec.github.io/License_Server/EMA_su_TF/";
        private const string LICENSE_HASH_SALT = "FuryTeam2025";
        private DateTime _licenseInfoDisplayTime = DateTime.MinValue;
        private bool _licenseInfoDisplayed = false;
        public DateTime Today_Date;
        private const int LICENSE_MAX_ATTEMPTS = 3;
        private int _failedVerificationAttempts = 0;
        private DateTime _nextVerificationAllowed = DateTime.MinValue;
        private string _licenseType = "Standard";
        private bool _licenseCheckFailed = false;
        private DateTime lastLicenseCheck = DateTime.MinValue;
        private HttpClient httpClient = new HttpClient();

        // CONTROLLO AGGIORNAMENTI
        private bool updateAvailable = false;
        private string updateVersion = "";
        private string updateMessage = "";
        private string[] updateChangelog = null;
        private string updateDownloadUrl = "";
        private bool updateRequired = false;
        private const string UPDATE_SERVER_URL = "https://obiriec.github.io/Updates/EMA_su_TF/";
        private DateTime lastUpdateCheck = DateTime.MinValue;

        private bool VerifyLicense(bool forceOnline = false)
        {
            try
            {
                // Verifica se siamo in lockout
                if (DateTime.Now < _nextVerificationAllowed && _failedVerificationAttempts >= 3)
                {
                    string timeRemaining = (_nextVerificationAllowed - DateTime.Now).ToString(@"dd/MM/yyyy HH:mm:ss");
                    Print($"🔒 Verifica licenza temporaneamente bloccata. Riprova tra: {timeRemaining}");
                    Error($"Troppe verifiche fallite. Riprova tra: {timeRemaining}");
                    return false;
                }

                // Se è già stata verificata e non è scaduta, ritorna true
                if (isLicenseValid && licenseExpirationDate > Server.Time && !forceOnline)
                    return true;

                Print($"🔑 Verifica licenza per Account ID: {Account.UserId}");

                // Contatta direttamente il server
                var url = $"{LICENSE_SERVER_URL}{Account.UserId}.json";
                var response = httpClient.GetAsync(url).Result;

                // Se la connessione fallisce, gestisci l'errore
                if (!response.IsSuccessStatusCode)
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification($"Errore connessione server licenze: Status code {response.StatusCode}");
                    return false;
                }

                // Ottieni i dati della licenza dalla risposta
                string licenseData = response.Content.ReadAsStringAsync().Result;

                License license = null;
                try
                {
                    license = JsonConvert.DeserializeObject<License>(licenseData);
                }
                catch (Exception ex)
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification($"Errore parsing JSON licenza: {ex.Message}");
                    return false;
                }

                if (license == null || string.IsNullOrWhiteSpace(license.account_id) ||
                    string.IsNullOrWhiteSpace(license.product_name) || string.IsNullOrWhiteSpace(license.license_key))
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification("Dati licenza non validi o mancanti");
                    return false;
                }

                // Verifica hash di integrità se presente
                if (!string.IsNullOrEmpty(license.integrity_hash))
                {
                    string expectedHash = ComputeLicenseHash(license);
                    Print($"[License] Hash calcolato: {expectedHash}, Hash file: {license.integrity_hash}");

                    if (license.integrity_hash != expectedHash)
                    {
                        _failedVerificationAttempts++;
                        HandleFailedVerification("Licenza danneggiata o alterata");
                        return false;
                    }
                }

                if (license.account_id != Account.UserId.ToString())
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification("Account ID non corrispondente");
                    return false;
                }

                // Usa TryParseExact con il formato specifico dd/MM/yyyy HH:mm:ss
                DateTime expirationDate;
                if (!DateTime.TryParseExact(license.expiration_date, "dd/MM/yyyy HH:mm:ss",
                                          CultureInfo.InvariantCulture, DateTimeStyles.None,
                                          out expirationDate))
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification($"Formato data scadenza non valido. Formato richiesto: dd/MM/yyyy HH:mm:ss, ricevuto: {license.expiration_date}");
                    return false;
                }

                if (Today_Date > expirationDate)
                {
                    _failedVerificationAttempts++;
                    HandleFailedVerification($"Licenza scaduta il {expirationDate.ToString("dd/MM/yyyy HH:mm:ss")}");
                    return false;
                }

                // Imposta la licenza come valida e resetta i contatori di errore
                licenseExpirationDate = expirationDate;
                isLicenseValid = true;
                _licenseType = license.license_type ?? "Standard";
                _failedVerificationAttempts = 0;
                _licenseCheckFailed = false;

                // Mostra info licenza nell'interfaccia
                string licenseTypeDisplay = string.IsNullOrEmpty(license.license_type) ? "" : $"[{license.license_type}] ";
                Print($"✅ Licenza {licenseTypeDisplay}valida fino al {expirationDate.ToString("dd/MM/yyyy HH:mm:ss")} per {license.product_name}");

                ChartObjects.DrawText("license_info",
                    $"✅ Licenza {licenseTypeDisplay}valida fino al {expirationDate.ToString("dd/MM/yyyy HH:mm:ss")}\n" +
                    $"🛡️ Prodotto: {license.product_name}\n" +
                    $"👤 Account ID: {license.account_id}\n" +
                    $"🔑 Tipo: {license.license_type ?? "Standard"}\n" +
                    $"🔒 Verifica integrità: {(!string.IsNullOrEmpty(license.integrity_hash) ? "Attiva" : "Non disponibile")}\n" +
                    $"📆 Ultimo controllo: {Server.Time.ToString("dd/MM/yyyy HH:mm:ss")}\n" +
                    $"⏱️ Questo messaggio sparirà tra {LicenseInfoDisplaySeconds} secondi",
                    StaticPosition.Center,
                    string.IsNullOrEmpty(license.license_type) || license.license_type.Contains("Trial") ? Colors.Orange : Colors.Lime);

                // Pianifica rimozione
                DateTime scheduledRemoval = DateTime.Now.AddSeconds(LicenseInfoDisplaySeconds);
                _objectRemovalTimes["license_info"] = scheduledRemoval;
                _licenseInfoDisplayed = true;

                return true;
            }
            catch (Exception ex)
            {
                _failedVerificationAttempts++;
                HandleFailedVerification($"Errore verifica licenza: {ex.Message}");
                return false;
            }
        }

        // Dizionario per gestire le rimozioni temporizzate
        private Dictionary<string, DateTime> _objectRemovalTimes = new Dictionary<string, DateTime>();

        // Costanti per l'header
        public const string NAME = "★ EMA su TF (by Fury Team) ★";
        public const string VERSION = "1.0.0";
        public const string BUILD_DATE = "2025-06-05";
        public const string CROSS = "\nWorks on any Forex/CFD symbol";
        public const string TELEGRAM = "https://t.me/Obiriec";

        protected override void Initialize()
        {
            // Imposta la data corrente per verifica licenza
            Today_Date = Server.Time;

            // Configura il timer correttamente
            Timer.Stop();
            Timer.Start(TimeSpan.FromMilliseconds(500));
            Print("✓ Timer configurato: intervallo 500ms per la rimozione automatica degli oggetti");

            // Verifica licenza ONLINE OBBLIGATORIA
            if (!VerifyLicense())
            {
                Print("❌ Esecuzione interrotta: licenza non valida");
                _licenseCheckFailed = true;
            }

            // Se la licenza è valida, prosegui con le normali operazioni di inizializzazione
            if (!_licenseCheckFailed)
            {
                // Verifica aggiornamenti
                CheckForUpdates();

                // Se l'aggiornamento è obbligatorio, blocca l'esecuzione
                if (updateAvailable && updateRequired)
                {
                    Print($"❌ Aggiornamento obbligatorio a v{updateVersion} richiesto. Visita {updateDownloadUrl}");
                    return;
                }

                // Ottieni le barre dal TimeFrame selezionato
                timeFrameBars = MarketData.GetBars(SelectedTimeFrame);

                // Inizializza l'indicatore EMA
                ema = Indicators.ExponentialMovingAverage(GetPrice(timeFrameBars, Source), EmaPeriod);

                // Mostra l'etichetta informativa se richiesto
                if (MostraEtichettaInfo)
                {
                    AggiornaEtichettaInfo();
                }
            }
        }

        public override void Calculate(int index)
        {
            // Non proseguire se la licenza è già fallita o c'è un aggiornamento obbligatorio
            if (_licenseCheckFailed || updateRequired)
                return;

            // Verifica periodica della licenza (ogni 12 ore)
            if ((!isLicenseValid ||
                (licenseExpirationDate != DateTime.MinValue && licenseExpirationDate < Server.Time) ||
                (Server.Time - lastLicenseCheck).TotalHours > 12))
            {
                lastLicenseCheck = Server.Time;

                // Imposta il flag di controllo fallito se la verifica fallisce
                if (!VerifyLicense())
                {
                    _licenseCheckFailed = true;
                    return;
                }

                if (!isLicenseValid)
                {
                    _licenseCheckFailed = true;
                    return;
                }
            }

            // Verifica periodica degli aggiornamenti
            if ((Server.Time - lastUpdateCheck).TotalHours >= 24)
                CheckForUpdates();

            // Trova il valore dell'EMA per il tempo corrente
            DateTime currentTime = Bars.OpenTimes[index];

            // Trova l'indice della barra corrispondente nel timeframe selezionato
            int tfIndex = FindTimeFrameIndex(currentTime);

            if (tfIndex >= 0)
            {
                EmaResult[index] = ema.Result[tfIndex];
            }
            else
            {
                // Se non c'è un valore disponibile, usa l'ultimo calcolato o NaN
                EmaResult[index] = index > 0 ? EmaResult[index - 1] : double.NaN;
            }

            // Aggiorna l'etichetta solo sull'ultima barra
            if (index == Bars.Count - 1 && MostraEtichettaInfo)
            {
                AggiornaEtichettaInfo();
            }
        }

        // Metodo per aggiornare l'etichetta informativa
        private void AggiornaEtichettaInfo()
        {
            // Rimuovi l'etichetta se esiste già
            ChartObjects.RemoveObject(etichetaId);

            // Crea il testo dell'etichetta
            string infoText = $"EMA {EmaPeriod} su TF {SelectedTimeFrame}";

            // Converti l'enum del colore in stringa per utilizzarlo con Chart.DrawStaticText
            string coloreStringa = ColoreEtichetta.ToString();
            Chart.DrawStaticText("EMA_Info", $"\n\n\n{infoText}", VerticalAlignment.Top, HorizontalAlignment.Center, coloreStringa);
        }

        // Trova l'indice corrispondente nel timeframe selezionato
        private int FindTimeFrameIndex(DateTime time)
        {
            // Prima cerca una corrispondenza esatta
            for (int i = 0; i < timeFrameBars.Count; i++)
            {
                if (timeFrameBars.OpenTimes[i] == time)
                    return i;
            }

            // Se non trova una corrispondenza esatta, cerca la candela precedente
            int latestIndex = -1;
            for (int i = 0; i < timeFrameBars.Count; i++)
            {
                if (timeFrameBars.OpenTimes[i] <= time)
                    latestIndex = i;
                else
                    break;
            }

            return latestIndex;
        }

        // Metodo per convertire la stringa TimeFrame in un oggetto TimeFrame
        private TimeFrame GetTimeFrame(string timeFrameStr)
        {
            switch (timeFrameStr)
            {
                case "M1": return TimeFrame.Minute;
                case "M5": return TimeFrame.Minute5;
                case "M15": return TimeFrame.Minute15;
                case "M30": return TimeFrame.Minute30;
                case "H1": return TimeFrame.Hour;
                case "H4": return TimeFrame.Hour4;
                case "D1": return TimeFrame.Daily;
                case "W1": return TimeFrame.Weekly;
                case "MN1": return TimeFrame.Monthly;
                default: return TimeFrame.Hour; // Default a H1
            }
        }

        // Metodo per ottenere la serie di prezzi basata sulla fonte selezionata
        private DataSeries GetPrice(Bars bars, SourcePrice source)
        {
            switch (source)
            {
                case SourcePrice.Open: return bars.OpenPrices;
                case SourcePrice.High: return bars.HighPrices;
                case SourcePrice.Low: return bars.LowPrices;
                case SourcePrice.Median: return bars.MedianPrices;
                case SourcePrice.Typical: return bars.TypicalPrices;
                case SourcePrice.Weighted: return bars.WeightedPrices;
                default: return bars.ClosePrices;
            }
        }


        protected override void OnTimer()
        {
            try
            {
                // Verifica tempo rimasto per rimozione licenza
                if (_objectRemovalTimes.ContainsKey("license_info"))
                {
                    var timeLeft = _objectRemovalTimes["license_info"] - DateTime.Now;
                    if (timeLeft.TotalSeconds <= 0)
                    {
                        // Rimuovi oggetto licenza
                        ChartObjects.RemoveObject("license_info");
                        Chart.RemoveObject("license_info");
                        _licenseInfoDisplayed = false;
                        _objectRemovalTimes.Remove("license_info");
                        Print($"✅ Rimosso messaggio licenza dopo {LicenseInfoDisplaySeconds} secondi");
                    }
                }

                // Verifica e rimuovi gli oggetti scaduti
                CheckAndRemoveExpiredObjects();
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in OnTimer: {ex.Message}");
            }
        }

        private void CheckAndRemoveExpiredObjects()
        {
            if (_objectRemovalTimes.Count == 0)
                return;

            try
            {
                var now = DateTime.Now;
                List<string> objectsToRemove = new List<string>();

                // Identifica gli oggetti scaduti
                foreach (var kvp in _objectRemovalTimes)
                {
                    if (now >= kvp.Value)
                        objectsToRemove.Add(kvp.Key);
                }

                // Rimuovi gli oggetti scaduti
                foreach (var objectId in objectsToRemove)
                {
                    try
                    {
                        ChartObjects.RemoveObject(objectId);
                        Chart.RemoveObject(objectId);
                        _objectRemovalTimes.Remove(objectId);
                    }
                    catch (Exception ex)
                    {
                        Print($"❌ Errore rimozione oggetto {objectId}: {ex.Message}");
                        _objectRemovalTimes.Remove(objectId);
                    }
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore generale in CheckAndRemoveExpiredObjects: {ex.Message}");
            }
        }



        private string ComputeLicenseHash(License license)
        {
            // NON rimuovere il "1" iniziale - usa l'ID completo
            string accountId = license.account_id?.Trim() ?? "";

            // CORREZIONE: Usa la data fissa 31/12/9999 00:00:00 per il calcolo hash
            // indipendentemente dalla data effettiva nella licenza
            string expirationDate = "31/12/9999 00:00:00";

            string productName = license.product_name?.Trim() ?? "";
            string licenseKey = license.license_key?.Trim() ?? "";

            // Formato esatto per generare l'hash
            string input = $"{accountId}|{expirationDate}|{productName}|{licenseKey}|{LICENSE_HASH_SALT}";

            // Log per debug
            Print($"[License Debug] Input string for hash: '{input}'");

            // Usa UTF-8 invece di ASCII per assicurare compatibilità completa
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Converti bytes in stringa esadecimale (minuscolo)
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();
            }
        }

        // Metodo per gestire tentativi di verifica falliti
        private void HandleFailedVerification(string message)
        {
            Print($"❌ {message}");
            isLicenseValid = false;

            // Se abbiamo troppi tentativi falliti consecutivi, impostiamo un lockout
            if (_failedVerificationAttempts >= 3)
            {
                _nextVerificationAllowed = DateTime.Now.AddMinutes(30);
                Print($"🔒 Troppe verifiche fallite. Blocco per 30 minuti fino a: {_nextVerificationAllowed.ToString("dd/MM/yyyy HH:mm:ss")}");
            }

            // Messaggio errore grafico
            Chart.DrawStaticText("license_error",
                $"❌ ERRORE LICENZA\n{message}\nL'indicatore è stato disattivato.\n\n" +
                $"Tentativi rimasti: {Math.Max(0, 3 - _failedVerificationAttempts)}",
                VerticalAlignment.Center, HorizontalAlignment.Center, Color.Red);

            // Imposta il flag di errore licenza
            _licenseCheckFailed = true;
        }

        // Metodo per la gestione degli errori di licenza con visualizzazione
        private void Error(string message = "Licenza non valida. Contatta https://t.me/Obiriec")
        {
            isLicenseValid = false;
            _licenseCheckFailed = true;

            // Messaggio errore console
            Print($"❌ ERRORE LICENZA: {message}");

            // Messaggio errore grafico
            Chart.DrawStaticText("license_error",
                $"❌ ERRORE LICENZA\n{message}\nL'indicatore è stato disattivato.\n\nContatta https://t.me/Obiriec per rinnovarla.",
                VerticalAlignment.Center, HorizontalAlignment.Center, Color.Red);

            // Visualizza messaggio bloccante semi-trasparente
            Chart.DrawStaticText("license_background",
                new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100),
                VerticalAlignment.Center, HorizontalAlignment.Center,
                Color.FromArgb(220, 0, 0, 0));
        }

        private void CheckForUpdates()
        {
            try
            {
                if ((Server.Time - lastUpdateCheck).TotalHours < 24 && lastUpdateCheck != DateTime.MinValue)
                    return;

                lastUpdateCheck = Server.Time;

                // URL richiesta aggiornamenti
                string updateUrl = $"{UPDATE_SERVER_URL}EMA_su_TF_updates.json";
                Print($"🔄 Controllo aggiornamenti: {updateUrl}");

                // Effettua richiesta HTTP
                var response = httpClient.GetAsync(updateUrl).Result;

                // Verifica risposta
                if (!response.IsSuccessStatusCode)
                {
                    Print($"⚠️ Errore server aggiornamenti: Status {response.StatusCode}");
                    return;
                }

                // Deserializza informazioni aggiornamento
                var updateInfo = JsonConvert.DeserializeObject<UpdateInfo>(response.Content.ReadAsStringAsync().Result);

                if (updateInfo == null || string.IsNullOrEmpty(updateInfo.version))
                {
                    Print("Informazioni di aggiornamento non valide");
                    return;
                }

                if (CompareVersions(updateInfo.version, VERSION) > 0)
                {
                    updateAvailable = true;
                    updateVersion = updateInfo.version;
                    updateMessage = updateInfo.message;
                    updateDownloadUrl = updateInfo.download_url;
                    updateRequired = updateInfo.required;

                    if (updateInfo.changelog != null && updateInfo.changelog.Length > 0)
                    {
                        updateChangelog = updateInfo.changelog;
                    }

                    if (updateRequired)
                    {
                        ShowRequiredUpdateMessage();
                    }
                    else
                    {
                        ShowUpdateNotification();
                    }
                }
                else
                {
                    Print($"Nessun aggiornamento disponibile. Versione attuale: {VERSION}");
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore controllo aggiornamenti: {ex.Message}");
            }
        }

        private int CompareVersions(string v1, string v2)
        {
            // Rimuovi eventuali prefissi 'v' o 'V'
            v1 = v1.TrimStart('v', 'V');
            v2 = v2.TrimStart('v', 'V');

            // Suddivide le stringhe di versione in parti numeriche
            string[] parts1 = v1.Split('.');
            string[] parts2 = v2.Split('.');

            // Determina la lunghezza massima tra le due versioni
            int maxLength = Math.Max(parts1.Length, parts2.Length);

            // Confronta ciascuna parte numerica
            for (int i = 0; i < maxLength; i++)
            {
                int num1 = i < parts1.Length ? int.Parse(parts1[i]) : 0;
                int num2 = i < parts2.Length ? int.Parse(parts2[i]) : 0;

                if (num1 != num2)
                    return num1 > num2 ? 1 : -1;
            }

            // Le versioni sono identiche
            return 0;
        }

        private void ShowUpdateNotification()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"🔄 AGGIORNAMENTO DISPONIBILE");
                sb.AppendLine($"{NAME}");
                sb.AppendLine($"━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                sb.AppendLine($"📦 Nuova versione: v{updateVersion}");
                sb.AppendLine($"📅 Data rilascio: {BUILD_DATE}");

                if (!string.IsNullOrEmpty(updateMessage))
                    sb.AppendLine($"💬 {updateMessage}");

                sb.AppendLine($"🌐 Scarica ora: {updateDownloadUrl}");

                if (updateChangelog != null && updateChangelog.Length > 0)
                {
                    sb.AppendLine("");
                    sb.AppendLine("✨ NOVITÀ:");

                    for (int i = 0; i < Math.Min(updateChangelog.Length, 10); i++)
                    {
                        sb.AppendLine($"• {updateChangelog[i]}");
                    }

                    if (updateChangelog.Length > 10)
                        sb.AppendLine("etc ...");
                }

                Chart.DrawStaticText("update_notification",
                    sb.ToString(),
                    VerticalAlignment.Center,
                    HorizontalAlignment.Center,
                    Color.DodgerBlue);
            }
            catch (Exception ex)
            {
                Print($"Errore visualizzazione notifica aggiornamento: {ex.Message}");
            }
        }

        private void ShowRequiredUpdateMessage()
        {
            try
            {
                // Rimuovi eventuali messaggi di errore licenza precedenti
                Chart.RemoveObject("license_error");
                Chart.RemoveObject("license_background");

                // Crea sfondo semi-trasparente
                Chart.DrawStaticText("update_background",
                    new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100),
                    VerticalAlignment.Center, HorizontalAlignment.Center,
                    Color.FromArgb(180, 0, 0, 120)); // Azzurro/blu semi-trasparente

                // Visualizza messaggio di aggiornamento obbligatorio con stile distintivo
                Chart.DrawStaticText("required_update_message",
                    $"🔄 AGGIORNAMENTO OBBLIGATORIO RICHIESTO\n" +
                    $"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                    $"📦 Nuova versione v{updateVersion} disponibile\n" +
                    $"⛔ La versione attuale (v{VERSION}) non è più supportata\n\n" +
                    $"Per continuare ad utilizzare l'indicatore è necessario\n" +
                    $"scaricare e installare l'ultima versione.\n\n" +
                    $"🌐 Scarica ora: {updateDownloadUrl}\n\n" +
                    $"📧 Supporto: {TELEGRAM}",
                    VerticalAlignment.Center, HorizontalAlignment.Center,
                    Color.DodgerBlue);

                Print($"🚨 AGGIORNAMENTO OBBLIGATORIO: è richiesta la versione {updateVersion} - Download link: {updateDownloadUrl}");

                // Flag per indicare che l'indicatore è bloccato per aggiornamento
                updateRequired = true;
            }
            catch (Exception ex)
            {
                Print($"Errore visualizzazione messaggio aggiornamento obbligatorio: {ex.Message}");
            }
        }

        protected override void OnDestroy()
        {
            // Rimuovi l'etichetta quando l'indicatore viene fermato
            if (MostraEtichettaInfo)
            {
                ChartObjects.RemoveObject(etichetaId);
            }

            // Rimuovi i messaggi di errore di licenza
            Chart.RemoveObject("license_error");
            Chart.RemoveObject("license_background");
            Chart.RemoveObject("update_notification");
            Chart.RemoveObject("required_update_message");
            Chart.RemoveObject("update_background");

            // Rimuovi messaggio licenza dal pannello dell'indicatore
            ChartObjects.RemoveObject("license_info");

            // Cleanup timer
            Timer.Stop();

            // Cleanup HttpClient
            if (httpClient != null)
            {
                httpClient.Dispose();
            }
        }




    }
}