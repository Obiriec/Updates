﻿using cAlgo.API;
using cAlgo.Robots;
using System;
using System.Collections.Generic;
using System.Linq;

public class ExtendedRecoveryModule
{
    // Riferimento principale al cBot parent
    private readonly ProfitSentinel _parent;

    // Parametri configurabili
    private const double EXTENDED_RECOVERY_VOLUME_FACTOR = 0.75;   // Fattore di riduzione per i volumi nel recovery esteso
    private const double MARKET_CONDITION_THRESHOLD = 1.5;         // Soglia per valutare condizioni di mercato avverse
    private const double MAX_EXTENDED_POSITIONS = 2;               // Massimo numero di posizioni aggiuntive nel recovery esteso
    private const double MIN_PROFIT_THRESHOLD_PERCENT = 0.2;       // Percentuale minima di recupero per posizioni estese
    private const double MIN_ADDITIONAL_DD_PERCENT = 1.5;          // Percentuale minima di DD addizionale tra recovery estesi

    // Stato interno
    private bool _extendedModeActive = false;
    private int _extendedPositionsOpened = 0;
    private DateTime _lastExtendedRecoveryTime = DateTime.MinValue;
    private double _lastExtendedVolume = 0;
    private double _maxDrawdownRegistered = 0;
    private double _initialEquity = 0;
    private bool _pendingRecoveryExecution = false;
    private DateTime _lastAttemptTime = DateTime.MinValue;

    // Parametri per la modalità emergenza
    private bool _enableEmergencyMode = false;  // Si attiverà automaticamente in condizioni critiche
    private double _criticalDrawdownThreshold = 75.0;  // Attiva modalità emergenza oltre questo drawdown
    private double _emergencyRSILowerBound = 5.0;  // Limite RSI modificato in modalità emergenza
    private double _emergencyRSIUpperBound = 95.0;  // Limite RSI modificato in modalità emergenza
    private bool _enableExtendedTrailingStopLoss = false;  // Sincronizzato con il parent
    private double _extendedTslTriggerEuro = 0.0;         // Sincronizzato con il parent
    private double _extendedTslDistancePercent = 50.0;     // Sincronizzato con il parent
    private Dictionary<string, double> _extendedTslMaxProfit = new Dictionary<string, double>();

    // Aggiungi proprietà pubbliche per accedere alle impostazioni
    public bool EnableExtendedTrailingStopLoss
    {
        get => _enableExtendedTrailingStopLoss;
        set => _enableExtendedTrailingStopLoss = value;
    }

    public double ExtendedTslTriggerEuro
    {
        get => _extendedTslTriggerEuro;
        set => _extendedTslTriggerEuro = Math.Max(0.0, value);
    }

    public double ExtendedTslDistancePercent
    {
        get => _extendedTslDistancePercent;
        set => _extendedTslDistancePercent = Math.Max(0.0, Math.Min(100.0, value));
    }

    // Proprietà di sola lettura
    public bool IsExtendedModeActive => _extendedModeActive;
    public int ExtendedPositionsOpened => _extendedPositionsOpened;
    public DateTime LastExtendedRecoveryTime => _lastExtendedRecoveryTime;
    public double LastExtendedVolume => _lastExtendedVolume;
    public double MaxDrawdownRegistered => _maxDrawdownRegistered;

    // Proprietà per emergenza
    public bool EnableEmergencyMode
    {
        get => _enableEmergencyMode;
        set => _enableEmergencyMode = value;
    }

    public double CriticalDrawdownThreshold
    {
        get => _criticalDrawdownThreshold;
        set => _criticalDrawdownThreshold = Math.Max(10.0, value);
    }

    public double EmergencyRSILowerBound
    {
        get => _emergencyRSILowerBound;
        set => _emergencyRSILowerBound = value;
    }

    public double EmergencyRSIUpperBound
    {
        get => _emergencyRSIUpperBound;
        set => _emergencyRSIUpperBound = value;
    }

    // Costruttore con inizializzazione
    public ExtendedRecoveryModule(ProfitSentinel parent)
    {
        _parent = parent;
        _initialEquity = parent.Account.Equity;

        // Sincronizza con i parametri del parent
        _enableExtendedTrailingStopLoss = parent.EnableRecoveryTrailingStopLoss;
        _extendedTslTriggerEuro = parent.RecoveryTrailingStopLossTriggerEuro;
        _extendedTslDistancePercent = parent.RecoveryTrailingStopLossDistancePercent;
    }

    /// <summary>
    /// Sincronizza le impostazioni di TrailingStopLoss con il parent
    /// </summary>
    public void SyncTrailingStopLossSettings(bool enableTsl, double triggerEuro, double distancePercent)
    {
        _enableExtendedTrailingStopLoss = enableTsl;
        _extendedTslTriggerEuro = triggerEuro;
        _extendedTslDistancePercent = distancePercent;
    }

    /// <summary>
    /// Determina se attivare il recovery esteso basandosi sulle condizioni correnti
    /// </summary>
    public bool ShouldActivateExtendedRecovery(List<Position> positions, double netProfit, double recoveryDD)
    {
        // Verifica innanzitutto se il recovery esteso è abilitato
        if (!_parent.EnableExtendedRecovery)
        {
            if (_parent.EnableDebugLogs)
                _parent.Print("⛔ Recovery esteso disabilitato da configurazione");
            return false;
        }

        // Blocca immediatamente se c'è già un'operazione di recovery in corso
        if (_pendingRecoveryExecution)
        {
            _parent.Print("⛔ Recovery esteso bloccato: operazione già in corso");
            return false;
        }

        // CONDIZIONE FONDAMENTALE #1: Verifica che siano state raggiunte il massimo numero di posizioni di recovery
        if (positions.Count < _parent.MaxRecoveryTrades)
        {
            if (_parent.EnableDebugLogs)
                _parent.Print($"⛔ Recovery esteso bloccato: numero posizioni ({positions.Count}) inferiore al massimo consentito ({_parent.MaxRecoveryTrades})");
            return false;
        }

        // CONDIZIONE FONDAMENTALE #2: Verifica che il drawdown superi la soglia critica
        if (recoveryDD < _criticalDrawdownThreshold)
        {
            if (_parent.EnableDebugLogs)
                _parent.Print($"⛔ Recovery esteso bloccato: drawdown ({recoveryDD:F2}%) inferiore alla soglia critica ({_criticalDrawdownThreshold:F2}%)");
            return false;
        }

        if (netProfit >= 0) return false;        // Non serve se siamo in profitto
        if (_extendedPositionsOpened >= MAX_EXTENDED_POSITIONS)
        {
            _parent.Print($"⛔ Recovery esteso bloccato: raggiunto limite massimo ({_extendedPositionsOpened}/{MAX_EXTENDED_POSITIONS})");
            return false; // Limite raggiunto
        }

        // Verifica controllo aggiuntivo sull'intervallo di tempo minimo (1 sec) per evitare doppie aperture
        if ((DateTime.Now - _lastAttemptTime).TotalSeconds < 1)
        {
            _parent.Print("⛔ Recovery esteso bloccato: tentativo troppo ravvicinato");
            return false;
        }
        _lastAttemptTime = DateTime.Now;

        // Verifica se il drawdown è aumentato sufficientemente dall'ultimo recovery esteso
        if (_extendedPositionsOpened > 0)
        {
            // Se abbiamo già aperto posizioni di recovery esteso, verifichiamo che il DD sia aumentato
            double lastRegisteredDD = _maxDrawdownRegistered;
            if ((recoveryDD - lastRegisteredDD) < MIN_ADDITIONAL_DD_PERCENT)
            {
                _parent.Print($"⛔ Recovery esteso bloccato: DD non aumentato sufficientemente ({recoveryDD:F2}% - {lastRegisteredDD:F2}% < {MIN_ADDITIONAL_DD_PERCENT:F2}%)");
                return false;
            }
        }

        // Attiva modalità emergenza se necessario
        bool isEmergencySituation = recoveryDD > _criticalDrawdownThreshold;
        if (isEmergencySituation && !_enableEmergencyMode)
        {
            _enableEmergencyMode = true;
            _parent.Print($"⚠️ ATTIVATA MODALITÀ EMERGENZA - Drawdown {recoveryDD:F2}% > Soglia {_criticalDrawdownThreshold:F2}%");
        }

        // Memorizza il massimo drawdown per riferimento futuro
        _maxDrawdownRegistered = Math.Max(_maxDrawdownRegistered, recoveryDD);

        // Verifica se siamo in situazione di drawdown profondo (2.0x il trigger standard)
        bool deepDrawdown = recoveryDD > _parent.RecoveryTriggerPercent * 2.0;  // Ridotto da 2.5 a 2.0

        // Verifica il tempo minimo tra recovery estesi (almeno 3 min in emergenza, 5 min normalmente)
        double requiredMinutes = _enableEmergencyMode ? 3 : 5;
        bool timeConstraintMet = (DateTime.Now - _lastExtendedRecoveryTime).TotalMinutes >= requiredMinutes;

        // Rafforziamo il controllo sul vincolo temporale
        if (!timeConstraintMet)
        {
            _parent.Print($"⛔ Recovery esteso bloccato: vincolo temporale non rispettato (ultimo: {_lastExtendedRecoveryTime.ToString("HH:mm:ss")})");
            return false;
        }

        // Verifica condizioni di mercato favorevoli (in emergenza usa criteri meno restrittivi)
        bool marketConditionsFavorable = CheckMarketConditions(isEmergencySituation);

        // Verifica margine di sicurezza adeguato
        bool marginSafe = CheckMarginSafety();

        try
        {
            _parent.Print($"\n==== VALUTAZIONE RECOVERY ESTESO ====");
            _parent.Print($"• Modalità emergenza: {(_enableEmergencyMode ? "✅ ATTIVA" : "⏸️ Inattiva")}");
            _parent.Print($"• Posizioni: {positions.Count}/{_parent.MaxRecoveryTrades} (massimo raggiunto)");
            _parent.Print($"• Drawdown: {recoveryDD:F2}% (soglia critica: {_criticalDrawdownThreshold:F2}%)");
            _parent.Print($"• Drawdown profondo: {deepDrawdown} ({recoveryDD:F2}% vs trigger {_parent.RecoveryTriggerPercent * 2.0:F2}%)");
            _parent.Print($"• Vincolo temporale rispettato: {timeConstraintMet} (ultimo: {(_lastExtendedRecoveryTime == DateTime.MinValue ? "mai" : _lastExtendedRecoveryTime.ToString("HH:mm:ss"))})");
            _parent.Print($"• Condizioni mercato favorevoli: {marketConditionsFavorable}");
            _parent.Print($"• Margine di sicurezza adeguato: {marginSafe}");

            // In situazioni normali richiediamo tutte le condizioni
            // In emergenza attiviamo se c'è drawdown profondo e il vincolo temporale è rispettato
            bool shouldActivate = _enableEmergencyMode ?
                (deepDrawdown && timeConstraintMet && marketConditionsFavorable && marginSafe) : // Modifica: richiediamo sempre il vincolo temporale
                (deepDrawdown && timeConstraintMet && marketConditionsFavorable && marginSafe);

            _parent.Print($"• Risultato finale: {(shouldActivate ? "✅ ATTIVAZIONE RECOVERY ESTESO" : "⛔ RECOVERY ESTESO NON NECESSARIO")}");

            return shouldActivate;
        }
        catch (Exception ex)
        {
            _parent.Print($"❌ ERRORE in ShouldActivateExtendedRecovery: {ex.Message}");
            return false; // In caso di errore, non facciamo nulla
        }
    }

    /// <summary>
    /// Verifica se le condizioni di mercato sono favorevoli per un recovery esteso
    /// </summary>
    private bool CheckMarketConditions(bool isEmergencyMode = false)
    {
        try
        {
            double volatility = CalculateVolatilityFactor();
            // In emergenza accettiamo una volatilità maggiore
            double volatilityThreshold = isEmergencyMode ? MARKET_CONDITION_THRESHOLD * 2.5 : MARKET_CONDITION_THRESHOLD;
            bool isVolatilityAcceptable = volatility < volatilityThreshold;

            try
            {
                // Usa RSI esistente se disponibile
                if (_parent.GetType().GetField("rsiBaseValueLong", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)?.GetValue(_parent) is double rsiValue)
                {
                    // Cerca condizioni di ipervenduto/ipercomprato estreme
                    // In modalità emergenza usiamo limiti molto più estesi
                    double lowerBound = isEmergencyMode ? _emergencyRSILowerBound : 15;
                    double upperBound = isEmergencyMode ? _emergencyRSIUpperBound : 85;

                    bool isExtremeOverbought = rsiValue > upperBound;
                    bool isExtremeOversold = rsiValue < lowerBound;

                    // Evita di aprire in condizioni estreme
                    if (isExtremeOverbought || isExtremeOversold)
                    {
                        _parent.Print($"• RSI in condizione estrema: {rsiValue:F2} (limiti: {lowerBound}-{upperBound})");
                        return false;
                    }
                }
            }
            catch
            {
                // In caso di errore, usa solo la volatilità
            }

            // Verifica spread ragionevole
            bool isSpreadAcceptable = true;
            try
            {
                double spreadPips = (_parent.Symbol.Ask - _parent.Symbol.Bid) / _parent.Symbol.PipSize;
                // In modalità emergenza accettiamo uno spread maggiore
                double spreadLimit = isEmergencyMode ? _parent.SpreadCriticoPips * 3.0 : _parent.SpreadCriticoPips * 1.5;
                isSpreadAcceptable = spreadPips <= spreadLimit;

                if (!isSpreadAcceptable)
                    _parent.Print($"• Spread troppo alto: {spreadPips:F1} pips > {spreadLimit:F1} pips");
            }
            catch
            {
                // Fallback se non è possibile calcolare lo spread
            }

            // In modalità emergenza consideriamo le condizioni favorevoli se almeno uno dei due fattori è accettabile
            return isEmergencyMode ? (isVolatilityAcceptable || isSpreadAcceptable) : (isVolatilityAcceptable && isSpreadAcceptable);
        }
        catch (Exception ex)
        {
            _parent.Print($"❌ ERRORE in CheckMarketConditions: {ex.Message}");
            return isEmergencyMode; // In emergenza, permettiamo comunque l'esecuzione
        }
    }

    /// <summary>
    /// Applica strategie avanzate di recovery esteso
    /// </summary>
    public void ApplyExtendedRecovery(List<Position> positions, double recoveryDD, double recoveryPips)
    {
        // Verifica innanzitutto se il recovery esteso è abilitato
        if (!_parent.EnableExtendedRecovery)
        {
            _parent.Print("⛔ Recovery esteso non eseguito: funzionalità disabilitata");
            return;
        }

        // Controllo anti-duplicazione
        if (_pendingRecoveryExecution)
        {
            _parent.Print("❌ RECOVERY ESTESO ABORTITO: operazione già in corso");
            return;
        }

        // Imposta il flag di operazione pendente
        _pendingRecoveryExecution = true;

        try
        {
            if (positions.Count == 0)
            {
                _parent.Print("❌ RECOVERY ESTESO ABORTITO: nessuna posizione esistente");
                return;
            }

            // Verifica ulteriore sul limite di posizioni
            if (_extendedPositionsOpened >= MAX_EXTENDED_POSITIONS)
            {
                _parent.Print($"❌ RECOVERY ESTESO ABORTITO: raggiunto limite massimo ({_extendedPositionsOpened}/{MAX_EXTENDED_POSITIONS})");
                return;
            }

            _extendedModeActive = true;
            TradeType direction = positions.First().TradeType;

            // Calcola il volume in modo adattivo
            double cumulativeVolume = positions.Sum(p => _parent.Symbol.VolumeInUnitsToQuantity(p.VolumeInUnits));

            _parent.Print("\n==== ESECUZIONE RECOVERY ESTESO ====");
            _parent.Print($"• Posizioni esistenti: {positions.Count}");
            _parent.Print($"• Volume cumulativo: {cumulativeVolume:F2} lots");
            _parent.Print($"• Drawdown: {recoveryDD:F2}%");
            _parent.Print($"• Pips: {recoveryPips:F2}");

            // Calcolo volume adattivo con smorzamento progressivo
            double baseVolume = CalculateExtendedRecoveryVolume(positions, recoveryDD);
            double adjustedVolume = ApplyVolumeSafetyFactors(baseVolume, recoveryDD);
            _lastExtendedVolume = adjustedVolume;

            _parent.Print($"• Volume base calcolato: {baseVolume:F2} lots");
            _parent.Print($"• Volume finale (dopo sicurezza): {adjustedVolume:F2} lots");

            // Verifica margine di sicurezza
            if (!VerifyVolumeConstraints(adjustedVolume))
            {
                _parent.Print("❌ RECOVERY ESTESO ABORTITO: vincoli di volume o margine non rispettati");
                return;
            }

            // Crea una label identificativa per il recovery esteso
            string label = GenerateExtendedRecoveryLabel();
            string comment = $"ExtRecovery#{_extendedPositionsOpened + 1}_DD{recoveryDD:F0}%";

            // Esecuzione dell'ordine
            try
            {
                // Converte il volume in lots a unità
                var volumeInUnits = _parent.Symbol.QuantityToVolumeInUnits(adjustedVolume);

                // Normalizzazione del volume secondo i requisiti del broker
                volumeInUnits = NormalizeVolumeToValidValue(volumeInUnits);

                // Verifica nuovamente che il volume normalizzato sia valido
                double normalizedLots = _parent.Symbol.VolumeInUnitsToQuantity(volumeInUnits);
                if (normalizedLots < 0.01 || !VerifyVolumeConstraints(normalizedLots))
                {
                    _parent.Print($"❌ RECOVERY ESTESO ABORTITO: volume normalizzato non valido ({normalizedLots:F2} lots)");
                    return;
                }

                _parent.Print($"• Esecuzione ordine: {direction}, {volumeInUnits} unità ({normalizedLots:F2} lots), {_parent.Symbol.Name}");
                var result = _parent.ExecuteMarketOrder(direction, _parent.SymbolName, volumeInUnits, label, null, null, comment);

                if (result.IsSuccessful)
                {
                    _extendedPositionsOpened++;
                    _lastExtendedRecoveryTime = DateTime.Now;
                    _parent.Print($"✅ RECOVERY ESTESO #{_extendedPositionsOpened} ESEGUITO: {normalizedLots:F2} lots a {recoveryDD:F2}% di perdita");

                    // Aggiorna il conteggio totale recovery del parent
                    IncrementParentRecoveryCount();

                    // Aggiorna il monitoraggio dinamico
                    UpdateDynamicMonitoring(positions, result.Position);
                }
                else
                {
                    _parent.Print($"❌ Errore esecuzione Recovery Esteso: {result.Error} (Volume originale: {adjustedVolume:F2} lots, normalizzato: {normalizedLots:F2} lots)");
                }
            }
            catch (Exception ex)
            {
                _parent.Print($"❌ EXCEPTION in ApplyExtendedRecovery: {ex.Message}");
            }

            _parent.Print("============= FINE RECOVERY ESTESO =============\n");
        }
        finally
        {
            // Assicuriamoci di resettare il flag in ogni caso
            _pendingRecoveryExecution = false;
        }
    }
    private double NormalizeVolumeToValidValue(double volumeInUnits)
    {
        try
        {
            // Verifica che il volume sia all'interno dei limiti consentiti dal broker
            double minVolume = _parent.Symbol.VolumeInUnitsMin;
            double maxVolume = _parent.Symbol.VolumeInUnitsMax;
            double stepVolume = _parent.Symbol.VolumeInUnitsStep;

            // Normalizza il volume ai limiti minimi e massimi
            if (volumeInUnits < minVolume)
            {
                _parent.Print($"⚠️ Volume troppo basso, normalizzato a {minVolume:F2} unità");
                return minVolume;
            }
            if (volumeInUnits > maxVolume)
            {
                _parent.Print($"⚠️ Volume troppo alto, normalizzato a {maxVolume:F2} unità");
                return maxVolume;
            }

            // Normalizza il volume secondo lo step richiesto dal broker
            if (stepVolume > 0)
            {
                // Calcola quanti step completi ci sono nel volume
                int numSteps = (int)(volumeInUnits / stepVolume);
                // Arrotonda al numero di step più vicino
                double normalizedVolume = numSteps * stepVolume;

                // Se è troppo piccolo, aggiungiamo uno step
                if (normalizedVolume < minVolume)
                    normalizedVolume = minVolume;

                if (Math.Abs(normalizedVolume - volumeInUnits) > 0.0001)
                {
                    _parent.Print($"⚠️ Volume normalizzato secondo step broker: {volumeInUnits:F4} → {normalizedVolume:F4} unità (step: {stepVolume:F4})");
                }
                return normalizedVolume;
            }

            // Restituisce il volume originale se è valido e non ci sono step da considerare
            return volumeInUnits;
        }
        catch (Exception ex)
        {
            _parent.Print($"❌ Errore durante la normalizzazione del volume: {ex.Message}");
            // Fallback più sicuro: restituisci il volume minimo consentito
            try
            {
                return _parent.Symbol.VolumeInUnitsMin;
            }
            catch
            {
                // Ultimo fallback se anche l'accesso al minimo fallisce
                return 0.01 * 100000; // 0.01 lot in unità tipiche
            }
        }
    }

    /// <summary>
    /// Calcola il volume appropriato per la posizione di recovery esteso
    /// </summary>
    private double CalculateExtendedRecoveryVolume(List<Position> positions, double recoveryDD)
    {
        // Calcolo avanzato del volume con riduzione progressiva
        Position lastPosition = positions.OrderByDescending(p => p.EntryTime).First();
        double lastVol = _parent.Symbol.VolumeInUnitsToQuantity(lastPosition.VolumeInUnits);

        // Volume di base con smorzamento progressivo
        double baseVolume = lastVol * Math.Max(0.5, _parent.RecoveryMultiplier * EXTENDED_RECOVERY_VOLUME_FACTOR);

        // Progressione dinamica con smorzamento
        double dampeningFactor = Math.Max(0.1, _parent.ProgressionDampeningFactor);
        double progressionFactor = Math.Max(0.5, 1.0 - (_extendedPositionsOpened * dampeningFactor));
        double calculatedVolume = baseVolume * progressionFactor;

        // Limita il volume in relazione al volume già in gioco 
        double totalExistingVolume = positions.Sum(p => _parent.Symbol.VolumeInUnitsToQuantity(p.VolumeInUnits));
        double maxSafeVolume = totalExistingVolume * 0.75; // Max 75% del volume già impegnato

        // Usa il minore tra i volumi calcolati per maggiore sicurezza
        return Math.Min(calculatedVolume, maxSafeVolume);
    }

    /// <summary>
    /// Applica fattori di sicurezza al volume calcolato
    /// </summary>
    private double ApplyVolumeSafetyFactors(double baseVolume, double recoveryDD)
    {
        // Volatilità del mercato
        double volatilityFactor = 1.0;
        if (_parent.EnableAdaptiveRecovery)
        {
            volatilityFactor = CalculateVolatilityFactor();
            baseVolume *= Math.Max(0.5, 1.0 - (volatilityFactor - 1.0) * 0.2);
        }

        // Sicurezza basata sul free margin
        double freeMarginRatio = _parent.Account.FreeMargin / _parent.Account.Balance;
        double marginSafetyFactor = Math.Min(1.0, freeMarginRatio * 1.5);
        baseVolume *= marginSafetyFactor;

        // Limita al massimo consentito
        return Math.Min(baseVolume, _parent.MaxAllowedLots);
    }

    /// <summary>
    /// Calcola un fattore di volatilità basato sulle condizioni di mercato
    /// </summary>
    private double CalculateVolatilityFactor()
    {
        try
        {
            // Usa il metodo esistente se disponibile nel parent
            var methodInfo = _parent.GetType().GetMethod("CalculateVolatilityIndex",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

            if (methodInfo != null)
            {
                return (double)methodInfo.Invoke(_parent, new object[] { 20 });
            }

            // Implementazione di fallback se il metodo non è disponibile
            return 1.0;
        }
        catch
        {
            return 1.0;
        }
    }

    /// <summary>
    /// Verifica che ci sia margine sufficiente per operare in sicurezza
    /// </summary>
    private bool CheckMarginSafety()
    {
        // Verifica margine minimo come specificato nei parametri
        bool freeMarginOk = _parent.Account.FreeMargin >= _parent.FreeMarginMinimoEuro * 1.5;

        // Verifica margine level
        double marginLevel = _parent.Account.Margin > 0
            ? (_parent.Account.Equity / _parent.Account.Margin) * 100.0
            : 0.0;

        bool marginLevelOk = marginLevel >= _parent.MinMarginLevelPercent * 1.2;

        if (!freeMarginOk)
            _parent.Print($"• Free Margin insufficiente: {_parent.Account.FreeMargin:F2}€ < {_parent.FreeMarginMinimoEuro * 1.5:F2}€");

        if (!marginLevelOk)
            _parent.Print($"• Margin Level insufficiente: {marginLevel:F2}% < {_parent.MinMarginLevelPercent * 1.2:F2}%");

        return freeMarginOk && marginLevelOk;
    }

    /// <summary>
    /// Verifica i vincoli di volume per la sicurezza
    /// </summary>
    private bool VerifyVolumeConstraints(double volume)
    {
        // Verifica volume minimo broker
        double minVol = 0.01; // Default
        try
        {
            minVol = _parent.Symbol.VolumeInUnitsToQuantity(_parent.Symbol.VolumeInUnitsMin);
        }
        catch
        {
            minVol = 0.01; // Default fallback value
        }

        if (volume < minVol)
        {
            _parent.Print($"• Volume troppo basso: {volume:F2} < {minVol:F2}");
            return false;
        }

        // Verifica volume massimo consentito
        if (volume > _parent.MaxAllowedLots)
        {
            _parent.Print($"• Volume supera il massimo consentito: {volume:F2} > {_parent.MaxAllowedLots:F2}");
            return false;
        }

        return true;
    }

    /// <summary>
    /// Genera una label univoca per il recovery esteso
    /// </summary>
    private string GenerateExtendedRecoveryLabel()
    {
        return $"ExtRec_{DateTime.Now:yyMMdd_HHmmss}_{_extendedPositionsOpened + 1}";
    }

    /// <summary>
    /// Aggiorna il monitoraggio dinamico dopo un recovery esteso
    /// </summary>
    private void UpdateDynamicMonitoring(List<Position> existingPositions, Position newPosition)
    {
        // Verifica che ci siano posizioni da monitorare
        if (existingPositions == null || !existingPositions.Any())
        {
            _parent.Print("⚠️ UpdateDynamicMonitoring: Nessuna posizione esistente da monitorare");
            return;
        }

        // Qui si potrebbero implementare logiche per monitorare le posizioni estese
        // e decidere strategie di uscita coordinate

        double avgEntryPrice = CalculateWeightedAverageEntry(existingPositions, newPosition);
        _parent.Print($"• Prezzo medio di entrata: {avgEntryPrice.ToString($"F{_parent.Symbol.Digits}")}");

        double breakEvenTicks = CalculateBreakEvenDistanceInTicks(existingPositions, newPosition);
        _parent.Print($"• Distanza breakeven: {breakEvenTicks:F1} ticks");

        // Qui si potrebbe disegnare una linea horizontale per il nuovo breakeven
        try
        {
            if (_parent.Chart != null)
            {
                string lineId = "ExtendedRecoveryBE_Line";
                _parent.Chart.RemoveObject(lineId);
                _parent.Chart.DrawHorizontalLine(lineId, avgEntryPrice, Color.DarkOrange, 1, LineStyle.DotsRare);

                // Verifica che Bars sia valido prima di usarlo
                if (_parent.Bars != null && _parent.Bars.Count > 0)
                {
                    _parent.Chart.DrawText($"{lineId}_Label", $"BE Ext ({breakEvenTicks:F0}t)", _parent.Bars.LastBar.OpenTime, avgEntryPrice, Color.DarkOrange);
                }
            }
        }
        catch (Exception ex)
        {
            _parent.Print($"⚠️ Errore nel disegno della linea BE: {ex.Message}");
        }
    }

    /// <summary>
    /// Calcola prezzo medio ponderato di entrata per tutte le posizioni
    /// </summary>
    private double CalculateWeightedAverageEntry(List<Position> existingPositions, Position newPosition)
    {
        // Verifica che la lista di posizioni non sia null
        if (existingPositions == null)
            return newPosition != null ? newPosition.EntryPrice : 0;

        var allPositions = new List<Position>(existingPositions);
        if (newPosition != null) allPositions.Add(newPosition);

        // Verifica che ci siano posizioni da analizzare
        if (!allPositions.Any()) return 0;

        double totalVolume = allPositions.Sum(p => p.VolumeInUnits);
        double weightedSum = allPositions.Sum(p => p.EntryPrice * p.VolumeInUnits);

        return totalVolume > 0 ? weightedSum / totalVolume : 0;
    }

    /// <summary>
    /// Calcola la distanza dal breakeven in tick
    /// </summary>
    private double CalculateBreakEvenDistanceInTicks(List<Position> existingPositions, Position newPosition)
    {
        // Gestione parametri nulli
        if (existingPositions == null && newPosition == null) return 0;

        var allPositions = new List<Position>();
        if (existingPositions != null) allPositions.AddRange(existingPositions);
        if (newPosition != null) allPositions.Add(newPosition);

        if (!allPositions.Any()) return 0;

        // Calcola il prezzo medio
        double avgPrice = CalculateWeightedAverageEntry(existingPositions, newPosition);
        if (avgPrice == 0) return 0;

        // Verifica che Symbol sia valido prima di usarlo
        if (_parent.Symbol == null)
        {
            _parent.Print("⚠️ Symbol è nullo in CalculateBreakEvenDistanceInTicks");
            return 0;
        }

        // Verifica che ci sia almeno una posizione prima di accedere a First()
        if (!allPositions.Any())
        {
            _parent.Print("⚠️ Nessuna posizione disponibile per calcolare la direzione del trade");
            return 0;
        }

        // Calcola la distanza dal prezzo corrente
        double currentPrice = allPositions.First().TradeType == TradeType.Buy ?
            _parent.Symbol.Bid : _parent.Symbol.Ask;

        // Verifica che TickSize non sia zero per evitare divisioni per zero
        double tickSize = _parent.Symbol.TickSize;
        if (tickSize <= 0)
        {
            _parent.Print("⚠️ TickSize non valido: " + tickSize);
            tickSize = 0.1;  // Valore di fallback sicuro
        }

        return Math.Abs(avgPrice - currentPrice) / tickSize;
    }

    /// <summary>
    /// Incrementa il contatore di recovery nel parent
    /// </summary>
    private void IncrementParentRecoveryCount()
    {
        try
        {
            var field = _parent.GetType().GetField("recoveryCount",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

            if (field != null && field.FieldType == typeof(int))
            {
                int currentCount = (int)field.GetValue(_parent);
                field.SetValue(_parent, currentCount + 1);
            }
        }
        catch { /* Ignora errori in caso di problemi con la reflection */ }
    }

    /// <summary>
    /// Verifica se deve chiudere tutte le posizioni in caso di recovery esteso positivo
    /// </summary>
    public bool CheckForCoordinatedExit(List<Position> positions, double netProfit)
    {
        // Controlli di sicurezza
        if (positions == null || !positions.Any() || !_extendedModeActive || positions.Count <= 3)
            return false;

        // Verifica che _initialEquity non sia zero per evitare divisione per zero
        if (_initialEquity <= 0)
        {
            _parent.Print("⚠️ Errore: _initialEquity è zero o negativo in CheckForCoordinatedExit");
            _initialEquity = _parent.Account.Equity;  // Aggiorna con il valore corrente
            if (_initialEquity <= 0) return false;     // Se ancora zero, esci
        }

        // Calcolo adattivo della soglia minima basata sul numero di posizioni e drawdown massimo
        double adjustedThreshold = MIN_PROFIT_THRESHOLD_PERCENT *
            (1.0 + (Math.Min(positions.Count, 10) - 3) * 0.05) *
            (1.0 + Math.Min(_maxDrawdownRegistered, 20) * 0.01);

        // Se siamo in profitto minimo, esamina la possibilità di chiusura coordinata
        bool isMinimalProfit = netProfit > 0 && (netProfit / _initialEquity * 100) > adjustedThreshold;

        if (isMinimalProfit)
        {
            try
            {
                _parent.Print($"\n==== VALUTAZIONE CHIUSURA COORDINATA (RECOVERY ESTESO) ====");
                _parent.Print($"• Profit netto: {netProfit:F2}€ ({netProfit / _initialEquity * 100:F2}%)");
                _parent.Print($"• Soglia minima: {adjustedThreshold:F2}% (base: {MIN_PROFIT_THRESHOLD_PERCENT:F2}%)");
                _parent.Print($"• Posizioni totali: {positions.Count}");
                _parent.Print($"• Massimo Drawdown registrato: {_maxDrawdownRegistered:F2}%");
                _parent.Print($"✅ CHIUSURA COORDINATA AUTORIZZATA - Profitto recuperato dopo recovery esteso");

                // Visualizza info sul grafico
                if (_parent.Chart != null && _parent.Bars != null && _parent.Bars.Count > 0 && positions.Any())
                {
                    _parent.Chart.DrawText("ExtendedRecoveryExit",
                        $"🎯 CHIUSURA COORDINATA\nProfit: {netProfit:F2}€ ({netProfit / _initialEquity * 100:F2}%)",
                        _parent.Bars.LastBar.OpenTime, positions.First().EntryPrice, Color.Green);
                }
            }
            catch (Exception ex)
            {
                _parent.Print($"⚠️ Errore durante la valutazione chiusura coordinata: {ex.Message}");
                // Continuiamo a restituire true anche in caso di errore durante la visualizzazione
            }
            return true;
        }

        return false;
    }

    /// <summary>
    /// Gestisce il TrailingStopLoss per le posizioni di recovery esteso
    /// </summary>
    public void ManageExtendedRecoveryTrailingStopLoss(List<Position> positions)
    {
        if (!_extendedModeActive || !_enableExtendedTrailingStopLoss || _extendedTslTriggerEuro <= 0)
            return;

        // Filtra solo le posizioni con l'etichetta di recovery esteso
        var extendedPositions = positions.Where(p => p.Label != null && p.Label.StartsWith("ExtRec_")).ToList();
        if (extendedPositions.Count == 0)
            return;

        double netProfitEuro = extendedPositions.Sum(p => p.NetProfit);

        // Identificatore unico per questo gruppo di posizioni
        string groupId = $"ExtRec_{_extendedPositionsOpened}";

        // Inizializza il tracker di profitto massimo se non esiste
        if (!_extendedTslMaxProfit.ContainsKey(groupId))
            _extendedTslMaxProfit[groupId] = 0;

        // Aggiorna il profitto massimo registrato
        _extendedTslMaxProfit[groupId] = Math.Max(_extendedTslMaxProfit[groupId], netProfitEuro);
        double maxProfitRegistered = _extendedTslMaxProfit[groupId];

        // Verifica se il trigger è stato raggiunto
        if (maxProfitRegistered >= _extendedTslTriggerEuro)
        {
            // Calcola il valore dello StopLoss
            double stopLossValue = maxProfitRegistered * (1.0 - _extendedTslDistancePercent / 100.0);

            // Disegna la linea del TSL sul grafico
            DrawExtendedTrailingStopLossLine(extendedPositions, maxProfitRegistered, stopLossValue);

            // Se il profitto attuale è sotto lo StopLoss, chiudi le posizioni
            if (netProfitEuro <= stopLossValue && netProfitEuro > 0)
            {
                _parent.Print($"⚠️ EXTENDED RECOVERY TSL ATTIVATO: Profitto {netProfitEuro:F2}€ sotto livello TSL {stopLossValue:F2}€");
                CloseExtendedRecoveryPositions(extendedPositions);
            }
        }
    }

    /// <summary>
    /// Disegna una linea di TrailingStopLoss per le posizioni di recovery esteso
    /// </summary>
    private void DrawExtendedTrailingStopLossLine(List<Position> positions, double maxProfit, double slValue)
    {
        try
        {
            if (_parent.Chart == null || positions.Count == 0)
                return;

            string lineId = "ExtendedRecoveryTSL_Line";
            _parent.Chart.RemoveObject(lineId);

            // Colore arancione per distinguerlo dal TSL normale
            Color tslColor = Color.Orange;

            // Disegna linea orizzontale e label
            _parent.Chart.DrawHorizontalLine(lineId, positions.First().EntryPrice, tslColor, 1, LineStyle.Dots);

            if (_parent.Bars != null && _parent.Bars.LastBar != null)
            {
                _parent.Chart.DrawText($"{lineId}_Label",
                    $"Ext TSL: {slValue:F2}€ (Max: {maxProfit:F2}€)",
                    _parent.Bars.LastBar.OpenTime,
                    positions.First().EntryPrice,
                    tslColor);
            }
        }
        catch (Exception ex)
        {
            _parent.Print($"⚠️ Errore nel disegno della linea TSL: {ex.Message}");
        }
    }

    /// <summary>
    /// Chiude le posizioni di recovery esteso in sicurezza
    /// </summary>
    /// <summary>
    /// Chiude le posizioni di recovery esteso in sicurezza
    /// </summary>
    private void CloseExtendedRecoveryPositions(List<Position> positions)
    {
        if (positions.Count == 0)
            return;

        _parent.Print($"\n==== CHIUSURA TSL RECOVERY ESTESO ====");
        _parent.Print($"• Posizioni da chiudere: {positions.Count}");

        double totalProfit = positions.Sum(p => p.NetProfit);
        _parent.Print($"• Profitto totale: {totalProfit:F2}€");

        foreach (var position in positions)
        {
            try
            {
                // Memorizza il label prima di chiudere la posizione
                string posLabel = position.Label;
                int posId = position.Id;

                position.Close();
                _parent.Print($"• ✅ Posizione chiusa: {posLabel}, Profit: {position.NetProfit:F2}€");

                // Pulisci gli oggetti grafici associati alla posizione
                CleanupPositionGraphics(posLabel, posId);
            }
            catch (Exception ex)
            {
                _parent.Print($"• ❌ Errore chiusura posizione {position.Label}: {ex.Message}");
            }
        }

        _parent.Print("==== FINE CHIUSURA TSL RECOVERY ESTESO ====\n");

        // Reset dei parametri di tracking
        string groupId = $"ExtRec_{_extendedPositionsOpened}";
        if (_extendedTslMaxProfit.ContainsKey(groupId))
            _extendedTslMaxProfit.Remove(groupId);
    }

    /// <summary>
    /// Rimuove tutti gli oggetti grafici associati ad una posizione chiusa
    /// </summary>
    private void CleanupPositionGraphics(string positionLabel, int positionId)
    {
        try
        {
            if (_parent.Chart == null) return;

            // Rimuovi linee ed etichette per recovery esteso
            if (positionLabel != null && positionLabel.StartsWith("ExtRec_"))
            {
                // Rimuovi linea breakeven
                _parent.Chart.RemoveObject("ExtendedRecoveryBE_Line");
                _parent.Chart.RemoveObject("ExtendedRecoveryBE_Line_Label");

                // Rimuovi linea TSL
                _parent.Chart.RemoveObject("ExtendedRecoveryTSL_Line");
                _parent.Chart.RemoveObject("ExtendedRecoveryTSL_Line_Label");

                // Rimuovi eventuali altri indicatori grafici specifici per recovery esteso
                _parent.Chart.RemoveObject("ExtendedRecoveryExit");
            }

            // Rimuovi linee TSL individuali per recovery normale
            _parent.Chart.RemoveObject($"TSL_Line_{positionId}");
            _parent.Chart.RemoveObject($"TSL_Label_{positionId}");

            // Se è l'ultima posizione di un gruppo, pulisci anche le linee di gruppo
            if (_parent.Positions.Count() <= 1)
            {
                _parent.Chart.RemoveObject("RecoveryTSL_Line");
                _parent.Chart.RemoveObject("RecoveryTSL_Line_Label");
                _parent.Chart.RemoveObject("BreakEvenLine");
                _parent.Chart.RemoveObject("BreakEvenLabel");
            }

            _parent.Print($"• 🧹 Puliti oggetti grafici per posizione {positionLabel} (ID: {positionId})");
        }
        catch (Exception ex)
        {
            _parent.Print($"⚠️ Errore durante la pulizia degli oggetti grafici: {ex.Message}");
        }
    }
}