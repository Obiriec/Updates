// ===================================================================================================
// PROFIT SENTINEL - Sviluppato da Armando Brecciaroli per Fury Team ©2023-2025
// Strategia Automatica Multi-Livello con Moduli Dinamici Recovery / TP / RSI Signal Engine
// Versione: 2.6.0 - Thread-Safe Protection System
// Build Date: 18-07-2025
// Sviluppato per cTrader Automate API
// © Tutti i diritti riservati - Prodotto non ridistribuibile
// ==================================================================================
//
// DESCRIZIONE:
// ProfitSentinel è un cBot avanzato per la piattaforma cTrader, progettato per la gestione automatizzata
// delle posizioni aperte tramite logiche di Trailing Profit, Take Profit fisso e Recovery Trades progressivi.
// Il sistema integra protezioni avanzate su Free Margin e Margin Level, gestione dinamica del rischio,
// Drawdown Progressivo, Cooldown movimento prezzo, e HUD grafico in tempo reale per la diagnostica operativa.
// Nella versione 1.8.0 sono stati aggiunti sistemi avanzati di analisi del rischio con Value at Risk (VaR),
// previsione della volatilità con modelli ML, riconoscimento pattern candlestick e analisi correlazione mercati.
//
// FUNZIONI PRINCIPALI:
// - Apertura iniziale automatica di trade LONG o SHORT selezionabile da menu.
// - Chiusura su Take Profit fisso con gestione opzionale di Drawdown (%).
// - Chiusura su Trailing TP dinamico con gestione Drawdown intelligente e TPStart % dinamico.
// - Sistema di Recovery trades avanzato con moltiplicatore progressivo e protezioni Free Margin e Margin Level.
// - Recovery con distanza minima da BreakEven, peggioramento progressivo del Drawdown, e movimento minimo richiesto.
// - Filtri Recovery: distanza minima pips, conferma RSI multi-condizione, movimento prezzo minimo richiesto.
// - Controllo MinProfit basato su margine usato + percentuale configurabile prima della chiusura profittevole.
// - HUD avanzato e dinamico: profitto, TP, Recovery, margini disponibili, protezioni attive, filtri operativi.
// - Diagnostica RSI Multi-Timeframe con filtri qualità: persistenza, delta crescente, curvatura, conferma a N barre.
// - Protezioni contro aperture multiple, spread e timing ingresso personalizzabile (conferma o barra successiva).
// - Massima stabilità, gestione sicura ordini e protezioni integrate anti-margin-call.
// - Analisi del rischio avanzata con Value at Risk (VaR) e modelli predittivi di volatilità.
// - Riconoscimento pattern candlestick per ottimizzazione segnali e timing entrata.
// - Sistema di monitoraggio correlazione tra mercati per analisi regime e correlazione.
//=======================================================================================================================
//
// CHANGELOG:
//
//    v1.3.6 (16 Aprile 2025)
//           - Prima versione ufficiale pubblica del ProfitSentinel v1.3.6.
//           - Sistema Recovery trades con moltiplicatore progressivo, TP fisso e Trailing TP dinamico.
//           - Controllo MinProfit su margine utilizzato.
//           - HUD grafico dinamico.
//
//    v1.3.7 (18 Aprile 2025)
//           - Correzioni formule Recovery, Break-Even, volumi.
//           - Migliorie HUD e gestione eventi posizioni chiuse.
//
//    v1.3.8 (19 Aprile 2025)
//           - Controllo corretto TP fisso e dinamico rispetto MinProfit (margine usato).
//           - Avvisi in HUD se TP insufficienti.
//           - Ottimizzazione descrizioni parametri Recovery Filters.
//
//    v1.5.0 (23 Aprile 2025)
//           - Recovery avanzato: distanza BreakEven, peggioramento DD richiesto.
//           - Introduzione Cooldown movimento minimo prezzo tra Recovery trades.
//           - Gestione riduzione lotto su Free Margin basso.
//
//    v1.5.1 (24 Aprile 2025)
//           - Protezione avanzata su Free Margin minimo (€) e Margin Level minimo (%).
//           - HUD migliorato: alert visivi su Free Margin e Margin Level.
//           - Revisione parametri sicurezza con soglie dirette in € e % reali.
//
//    v1.5.2 (24 Aprile 2025)
//           - HUD completamente aggiornato: diagnostica completa Free Margin, Margin Level e filtri Recovery.
//           - Migliorato controllo separato su Free Margin reale (€) e Margin Level (%).
//           - Ottimizzazione alert dinamici a colori in caso di rischio margine basso.
//           - Pulizia finale HUD: rimosse variabili obsolete e protezioni non più usate.
//
//    v1.5.3 (26 Aprile 2025)
//           - Recovery UltraPro: apertura recovery condizionata da nuovo swing/movimento reale + peggioramento € netto.
//           - HUD avanzato con Cooldown/Movimento/Gap Drawdown mostrati in formato leggibile.
//           - Refactoring completo in sezioni ordinate e commentate, per manutenzione rapida e sviluppo modulare.
//
//    v1.5.4 (27 Aprile 2025)
//           - Miglioramento del sistema di gestione del rischio con nuove logiche di controllo del drawdown.
//           - Ottimizzazione delle performance del cBot in condizioni di mercato ad alta volatilità.
//           - Aggiunta di nuove metriche nel HUD per una migliore visualizzazione delle condizioni di mercato.
//           - Correzione di bug minori e miglioramenti nella stabilità complessiva del sistema.
//
//    v1.5.5 (28 Aprile 2025 - Dynamic TPStart & Diagnostica MultiSimbolo Upgrade)
//           - ➕ Aggiunto Dynamic TPStart basato su % di Balance/Equity/FreeMargin.
//           - ➕ Aggiunta protezione TPStartMinimo per trailing sicuro su TPStart dinamico.
//           - ➕ Visualizzazione Dynamic TPStart nell'HUD con colori adattivi, Flash Smooth e icone di stato.
//           - ➕ Aggiunta Diagnostica Simboli attivabile da menu: verifica multi-simbolo su HUD.
//           - 🔥 Semaforo visivo 🟢🟠🔴 in tempo reale su HUD, con lampeggio rosso su errori gravi.
//           - 🛠️ Refactoring OnTick con ottimizzazione HUD Ultra-Lightweight senza spam.
//           - 🛠️ Protezione contro spam log: avviso console intelligente solo ogni 10 secondi su variazioni reali.
//           - 🔒 Compatibilità totale Live + Demo + VPS Ready.
//           - 📈 Migliorie finali su performance grafica, gestione eventi, sicurezza ordini.
//
//    v1.5.6 (29 Aprile 2025 - Migliorie HUD e Refactoring Visuale Sicuro)
//           - ✅ Rimozione parametro duplicato HUDesteso, mantenuto solo HUDCompatto (unificazione logica).
//           - ✅ Corretto stato HUD: mostra correttamente "Compatto" o "Esteso" in base al flag attivo.
//           - ✅ Barra HUD distanza BreakEven con riempimento proporzionale corretto (massimo 10 blocchi).
//           - ✅ Refactoring finale `DrawHUD()` e `DrawHUDCompatto()` per coerenza visiva e leggibilità.
//           - 🔐 Nessuna modifica alle logiche operative principali: TP/Recovery invariati.
//           - 🧱 Versione stabile pronta per distribuzione o pacchettizzazione .algo/.cbotset.
//           - 🔧 Tutte le modifiche modulari, sicure, integrate senza impatto retroattivo.
//           - 🧠 Allineato al profilo "Fury Team Release Mode – maggio 2025".
//
//    v1.5.7 (30 Aprile 2025 - Colorazione Swing HUD Integrata)
//           - 🎨 Integrazione completa modulo "HUD Color Dynamic" in DrawHUD().
//           - 🎯 Priorità di colorazione: Swing ➜ TP/Profit ➜ Recovery ➜ fallback logico (profit/loss).
//           - 🌈 Colori semitrasparenti contestuali: blu/rosso chiaro in base a Swing attuale.
//           - 🔁 Nessuna sovrascrittura di codice preesistente: blocco integrato in modalità isolata.
//           - ⚙️ Pronto per estensioni future su RGB dinamico, interpolazione colore o Flash HUD.
//           - 📌 Versione 100% modulare e aderente alle direttive: nessuna cancellazione, solo append.
//
//    v1.5.8 (2 Maggio 2025 - Miglioramenti Gestione BreakEven e Debug)
//           - 🛠️ Fix critico nel calcolo del margine usato con doppio fallback (GetEstimatedMargin + calcolo manuale)
//           - 📊 Aggiunti log di debug avanzati per il calcolo del margine e controllo MinProfit
//           - 🔍 Migliorata la diagnostica HUD per mostrare i dettagli del calcolo del margine
//           - 🧹 Pulizia codice e ottimizzazioni minori nelle funzioni di utilità
//           - 🔄 Migliorata la gestione degli errori durante il calcolo del margine
//           - 📈 Aggiunta visualizzazione del margine calcolato nell'HUD esteso
//           - 🛡️ Aggiunte ulteriori protezioni contro divisioni per zero e valori non validi
//
//    v1.5.9 (3 Maggio 2025 - Miglioramenti Visualizzazione TP Dinamico)
//           - ✅ Aggiunta visualizzazione esplicita del profitto mancante per raggiungere il TP dinamico
//           - 📌 Nell'HUD Esteso: dettaglio numerico "Stato attuale: X€ (mancano Y€ per Z€)"
//           - 📱 Nell'HUD Compatto: formato ultra-sintetico con icona ✔/✖ e importo mancante
//           - 🔄 Nessuna modifica alle logiche operative esistenti, solo miglioramenti visualizzazione
//           - 🧹 Ottimizzazione formattazione codice nelle nuove sezioni aggiunte
//           - 🛡️ Mantenute tutte le protezioni e logiche preesistenti intatte
//
//    v1.5.9-r2 (3 Maggio 2025 - Fix Completo BreakEven Visual + HUD)
//           - ✅ Corretto disegno linea BreakEven: ora usa sempre il prezzo target reale e non EntryPrice
//           - ✅ Etichetta grafica e linea BE aggiornate con prezzo esatto di uscita calcolato
//           - ✅ HUD mostra ora correttamente il prezzo target BreakEven, non più l'entry errato
//           - ✅ Slider pips distanza BreakEven usa offset effettivo dal prezzo target
//           - 🔄 Refactoring DrawBreakEvenLineSafe() e GetBreakEvenPrice() per allineamento corretto
//           - 🧠 Aggiornati OnTick(), DrawHUD() e HUD compatto per coerenza dati BE
//           - 🔧 Mantenute intatte tutte le logiche operative (TP, Recovery, MinProfitCheck)
//           - 📌 Changelog e intestazione aggiornati alla v1.5.9-r2 (Fury Team Release Mode)
//
//    v1.5.9-r3 (3 Maggio 2025 - Fix HUDCompatto BreakEven Definitivo)
//           - ✅ HUD Compatto aggiornato: ora mostra sempre il prezzo reale di chiusura BreakEven (target), non più l'EntryPrice.
//           - ✅ Corretto calcolo e visualizzazione distanza pips nello slider BE, ora allineato al target reale.
//           - ✅ Righe "BE: ... €" e "BE Target: ..." ora derivano da GetBreakEvenTargetPrice() anche nel compatto.
//           - 🔁 Pulizia uso variabile `be` nel metodo DrawHUDCompatto(): sostituito con calcolo diretto coerente.
//           - 🛠️ Nessun impatto sulle logiche operative o di chiusura reali: solo miglioramento visuale coerente.
//
//    v1.5.9-r4 (3 Maggio 2025 - Fix Finale BreakEven Visual + Calcolo Pips)
//           - ✅ Corretto il calcolo `GetBreakEvenTargetPrice()` con divisione sicura su `PipValue / 100000.0`
//           - ✅ Valore BreakEven ora coerente in HUD, linea grafica e slider pips
//           - ✅ Aggiunto log di debug `🧪 DEBUG BE: Bid=X, BE=Y, PipSize=Z` per facilitare diagnosi
//           - ✅ Eliminati calcoli errati dovuti a unità non normalizzate
//           - ✅ Funzionalità Breakeven ora 100% stabile e pronta per rilascio definitivo
//    v1.5.9-r4 (3 Maggio 2025 - Fix Finale BreakEven Visual + Calcolo Pips)
//           - ✅ Corretto il calcolo `GetBreakEvenTargetPrice()` con divisione sicura su `PipValue / 100000.0`
//           - ✅ Valore BreakEven ora coerente in HUD, linea grafica e slider pips
//           - ✅ Aggiunto log di debug `🧪 DEBUG BE: Bid=X, BE=Y, PipSize=Z` per facilitare diagnosi
//           - ✅ Eliminati calcoli errati dovuti a unità non normalizzate
//           - ✅ Funzionalità Breakeven ora 100% stabile e pronta per rilascio definitivo
//
//    v1.6.0 (04 Maggio 2025 - Rilascio Finale Stabile HUD+BE)
//           - 🧱 Versione finale stabile dichiarata: HUD Esteso e HUD Compatto definitivi
//           - ✅ Corretto duplicato versione nell'HUD compatto: ora mostra solo `BUILD_ID` coerente
//           - ✅ Restyling completo `DrawHUDCompatto()`: ora più leggibile, diretto, efficiente
//           - 🎯 Tutte le visualizzazioni BE ora coerenti: slider, target, distanza pips
//           - 📌 Versione ufficiale *Fury Team Release v1.6.0* marcata come stabile per utilizzo operativo
//           - 🚀 Pronta per compilazione `.algo` e pacchetti `.cbotset` di distribuzione
//
//    v1.6.1 (3 Maggio 2025 - BreakEven Fix: Fisso e Universale)
//           - ✅ Ripristinata logica BreakEven a soglia fissa, evitando comportamento da trailing stop
//           - ✅ `GetBreakEvenTargetPrice()` ora restituisce un valore costante basato su `fixedBreakEvenProfitThreshold`
//           - ✅ Compatibilità BreakEven estesa a simboli CFD/indice come GERMANY 40 (TopFX)
//           - ✅ Corretto `DrawBreakEvenLineSafe()` con etichetta a posizione fissa sul prezzo target
//           - ✅ Completato restyling HUDCompatto con slider BE corretto e sintesi visiva migliorata
//           - 🔄 HUD Esteso aggiornato: visualizzazione corretta pips BE e slider adattivo
//           - 🔐 Nessuna regressione sulle logiche TP dinamico, Recovery o MinProfitCheck
//           - 📌 Versione stabile universale per tutti i simboli (Forex, Indici, CFD)
//
//    v1.6.2 (6 Maggio 2025 - Revisione Completa RSI Multi-Timeframe + HUD Diagnostico)
//           - ✅ Rimosso completamente il riferimento a indicatori RSI esterni: ora la logica RSI è interna e indipendente
//           - 🔁 Refactoring completo dei metodi `IsSegnaleRSIValido()`, `AggiornaRSI()` e `DebugSegnaleRSI()` per gestione multi-timeframe pulita
//           - 📌 Valori RSI Base e Superiore gestiti separatamente con memorizzazione, aggiornamento e logging coerente
//           - 🧠 Nuova diagnostica RSI avanzata: stampa log dettagliati con cooldown, delta RSI e condizioni valide
//           - ✳️ Aggiunto supporto forzatura segnale RSI via flag `ForzaSegnaleRSI` (per test e debug)
//           - 🎯 HUD aggiornata: visualizzazione coerente dei segnali RSI, incluso disegno grafico segnale su chart
//           - 🧱 Pulizia completa codice RSI: ora modulare, testabile e compatibile con simboli diversi
//           - ✅ Consolidata la logica ordine da segnale RSI con protezioni anti-duplicazione posizione e label coerenti
//           - 📌 Versione ufficiale *Fury Team Release v1.6.3* per RSI Multi-Timeframe & HUD Diagnostico Integrato
//
//    v1.6.3 (6 Maggio 2025 - Consolidamento HUD RSI e Protezioni Iniziali)
//           - ✅ Consolidata struttura HUD con nuova sezione RSI diagnostico: visualizzazione completa LONG/SHORT live
//           - ✅ Aggiunto controllo: blocco segnale RSI se TimeFrame superiore ≤ TF base ➜ log + HUD warning dedicato
//           - ✅ Migliorata compatibilità avvio anche con SL e TP = 0 (ordini senza limiti iniziali ammessi)
//           - ⚠️ Aggiunto warning live: TP segnale troppo stretto, potenziale rischio spread > profitto
//           - ✅ Corretto errore su logica `MinProfitOverMargin`: ora valutato solo con posizioni effettive aperte
//           - ✅ SafeCloseAllPositions() ora chiude tutte le posizioni sul simbolo, ignorando label/commenti
//           - ✅ Cooldown entry RSI ora impedisce doppie aperture: verifica se esistono posizioni aperte nel symbol
//           - 🔧 Debug OnBar arricchito con diagnostica RSI dettagliata: delta, tempo ultimo segnale, stato valido
//           - 📌 Versione ufficiale *Fury Team Release v1.6.3* stabile per segnali RSI, chiusura coerente, entry sicura
//
//    v1.6.4 (6 Maggio 2025 - Trailing TP Reale + Protezione Soglia Garantita)
//           - ✅ TP Dinamico trasformato in vero trailing stop: maxTP viene aggiornato ogni volta che il profitto supera il massimo precedente
//           - ✅ La soglia minima di profitto aggiornata segue esattamente il valore massimo raggiunto con TPDrawdown% costante
//           - ✅ Protezione integrata: se attivo MinProfitCheck, la soglia minima è sempre la maggiore tra trailing e margine richiesto
//           - ✅ Corretto comportamento SafeCloseAllPositions(): ora chiude solo se il profitto netto è conforme alla soglia trailing
//           - 🧠 HUD Esteso aggiornato: visualizza soglia minima dinamica aggiornata + stato trailing real-time
//           - 🔍 Debug avanzato su ogni update di maxTP, soglia trailing e condizioni di chiusura dinamica
//           - 🛡️ Protezione aggiuntiva: nessuna chiusura autorizzata se profitto < trailingMinProfit anche se trigger avvenuto
//           - 🧱 Sincronizzato con struttura HUD v1.6.3: visualizzazione coerente, integrata e completa
//           - 📌 Versione ufficiale *Fury Team Release v1.6.4* per trailing TP sicuro e coerente in tempo reale
//
//    v1.6.5 (7 Maggio 2025 - Fix TP Dinamico & Ottimizzazioni HUD)
//           - 🛠️ Corretto bug: chiusura TP dinamico poteva avvenire anche se maxTP < TPStart
//           - 🧠 Ora il trailing TP viene attivato solo dopo il reale superamento di TPStart o TPStartPercent
//           - ✅ Aggiunto controllo coerente anche nell'HUD per riflettere solo trailing attivo se triggerato
//           - 📱 HUD Compatto aggiornato con messaggi più precisi e ordinati per TP Dinamico e BreakEven
//           - 🖥️ HUD Esteso allineato per chiarezza, rimozione duplicati, ordine logico delle informazioni
//           - 🧪 Migliorato logging: log TP dinamico e BreakEven resi più leggibili e coerenti
//           - 📌 Versione ufficiale *Fury Team Release v1.6.5* pronta per build finale
//
//    v1.6.6 (8 Maggio 2025 - Conferma Segnale RSI Multi-Barra & Timing Apertura)
//           - ✅ Introdotto filtro "Conferma Segnale RSI": richiede N barre consecutive valide prima dell'esecuzione ordine
//           - ⏱️ Aggiunta opzione di Timing apertura posizione:
//               • Alla chiusura della barra che ha confermato il segnale
//               • Alla chiusura della barra successiva (maggior prudenza)
//           - 📊 Diagnostica HUD aggiornata con stato attesa conferma + metodo di apertura configurato
//           - 🧠 Log dettagliato delle fasi: accumulo barre, conferma, esecuzione condizionata dal timing selezionato
//           - 🔁 Integrato nel blocco OnBar(), DrawHUD() e parametri generali senza alterare la struttura esistente
//           - 📌 Versione ufficiale *Fury Team Release v1.6.6* focalizzata sulla robustezza del timing d'ingresso operazioni
//
//    v1.6.7 (8 Maggio 2025 - Protezione Recovery & Uniformità Formula DD)
//           - ⛔ Bloccata l'esecuzione di Recovery se il profitto netto attuale è positivo ➜ protezione obbligatoria
//           - 🧠 Uniformato il calcolo del drawdown Recovery usando `GetRecoveryReferenceValue()` in tutte le funzioni
//           - 🔍 Verifica completa delle formule drawdown in OnTick(), ExecuteLogic(), HUD e TryRecovery
//           - 📊 HUD aggiornato: DD visualizzato in % uniforme rispetto al riferimento selezionato (Balance, Equity, FreeMargin)
//           - 🔄 Refactoring e controllo approfondito su formula TP Dinamico vs BE per evitare doppi trigger incoerenti
//           - 📦 Codice completamente validato dopo controllo integrale in 3 sezioni
//           - 📌 Versione ufficiale *Fury Team Release v1.6.7* focalizzata sulla protezione Recovery e coerenza formule
//
//    v1.6.8 (9 Maggio 2025 - Fix DD Recovery su Balance + Uniformità MinDDIncreasePercent)
//           - 🧮 Corretto il calcolo del DrawDown Recovery: ora sempre basato sul Balance corrente (non più Equity o formule cumulative errate)
//           - 🎯 Uniformata la logica `Minimo Peggioramento DD%` ➜ confronto ora su base % coerente (DD vs Balance)
//           - 🪪 Log estesi con confronto percentuale tra DD corrente e soglia richiesta ➜ visibilità piena
//           - 🔧 Integrazione diretta in `TryRecovery()` con allineamento a tutte le modalità Recovery esistenti
//           - ✅ Test e validazione superata in condizioni multiple (trigger, peggioramento, cooldown, sicurezza)
//           - 📌 Versione ufficiale *Fury Team Release v1.6.8* con correzione critica drawdown su base balance
//
//    v1.6.9 (10 Maggio 2025 - Patch Etichette RSI + Fix HUD Diagnostico TrendFollowing/Contrarian)
//           - 🟢 Corretto il modulo `DrawSegnaleGraficoRSI()` ➜ ora stampa correttamente le etichette LONG/SHORT
//             anche in modalità TrendFollowing (le etichette ora si invertono rispetto al segnale grezzo)
//           - 🟣 Uniformata la logica dell'HUD RSI ➜ Diagnostica Avanzata e Tecnica ora mostrano sempre
//             la direzione operativa coerente con la modalità (Contrarian = segnale grezzo; TrendFollowing = inverso)
//           - 🔍 Migliorata la funzione `GeneraStringaQualitaSegnale()` con coerenza interna e compatibilità etichette
//           - 🧪 Debug visuale migliorato con stampa `Print()` della modalità RSI, direzione segnale grezzo,
//             etichetta stampata e direzione del trade effettivo
//           - ✅ Validato su tutte le combinazioni operative: TrendFollowing/Contrarian, con/contro trend, e
//             tutte le condizioni di Delta/Persistenza/Filtro attivi
//
//    v1.7.0 (13 Maggio 2025 - Fix Recovery Volume & Fattore Potenziamento DD)
//           - ✅ Corretto calcolo volume recovery: ora sempre in multipli di 0.01 lots
//           - 🔧 Implementato sistema automatizzato per Fattore Potenziamento DD in base alla modalità:
//               • Standard: usa il valore configurato senza modifiche
//               • Bilanciato: richiede +50% del valore base (min +1.5%)
//               • Aggressivo: riduce al 60% del valore base (min 1%)
//           - 🧮 Rivista formula calcolo volume recovery:
//               • Normalizzazione sempre a 0.01 lots
//               • Blocco su volumi inferiori al minimo
//               • Gestione coerente moltiplicatore in base alla modalità
//           - 🛡️ Aggiunta protezione volume minimo (0.01) in tutte le funzioni che usano ExecuteMarketOrder
//           - 📊 Migliorato sistema di logging per tracciamento calcolo volumi
//           - 🔄 Centralizzata gestione normalizzazione volumi
//           - 🎯 Ottimizzato sistema di logging per DD e volumi recovery
//           - 📌 Versione ufficiale *Fury Team Release v1.7.0* con fix critici gestione volumi
//
//    v1.7.1 (14 Maggio 2025 - Fix Recovery Avanzato & DD Dinamico)
//           - ✅ Implementato sistema DD dinamico basato sul rapporto tra i lotti
//           - 🧮 Tre modalità calcolo DD:
//               • Standard: usa radice quadrata (più conservativo)
//               • Enhanced: usa radice cubica (medio)
//               • Aggressive: usa moltiplicatore diretto (più aggressivo)
//           - 🔧 Aggiunto parametro DDMultiplier per amplificare effetto (1.0-5.0)
//           - 📊 Log dettagliati calcolo DD dinamico con tutti i fattori
//           - 🛡️ Protezione aggiuntiva su recovery ravvicinati
//           - 🔄 DD richiesto aumenta progressivamente con l'aumento dei lotti
//           - 📈 Formula: DD = BaseDD × √(LotRatio) × DDMultiplier
//           - 🧪 Test approfonditi su tutte le modalità di calcolo
//           - 📌 Versione ufficiale *Fury Team Release v1.7.1* con fix critici recovery
//
//    v1.8.0 (10 Giugno 2025 - Analisi Avanzata e Sistemi Predittivi)
//           - 🧠 Implementato sistema Value at Risk (VaR) per analisi rischio avanzata
//           - 📊 Aggiunta previsione volatilità con modello semplificato
//           - 🎯 Riconoscimento pattern candlestick per conferma segnali (Doji, Engulfing, ecc.)
//           - 🔄 Analisi correlazione mercati tra simboli chiave (oro, indici, forex)
//           - 📈 HUD arricchito con visualizzazione analisi avanzate (VaR, volatilità, pattern)
//           - 📐 Centralizzazione calcolo volatilità con metodi multipli (Range, ATR, StdDev)
//           - 🎯 Migliorato sistema di visualizzazione TP Dinamico con linea grafica interattiva
//           - 📝 Aggiunto log dettagliato per calcolo TP Dinamico con parametri precisi
//           - 🔧 Ottimizzata la gestione della formattazione numerica per diverse valute
//           - 📊 Sistema log strutturato con livelli e categorie
//           - 🔍 Migliorata la precisione del calcolo del prezzo target di uscita
//           - 📌 Versione ufficiale *Fury Team Release v1.8.0* - Advanced Risk Analysis
//
//    v1.9.0 (16 Maggio 2025 - Fix Critici & Miglioramenti Stabilità)
//           - 🛠️ Corretto bug critico del TP Dinamico che chiudeva posizioni con profitto inferiore alla soglia
//           - ✅ Implementato sistema robusto di chiusura con tentativo multiplo (fino a 3 retry per posizione)
//           - 🔄 Migliorata gestione BreakEven per mantenerlo attivo anche con TP Dinamico
//           - 📊 Corretto il calcolo della tolleranza di chiusura per evitare chiusure premature
//           - 🔄 Migliorato reset di maxTP e tpDinamicoAttivato dopo chiusura di tutte le posizioni
//           - 🔍 Aggiunto logging dettagliato per diagnosi problemi di chiusura
//           - ⚡ Ottimizzata protezione spread per prevenire chiusure durante spread elevato
//           - 📈 Migliorata coerenza between TP Dinamico e BreakEven con funzionamento parallelo
//           - 🧠 Logica adattiva per la gestione delle chiusure e rilevamento orfani
//           - 👁️ Visualizzazione migliorata del target TP Dinamico sul grafico
//
//    v1.9.1 (17 Maggio 2025 - Sistema Controllo Aggiornamenti e Gestione Licenze)
//           - ✅ Implementato sistema automatico di controllo aggiornamenti
//           - 🔐 Migliorato sistema di verifica licenze con formato JSON standardizzato
//           - 🛡️ Aggiunta visualizzazione notifiche su grafico per aggiornamenti disponibili
//           - ⚠️ Gestione aggiornamenti obbligatori con blocco esecuzione
//           - 📋 Visualizzazione dettagliata changelog e note di rilascio
//           - 🔄 Verifica periodica degli aggiornamenti (ogni 24 ore)
//           - 📊 Integrazione completa con server di licenze e aggiornamenti
//           - 🔧 Correzioni minori e miglioramenti di stabilità generali
//
//    v1.9.2 (22 Maggio 2025 - Sistema Licenze Avanzato con Auto-Nascondimento)
//           - ✅ Migliorata visualizzazione informazioni licenza con formattazione avanzata e dettagliata
//           - ⏲️ Aggiunto parametro configurabile per auto-nascondere il messaggio licenza dopo X secondi
//           - 📊 Aggiunto contatore visibile su schermo per il tempo rimanente prima della rimozione
//           - 🔧 Implementata gestione automatica dello stato di visualizzazione della licenza
//           - 🛡️ Ottimizzato e centralizzato il sistema di verifica licenza con gestione eventi
//           - 🖥️ Migliorato posizionamento e formattazione delle informazioni a schermo
//
//    v1.9.3 (26 Maggio 2025 - Filtro Distanza Dinamico Avanzato)
//           - ✅ Migliorato calcolo della distanza di sicurezza con adattamento proporzionale ai lotti aperti
//           - 📊 Implementata formula logaritmica per incremento dinamico della distanza minima tra recovery
//           - 🧮 Volume totale delle posizioni aperte ora influisce direttamente sulla distanza richiesta
//           - 🛡️ Protezione incrementale: maggiore è l'esposizione, più alta è la distanza di sicurezza
//           - 🔄 Fattore di scaling volume con crescita progressiva (1.0 + Log10(1.0 + totalOpenLots))
//           - 📈 Visibilità completa nel log per tutti i fattori di calcolo della distanza dinamica
//
//    v1.9.4 (30 Maggio 2025 - Sistema Integrato di Controllo e Sicurezza)
//           - ✅ Sistema completo di verifica licenze con modalità online/offline e controllo integrità
//           - 🔄 Implementazione controllo automatico degli aggiornamenti con notifiche interattive
//           - 🔐 Sistema di blocco operatività in caso di aggiornamenti obbligatori disponibili
//           - 🛡️ Protezione avanzata contro spread anomali con campionamento storico intelligente
//           - 🔍 Gestione migliorata dei cooldown tra recovery con scaling proporzionale ai volumi
//           - 📊 Sistema diagnostico RSI potenziato con metriche di qualità e visualizzazione dettagliata
//           - ⏱️ Visualizzazioni HUD ottimizzate con auto-nascondimento informazioni non essenziali
//           - 📈 Log strutturato a categorie per tracciamento completo delle operazioni
//           - 🧠 Funzioni diagnostiche avanzate per troubleshooting in tempo reale
//           - 🔧 Ottimizzazioni prestazionali per riduzione overhead computazionale e HUD
//
//    v2.0.0 (31 Maggio 2025 - Aggiornamento Visualizzazione Recovery e Ottimizzazioni)
//           - ✅ Migliorata visualizzazione della soglia DD minima per recovery nell'HUD
//           - 📊 Aggiunta formattazione dettagliata: "Soglia DD minima: 17.23% (8.23% + 9.00%)"
//           - 🧠 Ottimizzato calcolo decimali per visualizzazione prezzi dinamici
//           - 🔄 Correzioni formattazione numerica con precisione decimali dal broker
//           - 🎯 Migliorati calcoli visualizzazione TP dinamico con decimali corretti
//           - 🛡️ Migliorate protezioni contro errori di arrotondamento prezzi
//           - 📱 HUD operativo aggiornato con informazioni più chiare sulla soglia DD
//           - 🎨 Migliorata formattazione etichette grafiche con decimali broker-specific
//
//    v2.1.0 (01 Giugno 2025 - Miglioramenti Controlli RSI e Filtri)
//           - ✅ Aggiunto controllo ON/OFF per filtro Delta Minimo RSI
//           - ✅ Aggiunto controllo ON/OFF per Barre Conferma Segnale
//           - 🔍 Migliorata diagnostica per timing aperture posizioni (chiusura barra attuale/successiva)
//           - 📊 Log dettagliati sui controlli di validazione segnali e timing esecuzione
//           - 📑 Ottimizzazione complessiva dei filtri di qualità segnali
//
//    v2.1.1 (10 Giugno 2025 - Fix Logica Contrarian)
//           - ✅ Corretto bug critico nella logica della modalità Contrarian
//           - 🔄 Risolto problema di inversione errata dei segnali RSI
//           - ⚠️ In modalità Contrarian ora:
//               - Segnale LONG (RSI ipervenduto) → apre posizione LONG
//               - Segnale SHORT (RSI ipercomprato) → apre posizione SHORT
//           - 🧪 Aggiunti test di validazione per tutte le combinazioni di modalità/segnali
//           - 📊 Migliorata diagnostica con log espliciti della direzione operativa
//
//    v2.1.2 (20 Giugno 2025 - Fix Logica TrendFollowing e HUD)
//           - ✅ Corretto comportamento della modalità TrendFollowing
//           - 🔄 Implementata corretta inversione segnali in TrendFollowing:
//               - Segnale LONG (RSI ipervenduto) → apre posizione SHORT
//               - Segnale SHORT (RSI ipercomprato) → apre posizione LONG
//           - 🎨 Corretta la visualizzazione della direzione operativa nell'HUD
//           - 📊 Aggiornato HUD diagnostico per mostrare segnali coerenti con la modalità selezionata
//           - 🔍 Migliorati log di debug con tracciamento della modalità RSI e direzione operativa
//           - 🏷️ Etichette grafiche ora mostrano correttamente la direzione effettiva dell'operazione
///
//    v2.1.3 (04 Giugno 2025 - Ottimizzazioni generali e miglioramenti performance)
//           - 🔄 Ottimizzazione del sistema di gestione memoria e visualizzazione HUD
//           - ⚡ Migliorata efficienza calcoli ripetitivi per TP dinamico e recovery
//           - 🛡️ Rafforzata la gestione degli errori e protezioni di sicurezza
//           - 🖥️ Ottimizzata visualizzazione HUD con refresh ridotti per migliori performance
//           - 📊 Raffinato sistema diagnostico RSI con riduzione overhead computazionale
//           - 🚀 Miglioramenti generali stabilità per funzionamento prolungato in VPS
//           - 📝 Aggiornato sistema licenze per migliore compatibilità e verifica
//
//    v2.2.0 (04 Giugno 2025)
//           - 🔑 Implementazione sistema completo di licenze online/offline
//           - 🛡️ Migliorato sistema sicurezza e verifica integrità licenza
//           - 🔄 Aggiunto sistema automatico di controllo aggiornamenti
//           - 📋 Gestione avanzata aggiornamenti obbligatori/opzionali
//           - 💻 Interfaccia migliorata per visualizzazione stato licenza
//           - 📂 Supporto memorizzazione locale per licenze offline
//
//    v2.3.0 (05 Giugno 2025 - Miglioramenti HUD RSI e Prestazioni)
//           - ✅ Implementata disabilitazione automatica HUD RSI durante posizioni aperte
//           - 🛡️ Prevenzione gestione segnali RSI durante trade attivi per evitare confusione
//           - 🧹 Migliorata visualizzazione HUD con messaggio chiaro sullo stato sospeso
//           - 📈 Ottimizzata gestione memoria con minore overhead durante trade attivi
//           - ⚙️ Riattivazione automatica analisi RSI dopo chiusura posizioni
//           - 🔄 Migliorata coerenza fra HUD operativo e diagnostico durante operazioni in corso
//           - 🚫 Implementato blocco automatico etichette grafiche RSI durante posizioni aperte
//
//    v2.3.1 (06 Giugno 2025 - Fix Compatibilità HUD e Ottimizzazioni Query)
//           - ✅ Corretto errore critico nel rendering HUD: metodo FindAll sostituito con approccio LINQ
//           - 🔄 Migliorata compatibilità con interfacce di collezione cTrader
//           - 🧹 Ottimizzazione query sulle posizioni
//           - 🛡️ Maggiore resilienza nella gestione delle collezioni di posizioni
//           - 🔍 Perfezionamento logging diagnostico
//           - 🔍 Integrato filtro EMA per validazione segnali RSI con modalità suggerimento o blocco
//
//    v2.4.0 (06 giugno 2025 - Sistema Avanzato Filtro RSI Swing Detection)
//           - 🔍 Implementato innovativo sistema di rilevamento swing points nell'RSI
//           - 📊 Analisi avanzata dei pattern di tendenza con identificazione picchi e valli
//           - 🔄 Filtro curvatura RSI completamente riprogettato con approccio dual-mode
//           - 🧮 Sistema ibrido che combina analisi tradizionale (3 barre) e swing detection (trend) 
//           - ⚖️ Valutazione dinamica della forza e regolarità degli swing per conferma segnali
//           - 📈 Migliorata drasticamente l'affidabilità dei segnali sui timeframe superiori
//           - 🛡️ Riduzione falsi negativi mantenendo l'efficacia del filtro qualitativo
//           - 📱 Log dettagliati con analisi completa dei pattern rilevati
//           - 🧪 Implementato confronto automatico tra metodo classico e swing detection
//           - 🔧 Ottimizzati parametri di sensibilità per adattamento a diversi mercati
//
//    v2.4.1 (11 Giugno 2025 - Correzione calcolo MinProfitCheck)
//           - ✅ Corretto calcolo MinProfitCheck per utilizzare solo il margine del simbolo attuale
//           - 🔧 Implementato metodo GetSymbolMargin per calcolare correttamente il margine solo per il simbolo corrente
//           - 🎛️ Migliorata visualizzazione nell'HUD dei requisiti MinProfit con valori più precisi
//           - 🛡️ Maggiore stabilità nelle operazioni di controllo margine minimi
//
//    v2.5.0 (08 Luglio 2025 - Ottimizzazione Filtri RSI e Modularizzazione Validazione)
//           - ✅ Unificati i filtri di qualità RSI (AbilitaFiltroPersistenzaRSI e AbilitaBarreConfermaSegnale)
//           - 🧩 Rifattorizzato il metodo ValidaSegnaleRSIConQualita in componenti modulari con responsabilità specifiche
//           - 📊 Implementato sistema di filtri più flessibile con conteggio proporzionale (50% superati = valido)
//           - 🛡️ Risolto bug critico che impediva l'apertura di posizioni con filtro barre conferma attivo
//           - 🔄 Migliorata gestione delle code di validazione segnali per tracking corretto validità consecutiva
//           - ⚙️ Aggiunto enum TipoConsistenzaRSI per personalizzare il rigore della validazione (Standard/Avanzato/Rigoroso)
//           - 📝 Ottimizzato logging con informazioni diagnostiche dettagliate sui filtri attivi e relativo stato
//           - 🔧 Supporto retrocompatibilità completa con configurazioni esistenti
//           - 📈 Migliorata l'efficacia della validazione segnali con minore rigidità e maggiore adattabilità
//           - 🧠 Struttura modulare che facilita estensioni e personalizzazioni future dei criteri di validazione
//
//    v2.6.0 (18 Luglio 2025 - Thread-Safe Protection System)
//           - 🔒 Implementato sistema anti-duplicazione per segnali RSI con lock thread-safe
//           - 🛡️ Aggiunto controllo di sicurezza per evitare aperture multiple sullo stesso simbolo
//           - ✅ Migliorata gestione delle posizioni esistenti prima dell'apertura di nuove
//           - ⏱️ Ottimizzato meccanismo temporale per prevenire segnali troppo ravvicinati
//           - 🔧 Potenziata gestione sicura dei flag pendenti nel modulo di recovery
//           - 📊 Integrata sincronizzazione thread-safe per operazioni concorrenti
//           - 🧠 Migliorato sistema di logging con tracciamento dettagliato delle operazioni rifiutate
//           - 🔍 Rafforzato sistema di verifica stato posizioni per protezione aperture simultanee
//           - 🛠️ Consolidato modulo di protezione doppie operazioni nel metodo EseguiSegnaleRSI
//
// ==================================================================================================== 
// 📘 LEGENDA EMOJI — ProfitSentinel HUD e Diagnostica 
// ==================================================================================================== 
// 📊 / 🛡️   = Intestazioni generali / HUD esteso 
// 📱 / 🖥️   = HUD compatto / esteso 
// ★          = Titolo HUD compatto 
// vX.X.X     = Versione build 
// 
// 💰 PROFITTO E TP DINAMICO 
// •          = Bullet info 
// ✅ / ❌     = Attivo / Disattivo 
// ⏳         = In attesa trigger TP dinamico 
// 🎯         = Target raggiunto (BE / TP) 
// 🚀         = Volo libero (profitto extra) 
// 🌱         = Base sicura 
// 📈         = Crescita stabile / segnale LONG 
// 🏹         = Mira al massimo 
// 🌈         = Performance brillante 
// 💰         = Profitto extra 
// 🔴 / 🟢 / 🟡 = Stato TP dinamico / MinProfitCheck
// 🚦         = Via libera (stato TP dinamico)
// 
// 📍 / 📌 / 🧪 = BreakEven (target, debug, log tecnico) 
// 📉         = Segnale SHORT (RSI) / log 
// 🎯         = Soglia target BreakEven 
// ■ / ░      = Slider distanza BE (pips) 
// 
// 🔁 RECOVERY 
// 🔁         = Stato Recovery 
// 🧩 / ⚖️ / 🔥 = Recovery Mode: Standard / Bilanciato / Aggressivo 
// 🔵 / 🟢 / 🟠 = Recovery Reference: Balance / Equity / FreeMargin 
// 🔄         = Chiusura sicura 
// 
// 🧭 SWING / TREND 
// 🔻 / 🔺     = Swing LOW (LONG) / HIGH (SHORT) 
// ○ / –      = Nessun segnale / neutro 
// ↓L / ↑S    = Swing compatto 
// 
// 📈 / 📉 / – = Segnale RSI Multi-TF 
// Δ          = Differenza RSI base vs superiore 
// ⚠️         = Avviso / warning 
// ⛔         = Blocco critico (es. chiusura impedita) 
// ⚪         = Disattivato / nessun dato 
// 🟢 OK / 🔴 BLOCCO / 🟡 Toll. = Stato filtri RSI, distanza, minProfit 
// 
// 🧪 DEBUG 
// 🧪         = Info debug tecnica (es. BE bid/pip info) 
// 📌         = Target BE calcolato 
// 
// ⏱         = Timestamp ultimo ordine 
// 🔧 / 🔒     = Configurazioni e blocchi
// 🔍         = Analisi o verifica dettagliata
// 🎚️         = Filtro o impostazione
// 🧠         = Diagnostica avanzata/intelligente
// 📋         = Log o elenco informazioni
// 🕒 / 🕓     = Timing o orario specifico
// 📝         = Note o annotazioni
// 📂         = File o salvataggio dati
// 🔑 / 🔐     = Licenza o autenticazione
// 📡         = Connessione o modalità online
// 📦         = Prodotto o pacchetto
// 🛑         = Stop o blocco trailing
// 🧹         = Pulizia o reset completo
// 🪪         = Identità o credenziali
// 
//=======================================================================================================================

using cAlgo.API;
using cAlgo.API.Indicators;
using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using System.Net.Http;
using Newtonsoft.Json;

using System.IO;

namespace cAlgo.Robots
{
    // === ENUMERAZIONI OPERATIVE ===
    public enum ExecutionMode { OnBar, OnTick }
    public enum TradeDirection { Nessuna, Long, Short }
    public enum RecoveryReferenceType { Balance, Equity, FreeMargin }

    // ==============================================================================
    // MODULO STANDARD LICENZA FURY TEAM © 2025
    // Versione: 1.0.1 - Standardizzata per tutti i prodotti
    // Data: 21/05/2025
    // Autore: Armando Brecciaroli
    // ==============================================================================

    // Definizione classe License standardizzata per la risposta JSON
    public class License
    {
        public string account_id { get; set; }
        public string expiration_date { get; set; }
        public string product_name { get; set; }
        public string license_key { get; set; }
        public string license_type { get; set; }
        public string integrity_hash { get; set; }
        public int max_verification_attempts { get; set; }
        public bool allow_offline_mode { get; set; }
    }

    // Nuova classe per deserializzare la risposta JSON degli aggiornamenti
    public class UpdateInfo
    {
        public string version { get; set; }
        public string build_date { get; set; }
        public string download_url { get; set; }
        public bool required { get; set; }
        public string message { get; set; }
        public string[] changelog { get; set; }
    }



    public enum TPMode { Standard, Hybrid, Aggressive }

    public enum OperationType
    {
        RSI_Signal,
        Recovery,
        Manual
    }

    public enum LogCategory
    {
        Recovery,
        BreakEven,
        Volume,
        DD,
        Error,
        Audit,
        Trade,
        RSI,
        Init    // Nuova categoria per inizializzazione
    }

    public struct CooldownInfo
    {
        public double RequiredPips;
        public double CurrentDistance;
        public bool IsActive;
        public string Status;
        public double VolumeMultiplier;
    }


    [Robot(TimeZone = TimeZones.UTC, AccessRights = AccessRights.FullAccess)]
    public class ProfitSentinel : Robot
    {
        // Aquisisco la data di oggi per il controllo della data di scadenza                
        public DateTime Today_Date;

        // === INFORMAZIONI BASE ===
        public const string NAME = "★ ProfitSentinel (by Fury Team) ★";
        public const string VERSION = "\nv" + BUILD_ID;
        public const string BUILD_DATE = "2025-07-18.1400";
        public const string BUILD_ID = "2.6.0";

        public const string CROSS = "\nWorks on any Forex/CFD symbol with equity/margin controls";
        public const string EMAIL = "a.brecciaroli@me.com";
        public const string TELEGRAM = "https://t.me/Obiriec";

        // [Parameter(NAME + " " + VERSION + " " + CROSS,
        [Parameter("INFO",
            Group = "★ ProfitSentinel (by Fury Team) ★" + VERSION + "\nAdvanced recovery and trailing logic cBot\nDeveloped by Armando Brecciaroli\nCopyright © 2024-2025",
            DefaultValue = TELEGRAM)]
        public string ProductInfo { get; set; }

        [Parameter("Descrizione Settings",
            Group = "Descrizione Settings",
            DefaultValue = "Default Profile v1")]
        public string DescrizioneSettings { get; set; }

        // CONTROLLO LICENZA (NUOVA)
        // Variabili stato licenza
        private bool isLicenseValid = false;
        private DateTime licenseExpirationDate = DateTime.MinValue;
        private int verificationAttempts = 0;
        private const string LICENSE_SERVER_URL = "https://obiriec.github.io/License_Server/Profit_Sentinel/";
        private const string OFFLINE_LICENSE_FILE = "ProfitSentinel_License.lic";
        private const string LICENSE_HASH_SALT = "FuryTeam2025";

        private const string LICENSE_OFFLINE_KEY = "YourLicenseOfflineKey"; // Define the constant

        // CONTROLLO AGGIORNAMENTI
        private bool updateAvailable = false;
        private string updateVersion = "";
        private string updateMessage = "";
        private string[] updateChangelog = null;
        private string updateDownloadUrl = "";
        private bool updateRequired = false;
        private const string UPDATE_SERVER_URL = "https://obiriec.github.io/Updates/Profit_Sentinel/";
        private DateTime lastUpdateCheck = DateTime.MinValue;

        // === PARAMETRI INIZIALI (AVVIO STRATEGIA) ===        
        [Parameter("Esecuzione in:", Group = "▶ MODALITA' ESECUZIONE del cBot", DefaultValue = ExecutionMode.OnBar)]
        public ExecutionMode Mode { get; set; }

        [Parameter("Apertura Posizione iniziale", Group = "▶ Avvio", DefaultValue = TradeDirection.Nessuna)]
        public TradeDirection StartTrade { get; set; }

        [Parameter("Volume iniziale (lots)", Group = "▶ Avvio", DefaultValue = 0.01, MinValue = 0.01, Step = 0.01)]
        public double VolumeInLots { get; set; }

        [Parameter("Label per nuove posizioni", Group = "▶ Avvio", DefaultValue = "")]
        public string CustomLabel { get; set; }

        [Parameter("Commento posizioni", Group = "▶ Avvio", DefaultValue = "")]
        public string CustomComment { get; set; }

        // === SICUREZZA ===
        [Parameter("Controllo Min Profit attivo", Group = "⚠ Sicurezza", DefaultValue = false)]
        public bool EnableMinProfitCheck { get; set; }

        [Parameter("Profit > Margine + (%)", Group = "⚠ Sicurezza", DefaultValue = 1.5, MinValue = 0)]
        public double MinProfitOverMarginPercent { get; set; }

        [Parameter("Mostra log riepilogo avvio", Group = "▶ Log di Avvio", DefaultValue = false)]
        public bool MostraLogAvvio { get; set; }

        [Parameter("Salva log avvio su file", Group = "▶ Log di Avvio", DefaultValue = false)]
        public bool SalvaLogAvvioFile { get; set; }

        // === GESTIONE BREAKEVEN ===
        [Parameter("Breakeven Trigger Attivo", Group = "➤ Breakeven", DefaultValue = false)]
        public bool EnableBE { get; set; }

        [Parameter("Breakeven Trigger €", Group = "➤ Breakeven", DefaultValue = 0.0, MinValue = 0.0)]
        public double BETrigger { get; set; }

        [Parameter("Drawdown %\n(rispetto al Trigger)", Group = "➤ Breakeven", DefaultValue = 90, MinValue = 0, MaxValue = 100)]
        public double TriggerDDBE { get; set; }

        // === TP FISSO ===
        [Parameter("Abilita Take Profit Fisso", Group = "➤ Take Profit Fisso", DefaultValue = false)]
        public bool EnableFixedTP { get; set; }

        [Parameter("Take Profit Fisso (€)", Group = "➤ Take Profit Fisso", DefaultValue = 0.0, MinValue = 0.0)]
        public double FixedTPAmount { get; set; }

        // === TRAILING PROFIT DINAMICO ===
        [Parameter("Abilita Trailing\nTake Profit Dinamico", Group = "➤ Trailing TP Dinamico", DefaultValue = false)]
        public bool EnableTrailingTP { get; set; }

        [Parameter("Modalità TP Dinamico", Group = "➤ Trailing TP Dinamico", DefaultValue = TPMode.Standard)]
        public TPMode TPMode { get; set; }

        [Parameter("Take Profit Start (€)", Group = "➤ Trailing TP Dinamico", DefaultValue = 0.0, MinValue = 0.0)]
        public double TPStart { get; set; }

        [Parameter("Min Pips Attivazione\n(Anti Spike)", Group = "➤ Trailing TP Dinamico", DefaultValue = 0.0, MinValue = 0.0)]
        public double MinActivationPips { get; set; }

        [Parameter("Drawdown (%)\n(rispetto al Trigger)", Group = "➤ Trailing TP Dinamico", DefaultValue = 50, MinValue = 0.0)]
        public double TPDrawdown { get; set; }

        [Parameter("TP Dinamico Adattivo (%)\n(Gestione AUTOMATICA)", Group = "➤ Trailing TP Dinamico ADATTIVO", DefaultValue = 0.0, MinValue = 0.0)]
        public double TPStartPercent { get; set; }

        [Parameter("Riferimento TP Adattivo", Group = "➤ Trailing TP Dinamico ADATTIVO", DefaultValue = RecoveryReferenceType.Equity)]
        public RecoveryReferenceType TPStartReference { get; set; }

        [Parameter("Minimo TP Start\nper Dinamico (€)\n(Anti Spike)", Group = "➤ Trailing TP Dinamico ADATTIVO", DefaultValue = 0.0, MinValue = 0.0)]
        public double TPStartMinimo { get; set; }

        [Parameter("Spread Critico (pips)\n(Anti Spike)", Group = "➤ Protezione\nTrailing TP Dinamico", DefaultValue = 2.0, MinValue = 0.0)]
        public double SpreadCriticoPips { get; set; }

        [Parameter("Spread Massimo Automatico", Group = "➤ Protezione\nTrailing TP Dinamico", DefaultValue = true)]
        public bool EnableAutoSpreadProtection { get; set; }

        [Parameter("Coefficiente Spread Auto (%)\n(del pip value)", Group = "➤ Protezione\nTrailing TP Dinamico", DefaultValue = 5.0, MinValue = 0.0)]
        public double AutoSpreadCoefficient { get; set; }

        [Parameter("Cooldown\nPost-chiusura (sec)\n(Evita riaperture immediate)", Group = "➤ Protezione\nTrailing TP Dinamico", DefaultValue = 60, MinValue = 0)]
        public int CooldownAfterCloseSeconds { get; set; }

        [Parameter("Delay aggiornamento\nTP dinamico (sec)", Group = "➤ Protezione\nTrailing TP Dinamico", DefaultValue = 5, MinValue = 0)]
        public int TrailingTPUpdateDelaySec { get; set; }

        // === RECOVERY PRINCIPALE ===
        [Parameter("Abilita Recovery", Group = "➤ Recovery", DefaultValue = false)]
        public bool EnableRecovery { get; set; }

        [Parameter("Lotto massimo consentito", Group = "➤ Recovery", DefaultValue = 1.0, MinValue = 0.01)]
        public double MaxAllowedLots { get; set; }

        [Parameter("Recovery Moltiplicatore", Group = "➤ Recovery", DefaultValue = 1.5, MinValue = 1.0)]
        public double RecoveryMultiplier { get; set; }

        [Parameter("Max Recovery Positions", Group = "➤ Recovery", DefaultValue = 3, MinValue = 1)]
        public int MaxRecoveryTrades { get; set; }

        [Parameter("Recovery Trigger (%)", Group = "➤ Recovery", DefaultValue = 2.0, MinValue = 0.0)]
        public double RecoveryTriggerPercent { get; set; }

        [Parameter("Fattore di Potenziamento DD (%)\nper successivi Recovery", Group = "➤ Recovery", DefaultValue = 2.0, MinValue = 1.0)]
        public double MinDDIncreasePercent { get; set; }

        [Parameter("Fattore Moltiplicativo DD",
          Group = "➤ Recovery", DefaultValue = 1.5, MinValue = 1.0)]
        public double DDMultiplier { get; set; }

        // Aggiungere l'enum per i tipi di calcolo
        public enum DDCalculationType
        {
            Conservativo,    // Usa radice quadrata (più conservativo)
            Enhanced,    // Usa radice cubica (medio)
            Aggressive   // Usa moltiplicatore diretto (più aggressivo)
        }

        [Parameter("Tipo Calcolo DD Recovery", Group = "➤ Recovery", DefaultValue = DDCalculationType.Conservativo)]
        public DDCalculationType DDCalcType { get; set; }

        [Parameter("Recovery Reference", Group = "➤ Recovery", DefaultValue = RecoveryReferenceType.Equity)]
        public RecoveryReferenceType RecoveryReference { get; set; }

        // === ENUMERAZIONI OPERATIVE EXTRA ===
        public enum RecoveryMode
        {
            Standard,
            Bilanciato,
            Aggressivo
        }

        [Parameter("Recovery Mode", Group = "➤ Recovery", DefaultValue = RecoveryMode.Standard)]
        public RecoveryMode SelectedRecoveryMode { get; set; }

        [Parameter("Abilita Trailing StopLoss per Recovery", Group = "➤ Recovery TSL", DefaultValue = false)]
        public bool EnableRecoveryTrailingStopLoss { get; set; }

        [Parameter("Trigger Trailing SL (€)", Group = "➤ Recovery TSL", DefaultValue = 0.0, MinValue = 0.0)]
        public double RecoveryTrailingStopLossTriggerEuro { get; set; }

        [Parameter("Distanza Trailing SL (%)", Group = "➤ Recovery TSL", DefaultValue = 50, MinValue = 0.0, MaxValue = 100)]
        public double RecoveryTrailingStopLossDistancePercent { get; set; }

        // === FILTRI RECOVERY ===
        [Parameter("Abilita filtro distanza (posizione precedente)", Group = "📐 Recovery Filters", DefaultValue = false)]
        public bool EnableDistanceFilter { get; set; }

        [Parameter("Distanza minima dall'ultima posizione (pips)", Group = "📐 Recovery Filters", DefaultValue = 1.0, MinValue = 0.0)]
        public double MinDistancePips { get; set; }

        [Parameter("Movimento minimo richiesto tra Recovery (pips)\nCooldown", Group = "📐 Recovery Filters", DefaultValue = 1.0, MinValue = 0.0)]
        public double RecoveryCooldownPips { get; set; }

        [Parameter("Min distanza tra BE e Prezzo (pips)", Group = "📐 Recovery Filters", DefaultValue = 1.0, MinValue = 0.0)]
        public double MinDistanceBEpips { get; set; }

        [Parameter("Abilita filtro RSI (per Recovery)", Group = "📐 Recovery Filters", DefaultValue = false)]
        public bool EnableRSIFilter { get; set; }

        [Parameter("Periodo RSI (calcolo)", Group = "📐 Recovery Filters", DefaultValue = 14, MinValue = 1)]
        public int RSIPeriod { get; set; }

        [Parameter("RSI minimo per aprire Buy", Group = "📐 Recovery Filters", DefaultValue = 30, MinValue = 0.0, MaxValue = 50)]
        public double RSIMinBuy { get; set; }

        [Parameter("RSI massimo per aprire Sell", Group = "📐 Recovery Filters", DefaultValue = 70, MinValue = 50, MaxValue = 100)]
        public double RSIMaxSell { get; set; }

        // === FILTRO SWING AVANZATO (Mini ZigZag Style) ===
        [Parameter("Usa filtro Swing per Recovery", Group = "📐 Recovery Filters", DefaultValue = false)]
        public bool EnableSwingFilter { get; set; }

        [Parameter("Swing Depth (barre)", Group = "📐 Recovery Filters", DefaultValue = 10, MinValue = 3)]
        public int SwingDepthBars { get; set; }

        [Parameter("Abilita Cooldown Dinamico", Group = "📐 Recovery Filters", DefaultValue = false)]
        public bool EnableDynamicCooldown { get; set; }

        // === RECOVERY AVANZATO ===
        [Parameter("Recovery Adattivo Volatilità", Group = "➤ Recovery Avanzato", DefaultValue = false)]
        public bool EnableAdaptiveRecovery { get; set; }

        [Parameter("Sensibilità alla volatilità (%)", Group = "➤ Recovery Avanzato", DefaultValue = 50, MinValue = 0.0, MaxValue = 100)]
        public double VolatilitySensitivityPercent { get; set; }

        [Parameter("Fattore di smorzamento progressione", Group = "➤ Recovery Avanzato", DefaultValue = 0.2, MinValue = 0.0, MaxValue = 1.0, Step = 0.1)]
        public double ProgressionDampeningFactor { get; set; }

        [Parameter("Protezione liquidità mercato", Group = "➤ Recovery Avanzato", DefaultValue = false)]
        public bool EnableLiquidityProtection { get; set; }

        [Parameter("Adatta recovery a orari di mercato", Group = "➤ Recovery Avanzato", DefaultValue = false)]
        public bool EnableTimeBasedRecovery { get; set; }

        [Parameter("Abilita recovery esteso", Group = "➤ Recovery Avanzato", DefaultValue = false)]
        public bool EnableExtendedRecovery { get; set; }

        [Parameter("Soglia critica drawdown (%)", Group = "➤ Recovery Avanzato", DefaultValue = 75.0, MinValue = 10.0)]
        public double CriticalDrawdownThreshold { get; set; }

        // === SICUREZZA AVANZATA ===
        [Parameter("Free Margin minimo richiesto (€)", Group = "⚠ Sicurezza Avanzata", DefaultValue = 0.0, MinValue = 0.0)]
        public double FreeMarginMinimoEuro { get; set; }

        [Parameter("Livello minimo di margine (%)", Group = "⚠ Sicurezza Avanzata", DefaultValue = 0.0, MinValue = 0.0)]
        public double MinMarginLevelPercent { get; set; }

        [Parameter("SafeMode Recovery On FreeMargin (€)", Group = "⚠ Sicurezza Avanzata", DefaultValue = 0.0, MinValue = 0.0)]
        public double SafeModeRecoveryFreeMargin { get; set; }

        [Parameter("Attiva diagnostica console debug", Group = "⚠ Log di Debug", DefaultValue = false)]
        public bool EnableDebugLogs { get; set; }

        // === HUD VISIVO ===
        [Parameter("Mostra HUD a schermo", Group = "🎛️ HUD", DefaultValue = true)]
        public bool ShowHUD { get; set; }

        [Parameter("Mostra diagnostica RSI live", Group = "🎛️ HUD", DefaultValue = true)]
        public bool ShowRSIDiagnostics { get; set; }

        [Parameter("Mostra linea Breakeven", Group = "🎛️ HUD", DefaultValue = true)]
        public bool ShowBreakEvenLine { get; set; }

        [Parameter("Mostra Slider BreakEven", Group = "🎛️ HUD", DefaultValue = true)]
        public bool ShowBreakEvenSlider { get; set; }

        [Parameter("Barre analisi storico per suggerimento", Group = "🎛️ HUD", DefaultValue = 50, MinValue =0)]
        public int BarreAnalisiSuggerimento { get; set; }

        [Parameter("Mostra info BreakEven HUD", Group = "🎛️ HUD", DefaultValue = true)]
        public bool ShowBreakEvenHUDInfo { get; set; }

        [Parameter("HUD Compatto (naming abbreviato)", Group = "🎛️ HUD", DefaultValue = false)]
        public bool HUDCompatto { get; set; }

        [Parameter("HUD Vertical", Group = "🎛️ HUD", DefaultValue = VerticalAlignment.Top)]
        public VerticalAlignment HUDVertical { get; set; }

        [Parameter("HUD Horizontal", Group = "🎛️ HUD", DefaultValue = HorizontalAlignment.Left)]
        public HorizontalAlignment HUDHorizontal { get; set; }

        [Parameter("Nascondi info licenza dopo (secondi)", Group = "🛡 Display License", DefaultValue = 30)]
        public int LicenseInfoDisplaySeconds { get; set; }

        // === HUD IN SEZIONI ===
        [Parameter("Abilita HUD Operativo", Group = "🎛️ HUD Avanzato", DefaultValue = true)]
        public bool MostraHUDOperativo { get; set; }

        [Parameter("Vertical HUD Operativo", Group = "🎛️ HUD Avanzato", DefaultValue = VerticalAlignment.Top)]
        public VerticalAlignment HUDOperativoVertical { get; set; }

        [Parameter("Orizzontale HUD Operativo", Group = "🎛️ HUD Avanzato", DefaultValue = HorizontalAlignment.Left)]
        public HorizontalAlignment HUDOperativoHorizontal { get; set; }

        [Parameter("Abilita HUD Diagnostico RSI", Group = "🎛️ HUD Avanzato", DefaultValue = true)]
        public bool MostraHUDDiagnosticoRSI { get; set; }

        [Parameter("Vertical HUD RSI", Group = "🎛️ HUD Avanzato", DefaultValue = VerticalAlignment.Top)]
        public VerticalAlignment HUDRSIVertical { get; set; }

        [Parameter("Orizzontale HUD RSI", Group = "🎛️ HUD Avanzato", DefaultValue = HorizontalAlignment.Right)]
        public HorizontalAlignment HUDRSIHorizontal { get; set; }

        // === DIAGNOSTICA MULTI-SIMBOLO ===
        [Parameter("Mostra Diagnostica Simboli", Group = "🎛️ HUD Avanzato", DefaultValue = false)]
        public bool MostraDiagnosticaSimboli { get; set; }

        // ▶️ Gruppo: ★ HUD Settings ★
        [Parameter("Colore SFONDO HUD Operativo", Group = "★ HUD Settings ★", DefaultValue = "DE001B30")]
        public Color HUDOperativoBackgroundColor { get; set; }

        [Parameter("Colore SFONDO HUD RSI", Group = "★ HUD Settings ★", DefaultValue = "E6371851")]
        public Color HUDRSIBackgroundColor { get; set; }

        // === HUD COLOR CUSTOM (con parametri tipo Color nativo RGBA) ===
        [Parameter("HUD Loss Hard (< -2%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFFF0000")]
        public Color HUDColorLossHard { get; set; }

        [Parameter("HUD Loss Medium (< -1%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFFF4646")]
        public Color HUDColorLossMed { get; set; }

        [Parameter("HUD Loss Light (< -0.3%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFFF8C00")]
        public Color HUDColorLossLight { get; set; }

        [Parameter("HUD Near Zero (< 0%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFFFFFFF")]
        public Color HUDColorZero { get; set; }

        [Parameter("HUD Gain Light (< 0.3%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFDCFF66")]
        public Color HUDColorGainLight { get; set; }

        [Parameter("HUD Gain Medium (< 0.7%)", Group = "🎨 HUD Color Custom", DefaultValue = "FFA0FF90")]
        public Color HUDColorGainMed { get; set; }

        [Parameter("HUD Gain Good (< 1.5%)", Group = "🎨 HUD Color Custom", DefaultValue = "FF64B4FF")]
        public Color HUDColorGainGood { get; set; }

        [Parameter("HUD Gain High (> 1.5%)", Group = "🎨 HUD Color Custom", DefaultValue = "FF00A0FF")]
        public Color HUDColorGainHigh { get; set; }

        [Parameter("Moltiplicatore Colore HUD", Group = "🎨 HUD Color Custom", DefaultValue = 2.0, MinValue = 0.0)]
        public double HUDColorMultiplier { get; set; }

        // === 🔁 SEGNALI OPERATIVI - COMUNI ===
        [Parameter("Abilita Segnali Operativi RSI", Group = "➤ Segnali Operativi - Comuni", DefaultValue = true)]
        public bool EnableSignalRSI { get; set; }

        public enum ModalitaOperativaRSI
        {
            TrendFollowing,
            Contrarian
        }

        [Parameter("➤ Modalità Operativa RSI", Group = "➤ Segnali Operativi - Comuni", DefaultValue = ModalitaOperativaRSI.Contrarian)]
        public ModalitaOperativaRSI ModalitaRSI { get; set; }

        public enum ExecutionModeEnum
        {
            SoloSegnali,
            SoloOrdini,
            Entrambi
        }

        [Parameter("Modalità esecuzione segnali/ordini", Group = "➤ Segnali Operativi - Comuni", DefaultValue = ExecutionModeEnum.SoloSegnali)]
        public ExecutionModeEnum SignalExecutionMode { get; set; }

        [Parameter("Lotti per ordine (LONG/SHORT)", Group = "➤ Segnali Operativi - Comuni", DefaultValue = 0.01, MinValue = 0.01, Step = 0.01)]
        public double SignalLotSize { get; set; }

        [Parameter("SL segnale (pips)", Group = "➤ Segnali Operativi - Comuni", DefaultValue = 0.0, MinValue = 0.0, Step = 0.01)]
        public double SignalStopLossPips { get; set; }

        [Parameter("TP segnale (pips)", Group = "➤ Segnali Operativi - Comuni", DefaultValue = 0.0, MinValue = 0.0, Step = 0.01)]
        public double SignalTakeProfitPips { get; set; }

        [Parameter("Cooldown minimo tra segnali (minuti)", Group = "➤ Segnali Operativi - Comuni", DefaultValue = 30, MinValue = 0)]
        public int SignalCooldownMinutes { get; set; }


        [Parameter("Cancella etichette RSI automaticamente", Group = "🎛️ Gestione Etichette Segnali", DefaultValue = true)]
        public bool EnableAutoDeleteRSILabels { get; set; }

        // Enum per il metodo di cancellazione
        public enum DeleteLabelsMode
        {
            DopoNBarre,
            DopoNMinuti
        }

        [Parameter("Metodo cancellazione etichette", Group = "🎛️ Gestione Etichette Segnali", DefaultValue = DeleteLabelsMode.DopoNBarre)]
        public DeleteLabelsMode LabelsDeleteMode { get; set; }

        [Parameter("Numero barre prima della cancellazione", Group = "🎛️ Gestione Etichette Segnali", DefaultValue = 5, MinValue = 1)]
        public int BarsBeforeDelete { get; set; }

        [Parameter("Minuti prima della cancellazione", Group = "🎛️ Gestione Etichette Segnali", DefaultValue = 30, MinValue = 1)]
        public int MinutesBeforeDelete { get; set; }

        [Parameter("Periodo RSI Base", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 14, MinValue = 1)]
        public int RsiPeriodBase { get; set; }

        [Parameter("RSI Base - Livello Ipervenduto", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 30, MinValue = 0.0, MaxValue = 50)]
        public double RsiBaseOversold { get; set; }

        [Parameter("RSI Base - Livello Ipercomprato", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 70, MinValue = 50, MaxValue = 100)]
        public double RsiBaseOverbought { get; set; }

        [Parameter("Timeframe RSI Superiore", Group = "➤ Segnali RSI - Multi-TF")]
        public TimeFrame RsiHigherTimeFrame { get; set; }

        [Parameter("Periodo RSI Superiore", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 14, MinValue = 1)]
        public int RsiPeriodHigher { get; set; }

        [Parameter("RSI Superiore - Livello Ipervenduto", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 30, MinValue = 0.0, MaxValue = 50)]
        public double RsiHigherOversold { get; set; }

        [Parameter("RSI Superiore - Livello Ipercomprato", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 70, MinValue = 50, MaxValue = 100)]
        public double RsiHigherOverbought { get; set; }

        [Parameter("✔ Attiva filtro delta minimo", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = true)]
        public bool AbilitaFiltroMinDeltaRSI { get; set; }

        [Parameter("Delta minimo RSI (Base vs Superiore)", Group = "➤ Segnali RSI - Multi-TF", DefaultValue = 5.0, MinValue = 0.0)]
        public double MinRsiDelta { get; set; }

        [Obsolete("Usa AbilitaFiltroConsistenzaRSI invece")]
        [Parameter("✔ Attiva filtro persistenza", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = true)]
        public bool AbilitaFiltroPersistenzaRSI { get; set; }

        [Obsolete("Usa AbilitaFiltroConsistenzaRSI invece")]
        [Parameter("✔ Richiedi persistenza segnale (barre)", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = 1, MinValue = 0)]
        public int MinBarrePersistenzaSegnale { get; set; }

        /*[Obsolete("Usa AbilitaFiltroConsistenzaRSI invece")]
        [Parameter("✔ Attiva barre conferma segnale", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = false)]*/
        public bool AbilitaBarreConfermaSegnale = false;

        /* [Obsolete("Usa AbilitaFiltroConsistenzaRSI invece")]
         [Parameter("✔ Barre conferma segnale", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = 1, MinValue = 0)]*/
        public int MinBarreConfermaSegnale = 0;

        [Parameter("✔ Filtro consistenza segnale", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = true)]
        public bool AbilitaFiltroConsistenzaRSI { get; set; }

        [Parameter("Persistenza richiesta (barre)", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = 1, MinValue = 0)]
        public int BarrePersistenzaRichieste { get; set; }

        public enum TipoConsistenzaRSI
        {
            Standard,    // Controlla solo validità di base
            Avanzato,    // Richiede che il valore RSI continui nella direzione corretta
            Rigoroso     // Richiede condizioni più stringenti per segnali molto affidabili
        }

        [Parameter("Tipo validazione persistenza", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = TipoConsistenzaRSI.Standard)]
        public TipoConsistenzaRSI TipoValidazionePersistenza { get; set; }

        // === RSI VS EMA FILTER ===
        [Parameter("✅ Attiva filtro EMA su segnali RSI", Group = "➤ Filtro EMA per RSI\n    Aggiungere sul grafico l'indicatore 'EMA su TF'\n    con gli stessi settings del cBot.", DefaultValue = false)]
        public bool EnableEmaFilter { get; set; }

        [Parameter("Periodo EMA", Group = "➤ Parametri Filtro EMA per RSI", DefaultValue = 200, MinValue = 5)]
        public int EmaPeriod { get; set; }

        [Parameter("⚠️ Forza controllo EMA (blocca aperture non conformi)", Group = "➤ Parametri Filtro EMA per RSI", DefaultValue = false)]
        public bool ForceEmaCheck { get; set; }

        [Parameter("Timeframe EMA", Group = "➤ Parametri Filtro EMA per RSI")]
        public TimeFrame EmaTimeFrame { get; set; }

        public enum TimingAperturaPosizione
        {
            AllaChiusuraBarraConferma,         // Esegue subito alla chiusura della barra che conferma
            AllaChiusuraBarraSuccessiva        // Esegue solo alla chiusura della barra successiva alla conferma
        }

        [Parameter("🕒 Timing apertura posizione (post segnale)", Group = "➤ Segnali RSI - Filtro Qualità")]
        public TimingAperturaPosizione ModalitaTimingApertura { get; set; }

        [Parameter("✔ Attiva filtro delta crescente", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = false)]
        public bool AbilitaFiltroDeltaCrescenteRSI { get; set; }

        [Parameter("✔ Attiva filtro curvatura RSI Base\nUsare con TF molto lenti\n(Daily, Weekly, Monthly)", Group = "➤ Segnali RSI - Filtro Qualità", DefaultValue = false)]
        public bool AbilitaFiltroCurvaturaRSIBase { get; set; }

        // === FORZATURA APERTURA POSIZIONI ===
        [Parameter("Forza segnale RSI per TEST DEBUG", DefaultValue = false, Group = "➤ Debug")]
        public bool ForzaSegnaleRSI { get; set; }

        // === SUPER MASTER OPTIONS ===
        [Parameter("➤ [EXTRA] TP dinamico su ATR", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = false)]
        public bool EnableVolatilityTrailingTP { get; set; }

        [Parameter("Periodo ATR (per trailing)", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = 14, MinValue = 1)]
        public int ATRPeriod { get; set; }

        [Parameter("➤ [EXTRA] Safe Mode: disattiva Recovery < FreeMargin", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = false)]
        public bool EnableSafeModeMarginProtection { get; set; }

        [Parameter("SafeMode: FreeMargin minimo (€)", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = 300.0, MinValue = 0.0)]
        public double SafeModeMinFreeMargin { get; set; }

        [Parameter("➤ [EXTRA] Closing-Only Mode attivo", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = false)]
        public bool EnableClosingOnlyMode { get; set; }

        [Parameter("➤ [EXTRA] Protezione Flash Crash attiva", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = false)]
        public bool EnableFlashCrashProtection { get; set; }

        [Parameter("Protezione Flash: soglia movimento (pips)", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = 50, MinValue = 0.0)]
        public double FlashCrashPips { get; set; }

        [Parameter("Protezione Flash: durata pausa (secondi)", Group = "🚀 Super Master Options\nAncora non operative!", DefaultValue = 300.0, MinValue = 1)]
        public int FlashCrashPauseSeconds { get; set; }

        // === VARIABILI INTERNE ===
        private const string HUD_ID = "ProfitSentinelHUD";
        private const string BE_LINE = "BreakEvenLine";
        private const string HUD_SWITCH_BUTTON = "HUDSwitchToggle";
        private RelativeStrengthIndex rsi;
        private double maxTP = 0, maxFixedTP = 0, maxEquity = 0;
        private int recoveryCount = 0;
        private double actualDDpercent = 0.0;
        private double lastRecoveryDrawdown = 0.0;
        private double lastRecoveryReferenceValue = 0.0;
        private bool recoveryCooldownActive = false;
        private double lastRecoveryPrice = 0.0;
        private bool triggerBreakevenAttivo = false;
        private double maxProfitAfterTrigger = 0;
        private double lastTPDynamicProgress = 0;
        private DateTime lastTPDynamicUpdate = DateTime.MinValue;
        private double lastProfitHUD = double.MinValue;
        private double lastRecoveryDDHUD = double.MinValue;
        private int lastRecoveryCountHUD = -1;
        private double lastBreakEvenHUD = 0.0;
        private int lastPosizioniAperteHUD = -1;
        private double fixedBreakEvenProfitThreshold = 0.0;

        private bool _pendingPositionExecution = false;
        private DateTime _lastPositionOpenTime = DateTime.MinValue;
        private readonly object _positionLock = new object();

        // Modulo per recovery esteso
        private ExtendedRecoveryModule _extendedRecoveryModule;

        // Aggiungi alla sezione delle variabili private
        private ExponentialMovingAverage ema;
        private string emaStatus = "";
        private Color emaStatusColor = Color.Gray;

        // Classe unificata per tracciare sia posizioni TSL attive che chiuse
        private class TslPositionData
        {
            // Proprietà comuni
            public int PositionId { get; set; }
            public string Label { get; set; }
            public double Volume { get; set; }
            public TradeType Direction { get; set; }

            // Proprietà per il tracking attivo
            public bool IsActive { get; set; } = false;
            public double MaxProfit { get; set; } = 0;
            public double StopLossValue { get; set; } = 0;

            // Proprietà per posizioni chiuse
            public double InitialDrawdown { get; set; }
            public double ReferenceValue { get; set; }  // Balance/Equity/FreeMargin al momento dell'apertura
            public DateTime? CloseTime { get; set; }

            // Costruttore per posizioni attive
            public TslPositionData(int positionId, string label)
            {
                PositionId = positionId;
                Label = label;
                IsActive = false;
                CloseTime = null;
            }

            // Costruttore per posizioni chiuse
            public TslPositionData(string label, double initialDrawdown, double referenceValue,
                                 TradeType direction, double volume, DateTime closeTime)
            {
                Label = label;
                InitialDrawdown = initialDrawdown;
                ReferenceValue = referenceValue;
                Direction = direction;
                Volume = volume;
                CloseTime = closeTime;
                IsActive = false;
            }

            // Funzione di conversione da tracking attivo a posizione chiusa
            public void MarkAsClosed(DateTime closeTime)
            {
                CloseTime = closeTime;
                IsActive = false;
            }

            // Funzione per verificare se è una posizione chiusa
            public bool IsClosed()
            {
                return CloseTime.HasValue;
            }
        }

        // Classe per tenere traccia delle posizioni chiuse da TSL
        private class TSLClosedPosition
        {
            public string Label { get; set; }
            public double InitialDrawdown { get; set; }
            public double ReferenceValue { get; set; }
            public TradeType Direction { get; set; }
            public double Volume { get; set; }
            public DateTime CloseTime { get; set; }
        }

        // Struttura per tenere traccia delle etichette
        private class RSILabel
        {
            public string Tag { get; set; }
            public DateTime CreationTime { get; set; }
            public int CreationBarIndex { get; set; }
        }

        // Lista per memorizzare le etichette
        private List<RSILabel> rsiLabels = new List<RSILabel>();
        private Border _hudOperativoPanel;
        private Border _hudRSIPanel;

        // 🕒 Timestamp segnale in attesa conferma
        private DateTime? pendingSignalLongTime = null;
        private DateTime? pendingSignalShortTime = null;
        private string ultimoMessaggioOrdine = string.Empty;
        private DateTime ultimoMessaggioTime = DateTime.MinValue;
        private bool isClosing = false;
        private DateTime lastForcedCloseTime = DateTime.MinValue;
        private int cooldownAfterCloseSeconds; // durata blocco (modificabile)
        private DateTime lastTrailingUpdateTime = DateTime.MinValue;
        private string hudRsiInfoLong = "";
        private string hudRsiInfoShort = "";
        private string trailingTPWarningHUD = string.Empty;
        private double trailingTPLastProfit = 0;
        private double trailingTPExpectedMin = 0;
        private Queue<double> storicoRsiBaseLong = new Queue<double>();
        private Queue<double> storicoRsiBaseShort = new Queue<double>();
        private Queue<double> storicoDeltaLong = new Queue<double>();
        private Queue<double> storicoDeltaShort = new Queue<double>();
        private Queue<bool> storicoSegnaleValidoLong = new Queue<bool>();
        private Queue<bool> storicoSegnaleValidoShort = new Queue<bool>();
        private string lastDetectedSwingType = "";
        private const int MaxStoricoRSI = 10;
        private string hudRsiQualitaLong = "";
        private string hudRsiQualitaShort = "";

        // Aggiungi questo campo alla classe RsiQualitaDiagnostica
        public bool FiltroEmaSuperato;

        public class RsiQualitaDiagnostica
        {
            public bool SegnaleBaseValido;
            public bool FiltroPersistenzaSuperato;
            public bool FiltroDeltaCrescenteSuperato;
            public bool FiltroCurvaturaSuperato;
            public bool FiltroEmaSuperato;  // Proprietà aggiunta qui
            public double Delta { get; set; }

            public bool SegnaleFinale { get; set; }
        }

        // Variabili temporanee per gestione timing esecuzione segnale RSI
        private DateTime? pendingExecutionLongTime = null;
        private DateTime? pendingExecutionShortTime = null;
        private DateTime lastSignalLongTime = DateTime.MinValue;
        private DateTime lastSignalShortTime = DateTime.MinValue;

        // Timestamp ultimo segnale per cooldown (LONG/SHORT gestiti insieme)
        DateTime ultimoSegnaleLong = DateTime.MinValue;
        DateTime ultimoSegnaleShort = DateTime.MinValue;

        // Mappa enum in flag booleani per compatibilità con codice esistente
        private bool IsSignalEnabled => SignalExecutionMode == ExecutionModeEnum.SoloSegnali || SignalExecutionMode == ExecutionModeEnum.Entrambi;
        private bool IsOrderEnabled => SignalExecutionMode == ExecutionModeEnum.SoloOrdini || SignalExecutionMode == ExecutionModeEnum.Entrambi;

        // === VARIABILI INTERNE – SEGNALI RSI MULTI-TF (LONG) ===
        private double rsiBaseValueLong;
        private double rsiSuperiorValueLong;
        private DateTime lastSignalTimeLong = DateTime.MinValue;

        // === VARIABILI INTERNE – SEGNALI RSI MULTI-TF (SHORT) ===
        private double rsiBaseValueShort;
        private double rsiSuperiorValueShort;
        private DateTime lastSignalTimeShort = DateTime.MinValue;

        // ======================================================================
        // BLOCCO 1 - Variabili aggiuntive per il calcolo del TP Dinamico (da aggiungere alla sezione variabili)
        // ======================================================================
        private double lastCalculatedMinProfitToClose = 0;
        private string lastTPDynamicStatus = "";
        private Color lastTPDynamicColor = Color.Gray;

        // === VARIABILE STATO SWING ===
        private DateTime ultimoLogDiagnostica = DateTime.MinValue;
        private int ultimoNumeroAnomalie = -1;
        private int confermaBarreLong = 0;
        private int confermaBarreShort = 0;
        private const string TP_DYNAMIC_LINE = "TPDynamicLine";
        private const string TP_DYNAMIC_LABEL = "TPDynamicLabel";
        private double lastLoggedSpread = 0;
        private int consecutiveValidLong = 0;
        private int consecutiveValidShort = 0;
        private DateTime lastValidatedBarTimeLong = DateTime.MinValue;
        private DateTime lastValidatedBarTimeShort = DateTime.MinValue;
        private bool tpDinamicoAttivato = false;
        private void ResetTPDynamicValues()
        {
            tpDinamicoAttivato = false;
            maxTP = 0;
            Print("🔄 Valori TP Dinamico resettati");
        }

        private Queue<double> spreadHistory = new Queue<double>(100);
        private DateTime lastSpreadRecordTime = DateTime.MinValue;
        private double averageSpreadPips = 0;
        private int spreadSampleCount = 0;

        private bool lastCheckSpreadResult = true;
        private double lastCheckSpreadValue = 0;

        // Variabili interne per il trailing SL
        private double lastTrailingStopLossPrice = 0;
        private bool trailingStopLossAttivo = false;
        private const string TRAILING_SL_LINE = "TrailingStopLossLine";

        // Dizionario per memorizzare i tracker delle posizioni
        private Dictionary<int, TslPositionData> tslPositionTrackers = new Dictionary<int, TslPositionData>();

        // Aggiungi come variabile di classe per tracciare quali posizioni sono state chiuse da TSL
        // private HashSet<string> tslClosedPositionLabels = new HashSet<string>();
        private List<TslPositionData> tslClosedPositions = new List<TslPositionData>();


        // VARIABILI PER LA GESTIONE DELLA LICENZA
        // Aggiungi queste variabili nella sezione delle variabili private
        private DateTime _licenseInfoDisplayTime = DateTime.MinValue;
        private bool _licenseInfoDisplayed = false;

        // Aggiungi questo metodo alla classe
        private (bool isPriceAboveEma, string recommendation, Color recommendationColor) CheckPriceAgainstEMA()
        {
            if (!EnableEmaFilter || ema == null)
                return (true, "", Color.Gray); // Default permissivo se il filtro è disattivato

            try
            {
                // Ottieni l'ultimo valore dell'EMA
                double emaValue = ema.Result.LastValue;

                // Controlla se il prezzo è sopra o sotto l'EMA
                bool isPriceAboveEma = Symbol.Bid > emaValue;

                // Prepara le raccomandazioni in base alla modalità RSI
                string recommendation;
                Color recommendationColor;

                if (ModalitaRSI == ModalitaOperativaRSI.Contrarian)
                {
                    if (isPriceAboveEma)
                    {
                        // Prezzo sopra EMA in modalità Contrarian
                        recommendation = "Prezzo > EMA: SHORT naturale, LONG consigliato";
                        recommendationColor = Color.LightBlue;
                    }
                    else
                    {
                        // Prezzo sotto EMA in modalità Contrarian
                        recommendation = "Prezzo < EMA: LONG naturale, SHORT consigliato";
                        recommendationColor = Color.LightCoral;
                    }
                }
                else // TrendFollowing
                {
                    if (isPriceAboveEma)
                    {
                        // Prezzo sopra EMA in modalità TrendFollowing
                        recommendation = "Prezzo > EMA: LONG consigliato (trend rialzista)";
                        recommendationColor = Color.LightGreen;
                    }
                    else
                    {
                        // Prezzo sotto EMA in modalità TrendFollowing
                        recommendation = "Prezzo < EMA: SHORT consigliato (trend ribassista)";
                        recommendationColor = Color.LightPink;
                    }
                }

                return (isPriceAboveEma, recommendation, recommendationColor);
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in CheckPriceAgainstEMA: {ex.Message}");
                return (true, "Errore verifica EMA", Color.Red);
            }
        }

        // === FUNZIONE DEBUG CONDITIONAL ===
        // Alias per retrocompatibilità
        private void DebugLog(string message)
        {
            LogDebug(LogCategory.Audit, message);
        }

        private void LogDebug(LogCategory category, string message, bool forceLog = false)
        {
            if (!EnableDebugLogs && !forceLog) return;
            Print($"[{category}] {DateTime.Now:HH:mm:ss.fff} | {message}");
        }

        //==========================================================================
        // 📋 PARAMETRI UTENTE — GUIDA RAPIDA
        //==========================================================================
        //
        // ▶ Avvio
        //   - StartTrade: direzione iniziale (Long, Short, Nessuna).
        //   - Mode: modalità di esecuzione (OnBar, OnTick).
        //   - VolumeInLots: volume iniziale.
        //
        // ➤ Take Profit Fisso
        //   - EnableFixedTP: attiva chiusura con profitto fisso (€).
        //   - FixedTPAmount: soglia di profitto (€).
        //   - FixedTPDrawdownPercent: drawdown massimo prima di chiusura.
        //
        // ➤ Trailing TP Dinamico
        //   - EnableTrailingTP: attiva trailing TP.
        //   - TPStart: profitto minimo per attivare trailing (€).
        //   - TPDrawdown: % drawdown tollerato.
        //
        // ➤ Recovery
        //   - EnableRecovery: attiva sistema di recupero.
        //   - RecoveryMultiplier: moltiplicatore dei volumi.
        //   - MaxRecoveryTrades: numero massimo di recovery.
        //   - RecoveryTriggerPercent: drawdown (%) per triggerare recovery.
        //   - RecoveryReference: base del DD (Balance, Equity, FreeMargin).
        //
        // 📐 Recovery Filters
        //   - EnableDistanceFilter: attiva filtro distanza pips.
        //   - MinDistancePips: distanza minima in pips.
        //   - RecoveryCooldownPips: movimento minimo richiesto per nuovo recovery.
        //   - MinDDIncreasePercent: peggioramento DD richiesto tra recovery.
        //   - MinDistanceBEpips: distanza minima tra prezzo e BreakEven.
        //   - EnableRSIFilter + RSI Settings: filtri RSI Buy/Sell.
        //
        // ⚠ Sicurezza
        //   - EnableMinProfitCheck: richiede profitto superiore al margine usato.
        //   - MinProfitOverMarginPercent: % profitto minimo su margine.
        //
        // ⚠ Sicurezza Avanzata
        //   - FreeMarginMinimoEuro: minimo Free Margin richiesto (€).
        //   - MinMarginLevelPercent: minimo Margin Level richiesto (%).
        //
        // 🎛️ HUD
        //   - ShowHUD: attiva visualizzazione HUD.
        //   - ShowBreakEvenLine: linea BE sul grafico.
        //   - HUDVertical / HUDHorizontal: posizione del testo HUD.
        //
        //==========================================================================

        //==========================================================================
        // 🚀 — AVVIO STRATEGIA E INIZIALIZZAZIONE
        //==========================================================================
        protected override void OnStart()
        {
            InitializeBackwardCompatibility();

            Today_Date = Server.Time;

            // Verifica licenza con il sistema standardizzato
            if (!VerifyLicense(true))
            {
                Print("❌ Esecuzione interrotta: licenza non valida");
                return;
            }

            // Verifica aggiornamenti
            CheckForUpdates();

            // Aggiorna la storia degli spread
            UpdateSpreadHistory();

            storicoRsiBaseLong = new Queue<double>();
            storicoRsiBaseShort = new Queue<double>();
            storicoDeltaLong = new Queue<double>();
            storicoDeltaShort = new Queue<double>();
            storicoSegnaleValidoLong = new Queue<bool>();
            storicoSegnaleValidoShort = new Queue<bool>();
            recoveryCount = 0;
            recoveryCooldownActive = false;
            lastRecoveryPrice = 0.0;
            lastRecoveryDrawdown = 0.0;
            lastDetectedSwingType = "";
            lastRecoveryReferenceValue = GetRecoveryReferenceValue();

            // Verifica e adatta i volumi minimi per il simbolo
            double symbolMinLots = GetMinimumAllowedLots();

            if (VolumeInLots < symbolMinLots)
            {
                Print($"⚠️ ATTENZIONE: Volume iniziale {VolumeInLots:F2} non valido per {Symbol.Name}");
                Print($"➤ Volume minimo consentito: {symbolMinLots:F2} lots");
                VolumeInLots = symbolMinLots;
            }

            if (SignalLotSize < symbolMinLots)
            {
                Print($"⚠️ ATTENZIONE: Volume segnali {SignalLotSize:F2} non valido per {Symbol.Name}");
                Print($"➤ Volume minimo consentito: {symbolMinLots:F2} lots");
                SignalLotSize = symbolMinLots;
            }

            // Apertura automatica di posizione se richiesta da parametro
            // 🚀 Apertura automatica se richiesto da parametro
            if (StartTrade != TradeDirection.Nessuna)
            {
                var vol = Symbol.QuantityToVolumeInUnits(VolumeInLots);

                if (vol <= 0)
                {
                    Print("⚠️ Volume non valido per apertura iniziale.");
                    return;
                }

                // Verifica se è possibile aprire posizioni
                if (!CanOpenNewPositions())
                    return;

                TradeType tipo = StartTrade == TradeDirection.Long ? TradeType.Buy : TradeType.Sell;
                Print($"🚀 Apertura automatica all'avvio: {tipo} | Volume: {VolumeInLots} lots ({vol} units)");
                ExecuteMarketOrder(StartTrade == TradeDirection.Long ? TradeType.Buy : TradeType.Sell, SymbolName, vol, CustomLabel);
            }

            if (EnableSignalRSI && RsiHigherTimeFrame <= TimeFrame)
            {
                Print("⚠️ ERRORE CONFIGURAZIONE: il TimeFrame RSI superiore è <= del timeframe base del cBot.");
                Print("   ➤ Il filtro RSI multi-timeframe non funzionerà correttamente (Δ = 0 sempre).");
            }

            // Inizializzazione indicatore EMA
            if (EnableEmaFilter)
            {
                try
                {
                    var emaBars = EmaTimeFrame == TimeFrame ? Bars : MarketData.GetBars(EmaTimeFrame);
                    ema = Indicators.ExponentialMovingAverage(emaBars.ClosePrices, EmaPeriod);
                    Print($"✅ Indicatore EMA inizializzato: Periodo {EmaPeriod}, Timeframe {EmaTimeFrame}");
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore inizializzazione EMA: {ex.Message}");
                    EnableEmaFilter = false;
                }
            }

            ValidateParameters();  // ✅ chiamata alla funzione centralizzata
            Print("✅ Validazione parametri completata. Strategia pronta.");

            // Utilizzo della variabile BuildVersion per il log
            string BuildVersion = BUILD_ID;
            Print($"Versione Build attuale: {BuildVersion}");

            TimeFrame tfBase = TimeFrame;
            int rsiPeriodBase = RsiPeriodBase;
            int rsiPeriodHigher = RsiPeriodHigher;
            TimeFrame rsiTFHigher = RsiHigherTimeFrame;
            double minRsiDelta = MinRsiDelta;

            cooldownAfterCloseSeconds = CooldownAfterCloseSeconds;

            if (!IsSignalEnabled && !IsOrderEnabled)
            {
                Print("⚠️ Attenzione: modalità esecuzione non valida. Nessuna azione sarà effettuata.");
                Chart.DrawStaticText("execution_mode_warning",
                    "⚠️ Modalità esecuzione: né segnali né ordini attivi!",
                    VerticalAlignment.Top, HorizontalAlignment.Center, Color.OrangeRed);
            }

            // === FLAGS DI ATTIVAZIONE ===
            bool segnaliAttivi = EnableSignalRSI;

            // === PARAMETRI ORDINE ===
            double volumeLotti = Symbol.QuantityToVolumeInUnits(SignalLotSize);
            double slPips = SignalStopLossPips;
            double tpPips = SignalTakeProfitPips;
            int cooldownMinuti = SignalCooldownMinutes;

            // 🔄 Disegno immediato linea BE all'apertura se Breakeven attivo
            if (EnableBE)
            {
                var pos = Positions.FirstOrDefault(p => p.SymbolName == SymbolName);
                if (pos != null)
                {
                    fixedBreakEvenProfitThreshold = BETrigger * (1 - TriggerDDBE / 100.0);
                    DrawBreakEvenLineSafe(pos, fixedBreakEvenProfitThreshold);
                    double breakEvenTarget = pos.TradeType == TradeType.Buy
                        ? pos.EntryPrice + (fixedBreakEvenProfitThreshold / (pos.VolumeInUnits * (Symbol.PipValue / 100000.0)))
                        : pos.EntryPrice - (fixedBreakEvenProfitThreshold / (pos.VolumeInUnits * (Symbol.PipValue / 100000.0)));

                    Print($"📌 BE iniziale disegnato: Target {breakEvenTarget:F5} su profitto {fixedBreakEvenProfitThreshold:F2}€");
                }
            }

            // Inizializzazione del modulo di recovery esteso
            _extendedRecoveryModule = new ExtendedRecoveryModule(this);

            // Sincronizza le impostazioni di TrailingStopLoss
            _extendedRecoveryModule.SyncTrailingStopLossSettings(
                EnableRecoveryTrailingStopLoss,
                RecoveryTrailingStopLossTriggerEuro,
                RecoveryTrailingStopLossDistancePercent
            );

            // Eventualmente configura parametri specifici
            _extendedRecoveryModule.CriticalDrawdownThreshold = 75.0; // Configurazione opzionale


            // === LOG DI AVVIO CON VERSIONE BUILD ===
            Print($"✅ Avvio ProfitSentinel | BUILD: {BUILD_ID} | Profilo: {DescrizioneSettings}");

            // Inizializzazione indicatore RSI
            rsi = Indicators.RelativeStrengthIndex(Bars.ClosePrices, RSIPeriod);

            // Memorizza valore massimo iniziale di Equity
            maxEquity = Account.Equity;

            // Ascolta evento di chiusura posizioni
            Positions.Closed += OnPositionClosed;

            // Disegna HUD se abilitato
            if (ShowHUD)
                DrawHUD(0, 0, 0, 0, Symbol.Bid, null);

            // 📝 Salvataggio LOG CONFIGURAZIONE in file testo
            if (SalvaLogAvvioFile)
            {
                var log = new System.Text.StringBuilder();
                log.AppendLine("📋 CONFIGURAZIONE COMPLETA - PARAMETRI AVVIO");

                log.AppendLine("▶️ Generale:");
                log.AppendLine($"• VolumeInLots: {VolumeInLots} | SignalLotSize: {SignalLotSize}");
                log.AppendLine($"• SL/TP segnale: {SignalStopLossPips} pips / {SignalTakeProfitPips} pips");

                log.AppendLine("📈 TP Dinamico / BE:");
                log.AppendLine($"• TPStart: {TPStart}€ | TPDrawdown: {TPDrawdown}% | TPStartPercent: {TPStartPercent}%");
                log.AppendLine($"• CooldownAfterClose: {CooldownAfterCloseSeconds}s | TPUpdateDelay: {TrailingTPUpdateDelaySec}s");
                log.AppendLine($"• BETrigger: {BETrigger}€ | TriggerDDBE: {TriggerDDBE}%");

                log.AppendLine("🔁 Recovery:");
                log.AppendLine($"• MaxLots: {MaxAllowedLots} | Multiplier: {RecoveryMultiplier} | Max Trades: {MaxRecoveryTrades}");
                log.AppendLine($"• RecoveryTrigger%: {RecoveryTriggerPercent} | MinProfitOverMargin: {MinProfitOverMarginPercent}%");

                log.AppendLine("📐 Filtri & Sicurezza:");
                log.AppendLine($"• FreeMarginMinimo: {FreeMarginMinimoEuro}€ | MinMarginLevel: {MinMarginLevelPercent}%");
                log.AppendLine($"• SafeModeFreeMargin: {SafeModeRecoveryFreeMargin}€");
                log.AppendLine($"• SpreadCritico: {SpreadCriticoPips} | FlashCrash: {FlashCrashPips}p / {FlashCrashPauseSeconds}s");

                log.AppendLine("📊 RSI & Segnali:");
                log.AppendLine($"• RSI Base: {RsiPeriodBase} / {RSIMinBuy} - {RSIMaxSell}");
                log.AppendLine($"• RSI HighTF: {RsiPeriodHigher} / Δmin: {MinRsiDelta}");

                log.AppendLine("✅ Fine validazione e riepilogo parametri.");

                try
                {
                    var filename = $"ProfitSentinel_Log_Avvio_{Server.Time:yyyyMMdd_HHmm}.txt";
                    var fullPath = System.IO.Path.Combine(Environment.CurrentDirectory, filename);
                    System.IO.File.WriteAllText(fullPath, log.ToString());
                    Print($"📂 Log riepilogativo salvato in: {fullPath}");
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore salvataggio log: {ex.Message}");
                }
            }
        }

        // Retrocompatibilità con i vecchi parametri
        // Retrocompatibilità con i vecchi parametri
        private void InitializeBackwardCompatibility()
        {
            // I valori dei vecchi parametri vengono trasferiti ai nuovi
            AbilitaFiltroConsistenzaRSI = AbilitaFiltroPersistenzaRSI || AbilitaBarreConfermaSegnale;
            BarrePersistenzaRichieste = Math.Max(MinBarrePersistenzaSegnale, MinBarreConfermaSegnale);

            // Determina il tipo di validazione in base ai vecchi parametri
            if (AbilitaFiltroPersistenzaRSI && AbilitaBarreConfermaSegnale)
                TipoValidazionePersistenza = TipoConsistenzaRSI.Avanzato;
            else
                TipoValidazionePersistenza = TipoConsistenzaRSI.Standard;

            Print("🔄 Parametri di filtro RSI compatibilità inizializzati");
        }

        // Metodo principale di verifica licenza
        protected bool VerifyLicense(bool forceCheck = false)
        {
            try
            {
                Print($"🔑 Verifica licenza per Account ID: {Account.Number} ({Account.UserId})");

                // Se già verificata e non forzata, ritorna subito
                if (isLicenseValid && !forceCheck)
                    return true;

                // Incrementa tentativo
                verificationAttempts++;

                // Prova verifica online
                if (CheckLicenseOnline())
                    return true;

                // Prova verifica offline se consentito
                string dirPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                                           "FuryTeam", "Licenses");
                string offlineLicensePath = Path.Combine(dirPath, OFFLINE_LICENSE_FILE);

                // Verifica che le directory esistano
                try
                {
                    // Verifica se esiste la directory, altrimenti la crea
                    if (!Directory.Exists(dirPath))
                    {
                        Print($"🔑 Directory licenze non trovata, creo: {dirPath}");
                        Directory.CreateDirectory(dirPath);
                    }

                    if (File.Exists(offlineLicensePath))
                    {
                        if (CheckLicenseOffline(offlineLicensePath))
                            return true;
                    }
                    else
                    {
                        Print($"⚠️ File licenza offline non trovato: {offlineLicensePath}");
                    }
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore accesso directory licenze: {ex.Message}");
                }

                // Troppi tentativi falliti
                if (verificationAttempts >= 3)
                {
                    ShowLicenseError("Numero massimo di tentativi di verifica licenza raggiunto");
                    return false;
                }

                return false;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore durante la verifica della licenza: {ex.Message}");
                return false;
            }
        }

        // Verifica licenza online
        private bool CheckLicenseOnline()
        {
            try
            {
                // URL richiesta licenza
                string requestUrl = $"{LICENSE_SERVER_URL}{Account.UserId}.json";
                Print($"📡 Richiesta licenza online: {requestUrl}");

                // Effettua richiesta HTTP
                var response = Http.Get(requestUrl);

                // Verifica risposta
                if (response.StatusCode != 200)
                {
                    Print($"⚠️ Errore server licenze: Status {response.StatusCode}");
                    return false;
                }

                // Deserializza licenza
                License license = JsonConvert.DeserializeObject<License>(response.Body);

                // Verifica integrità
                if (!VerifyLicenseIntegrity(license))
                {
                    Print("⚠️ Integrità licenza compromessa");
                    return false;
                }

                // Verifica account
                if (license.account_id != Account.UserId.ToString())
                {
                    Print($"⚠️ ID account non corrispondente: {license.account_id} vs {Account.UserId}");
                    return false;
                }

                // Verifica scadenza
                if (DateTime.TryParse(license.expiration_date, out DateTime expirationDate))
                {
                    licenseExpirationDate = expirationDate;

                    // Licenza scaduta
                    if (expirationDate < Server.Time && license.license_type != "Lifetime")
                    {
                        Print($"⚠️ Licenza scaduta il {expirationDate:dd/MM/yyyy}");
                        ShowLicenseError($"La tua licenza è scaduta il {expirationDate:dd/MM/yyyy}");
                        return false;
                    }

                    // Licenza lifetime o valida
                    if (license.license_type == "Lifetime" || expirationDate > Server.Time)
                    {
                        isLicenseValid = true;
                        ShowLicenseInfo(license, false);

                        // Salva copia offline se consentito
                        if (license.allow_offline_mode)
                            SaveOfflineLicense(license);

                        return true;
                    }
                }
                else
                {
                    Print("⚠️ Formato data scadenza non valido");
                }

                return false;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore verifica licenza online: {ex.Message}");
                return false;
            }
        }

        // Verifica licenza offline
        private bool CheckLicenseOffline(string licensePath)
        {
            try
            {
                Print($"🔑 Tentativo verifica licenza offline");

                if (!File.Exists(licensePath))
                {
                    Print("⚠️ File licenza offline non trovato");
                    return false;
                }

                // Leggi e deserializza licenza
                string licenseContent = File.ReadAllText(licensePath);
                License license = JsonConvert.DeserializeObject<License>(licenseContent);

                // Verifica integrità
                if (!VerifyLicenseIntegrity(license))
                {
                    Print("⚠️ Integrità licenza offline compromessa");
                    return false;
                }

                // Verifica account
                if (license.account_id != Account.UserId.ToString())
                {
                    Print($"⚠️ ID account offline non corrispondente");
                    return false;
                }

                // Verifica scadenza
                if (DateTime.TryParse(license.expiration_date, out DateTime expirationDate))
                {
                    licenseExpirationDate = expirationDate;

                    // Licenza scaduta
                    if (expirationDate < Server.Time && license.license_type != "Lifetime")
                    {
                        Print($"⚠️ Licenza offline scaduta il {expirationDate:dd/MM/yyyy}");
                        return false;
                    }

                    // Licenza lifetime o valida
                    if (license.license_type == "Lifetime" || expirationDate > Server.Time)
                    {
                        isLicenseValid = true;
                        ShowLicenseInfo(license, true);
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore verifica licenza offline: {ex.Message}");
                return false;
            }
        }

        // Verifica integrità licenza tramite hash
        private bool VerifyLicenseIntegrity(License license)
        {
            if (license == null || string.IsNullOrEmpty(license.integrity_hash))
                return false;

            string dataToHash = $"{license.account_id}|{license.expiration_date}|{license.product_name}|{license.license_key}|{LICENSE_HASH_SALT}";
            string computedHash;

            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(dataToHash);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                computedHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();
            }

            return computedHash == license.integrity_hash;
        }

        // Salva copia licenza offline
        private void SaveOfflineLicense(License license)
        {
            try
            {
                string dirPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FuryTeam", "Licenses");

                if (!Directory.Exists(dirPath))
                    Directory.CreateDirectory(dirPath);

                string filePath = Path.Combine(dirPath, OFFLINE_LICENSE_FILE);
                string licenseJson = JsonConvert.SerializeObject(license, Formatting.Indented);

                File.WriteAllText(filePath, licenseJson);
                Print($"✅ Licenza salvata offline in: {filePath}");
            }
            catch (Exception ex)
            {
                Print($"⚠️ Impossibile salvare licenza offline: {ex.Message}");
            }
        }

        // Genera hash per account (per licenza offline)
        private string GenerateAccountHash(string accountId)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
            {
                var bytes = System.Text.Encoding.UTF8.GetBytes(accountId + LICENSE_OFFLINE_KEY);
                var hash = sha.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").Substring(0, 16);
            }
        }

        // Mostra info licenza nell'interfaccia
        // Mostra info licenza nell'interfaccia
        private void ShowLicenseInfo(License license, bool isOffline)
        {
            string expiryInfo = license.license_type == "Lifetime" ?
                "Licenza perpetua" :
                $"Valida fino al {licenseExpirationDate:dd/MM/yyyy}";

            // Crea un messaggio più dettagliato con formattazione migliorata
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"✅ {(isOffline ? "[OFFLINE] " : "")}LICENZA ATTIVA");
            sb.AppendLine($"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sb.AppendLine($"📦 Prodotto: {license.product_name}");
            sb.AppendLine($"🆔 Account ID: {license.account_id} ({Account.Number})");
            sb.AppendLine($"📆 {expiryInfo}");
            sb.AppendLine($"🏷️ Tipo licenza: {license.license_type}");
            sb.AppendLine($"🔑 Chiave: {license.license_key}");
            sb.AppendLine($"📡 Modalità: {(isOffline ? "OFFLINE (cache locale)" : "ONLINE (server verificato)")}");

            // Informazioni aggiuntive sulla verifica
            sb.AppendLine($"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            sb.AppendLine($"🔄 Verificata il: {Server.Time:dd/MM/yyyy HH:mm:ss}");
            sb.AppendLine($"🛡️ Tentativi max: {license.max_verification_attempts}");
            sb.AppendLine($"💾 Offline mode: {(license.allow_offline_mode ? "Consentito ✓" : "Non consentito ✗")}");
            sb.AppendLine($"🔐 Hash: ...{license.integrity_hash.Substring(Math.Max(0, license.integrity_hash.Length - 8))}");
            sb.AppendLine($"📊 Versione: {BUILD_ID} ({BUILD_DATE})");

            // Informazione timer rimozione
            if (LicenseInfoDisplaySeconds > 0)
                sb.AppendLine($"⏱️ Auto-nascondimento tra {LicenseInfoDisplaySeconds} secondi");

            // Mostra nel grafico
            Chart.DrawStaticText("license_info",
                sb.ToString(),
                VerticalAlignment.Bottom,
                HorizontalAlignment.Center,
                isOffline ? Color.Orange : Color.LimeGreen);

            Print($"🔑 Info licenza: {license.product_name} | {expiryInfo} | Tipo: {license.license_type}");

            // Salva l'orario di visualizzazione del messaggio
            _licenseInfoDisplayTime = Server.Time;
            _licenseInfoDisplayed = true;
        }

        // Mostra avvertimento licenza
        private void ShowLicenseWarning(string message)
        {
            Chart.DrawStaticText("license_warning",
                message,
                VerticalAlignment.Top,
                HorizontalAlignment.Center,
                Color.Orange);

            Print($"⚠️ AVVISO LICENZA: {message}");
        }

        // Mostra errore licenza
        private void ShowLicenseError(string message)
        {
            isLicenseValid = false;

            // Messaggio errore console
            Print($"❌ ERRORE LICENZA: {message}");

            // Messaggio errore grafico
            Chart.DrawStaticText("license_error",
                $"❌ ERRORE LICENZA\n{message}\n\nIl robot è stato disattivato.\n\n" +
                $"Contatta https://t.me/Obiriec per assistenza.",
                VerticalAlignment.Center,
                HorizontalAlignment.Center,
                Color.Red);

            // Sfondo semi-trasparente
            Chart.DrawStaticText("license_background",
                new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100),
                VerticalAlignment.Center,
                HorizontalAlignment.Center,
                Color.FromArgb(220, 0, 0, 0));
        }

        //===============================================================
        // CONTROLLO AGGIORNAMENTI
        //===============================================================
        // Metodo per controllare gli aggiornamenti
        // Metodo per controllare gli aggiornamenti
        protected void CheckForUpdates()
        {
            try
            {
                // Controlla aggiornamenti solo una volta al giorno
                // if ((Server.Time - lastUpdateCheck).TotalHours < 24 && lastUpdateCheck != DateTime.MinValue)
                if ((Server.Time - lastUpdateCheck).TotalMinutes < 1 && lastUpdateCheck != DateTime.MinValue)
                    return;

                lastUpdateCheck = Server.Time;

                Print($"🔄 Verifica aggiornamenti disponibili...");

                // Simulazione di un controllo aggiornamenti
                updateAvailable = true; // Supponiamo che un aggiornamento sia disponibile

                // Richiesta HTTP GET al server degli aggiornamenti
                var response = Http.Get($"{UPDATE_SERVER_URL}profit_sentinel_updates.json");

                // Verifica risposta HTTP
                if (response.StatusCode != 200)
                {
                    Print($"⚠️ Errore server aggiornamenti: Status {response.StatusCode}");
                    return;
                }

                // Deserializza la risposta JSON
                UpdateInfo updateInfo = JsonConvert.DeserializeObject<UpdateInfo>(response.Body);

                // Verifica dati di aggiornamento
                if (updateInfo == null || string.IsNullOrEmpty(updateInfo.version))
                {
                    Print("⚠️ Dati aggiornamento non validi o mancanti");
                    return;
                }

                // Verifica se la versione è più recente
                if (CompareVersions(updateInfo.version, BUILD_ID) > 0)
                {
                    // Aggiornamento disponibile
                    updateAvailable = true;
                    updateVersion = updateInfo.version;
                    updateMessage = updateInfo.message;
                    updateChangelog = updateInfo.changelog;
                    updateDownloadUrl = updateInfo.download_url;
                    updateRequired = updateInfo.required;

                    Print($"🔔 Aggiornamento disponibile: v{updateVersion}");
                    Print($"📋 Messaggio: {updateMessage}");
                    Print($"💾 Download link: {updateDownloadUrl}");

                    if (updateInfo.changelog != null && updateInfo.changelog.Length > 0)
                    {
                        Print("📋 Changelog:");
                        foreach (var change in updateInfo.changelog)
                            Print($"  • {change}");
                    }

                    // Mostra avviso sul grafico
                    ShowUpdateNotification();

                    // Se l'aggiornamento è obbligatorio, non fermare l'esecuzione ma blocca le nuove aperture
                    if (updateRequired)
                    {
                        Print("⚠️ Questo aggiornamento è obbligatorio. Le nuove aperture saranno bloccate fino all'aggiornamento.");
                        ShowUpdateRequiredWarning();
                        // Non chiamare Stop() per permettere all'utente di vedere l'avviso
                    }
                }
                else
                {
                    Print($"✅ Stai utilizzando l'ultima versione disponibile (v{BUILD_ID})");
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore verifica aggiornamenti: {ex.Message}");
            }
        }

        // Nuovo metodo per mostrare un avviso permanente sull'aggiornamento obbligatorio
        private void ShowUpdateRequiredWarning()
        {
            // Mostra un avviso persistente sul grafico
            Chart.DrawStaticText("update_required_warning",
                "⚠️ AGGIORNAMENTO OBBLIGATORIO RICHIESTO ⚠️\n\n" +
                $"È disponibile la versione {updateVersion}, che è obbligatoria.\n" +
                "L'apertura di nuove posizioni è stata bloccata.\n\n" +
                $"Scarica l'aggiornamento da: {updateDownloadUrl}\n\n" +
                "Il cBot continuerà a gestire le posizioni esistenti.",
                VerticalAlignment.Top, HorizontalAlignment.Center,
                Color.Red);
        }

        // Aggiungere questo metodo per verificare se è possibile aprire posizioni
        private bool CanOpenNewPositions()
        {
            if (updateRequired)
            {
                Print("⛔ Apertura posizione bloccata: richiesto aggiornamento obbligatorio.");
                return false;
            }
            return true;
        }

        // Metodo per confrontare le versioni (ritorna positivo se v1 > v2)
        private int CompareVersions(string v1, string v2)
        {
            // Rimuovi eventuali prefissi 'v' o 'V'
            v1 = v1.TrimStart('v', 'V');
            v2 = v2.TrimStart('v', 'V');

            // Suddivide le stringhe di versione in parti numeriche
            string[] parts1 = v1.Split('.');
            string[] parts2 = v2.Split('.');

            // Determina la lunghezza massima tra le due versioni
            int maxLength = Math.Max(parts1.Length, parts2.Length);

            // Confronta ciascuna parte numerica
            for (int i = 0; i < maxLength; i++)
            {
                // Se una versione ha meno parti, considera 0 per le parti mancanti
                int num1 = (i < parts1.Length) ? int.Parse(parts1[i]) : 0;
                int num2 = (i < parts2.Length) ? int.Parse(parts2[i]) : 0;

                if (num1 != num2)
                    return num1.CompareTo(num2);
            }

            // Le versioni sono identiche
            return 0;
        }

        // Metodo per mostrare la notifica di aggiornamento sul grafico
        private void ShowUpdateNotification()
        {
            try
            {
                // Crea il messaggio di notifica
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"🔔 AGGIORNAMENTO DISPONIBILE");
                sb.AppendLine($"Una nuova versione (v{updateVersion}) è disponibile!");
                sb.AppendLine();
                sb.AppendLine($"{updateMessage}");
                sb.AppendLine();

                if (updateChangelog != null && updateChangelog.Length > 0)
                {
                    sb.AppendLine("📋 NOVITÀ:");
                    foreach (var change in updateChangelog.Take(10))
                        sb.AppendLine($"• {change}");

                    if (updateChangelog.Length > 10)
                        sb.AppendLine("• etc. ...");
                }

                sb.AppendLine();
                sb.AppendLine($"📥 Download: {updateDownloadUrl}");
                sb.AppendLine(updateRequired ? "⚠️ AGGIORNAMENTO OBBLIGATORIO ⚠️" : "");

                // Colore in base alla criticità dell'aggiornamento
                Color notificationColor = updateRequired ? Color.Red : Color.Orange;

                // Rimuovi notifiche precedenti
                Chart.RemoveObject("update_notification");
                Chart.RemoveObject("update_background");

                // Sfondo semitrasparente
                Chart.DrawStaticText("update_background",
                    new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100) + "\n" + new string(' ', 100),
                    VerticalAlignment.Center, HorizontalAlignment.Center,
                    Color.FromArgb(180, 0, 0, 0));

                // Testo di notifica
                Chart.DrawStaticText("update_notification",
                    sb.ToString(),
                    VerticalAlignment.Center, HorizontalAlignment.Center,
                    notificationColor);
            }
            catch (Exception ex)
            {
                Print($"❌ Errore visualizzazione notifica aggiornamento: {ex.Message}");
            }
        }

        //===============================================================
        // VALIDATE PARAMETERS
        //===============================================================
        private void ValidateParameters()
        {
            if (VolumeInLots <= 0)
                throw new ArgumentException("❌ Il volume iniziale deve essere maggiore di 0.");

            if (VolumeInLots < 0.01)
                throw new ArgumentException("❌ Il volume minimo consentito è 0.01 lots");

            if (SignalLotSize < 0.01)
                throw new ArgumentException("❌ Il volume minimo per i segnali RSI è 0.01 lots");

            if (EnableSignalRSI)
            {
                if (SignalLotSize <= 0)
                    throw new ArgumentException("❌ Il lotto per ordine segnale deve essere maggiore di 0.");

                if (SignalStopLossPips != 0 && SignalStopLossPips < Symbol.TickSize / Symbol.PipSize * 10)
                    throw new ArgumentException("❌ SL segnale troppo vicino al prezzo: distanza minima richiesta dal broker non rispettata.");
                double slMinimo = Symbol.TickSize / Symbol.PipSize * 10;
                Print($"ℹ️ SL minimo richiesto dal broker: {slMinimo} pips");

                if (SignalStopLossPips > 100)
                    Print("⚠️ Avviso: SL segnale superiore a 100 pips. Controlla se è voluto.");

                if (SignalTakeProfitPips != 0 && SignalTakeProfitPips < Symbol.TickSize / Symbol.PipSize * 10)
                    throw new ArgumentException("❌ TP segnale troppo vicino al prezzo: distanza minima richiesta dal broker non rispettata.");

                if (SignalTakeProfitPips < 5)
                    Print("⚠️ Avviso: TP segnale molto stretto. Potrebbe non coprire costi/spread.");
            }

            if (EnableSignalRSI && RsiHigherTimeFrame <= TimeFrame)
            {
                Print($"⚠️ Attenzione: il TimeFrame RSI superiore ({RsiHigherTimeFrame}) è uguale o inferiore a quello del cBot ({TimeFrame}).");
                Print("➤ Il Δ RSI sarà sempre 0 ➜ logica segnale RSI inefficace.");
            }

            if (EnableTrailingTP)
            {
                if (TPDrawdown < 0 || TPDrawdown > 100)
                    throw new ArgumentException("❌ TPDrawdown deve essere compreso tra 0 e 100%.");

                if (TPDrawdown > 90)
                    Print("⚠️ Avviso: TPDrawdown molto alto. Il trailing TP sarà molto permissivo.");

                if (TPDrawdown < 10)
                    Print("⚠️ Avviso: TPDrawdown molto basso. Rischio di chiusure premature.");

                if (TPStart < 0)
                    throw new ArgumentException("❌ TPStart deve essere positivo.");

                if (TPStartPercent < 0 || TPStartPercent > 100)
                    throw new ArgumentException("❌ TPStartPercent deve essere compreso tra 0 e 100%.");

                if (TPStartPercent > 80)
                    Print("⚠️ Avviso: TPStartPercent elevato. Potrebbe attivare il trailing solo con grandi profitti.");

                if (TPStartMinimo < 0)
                    throw new ArgumentException("❌ TPStartMinimo non può essere negativo.");

                if (SpreadCriticoPips < 0)
                    throw new ArgumentException("❌ SpreadCriticoPips deve essere positivo o zero.");

                if (SpreadCriticoPips > 10)
                    Print("⚠️ Avviso: SpreadCriticoPips elevato. Potrebbe non attivare la protezione in tempo.");

                if (CooldownAfterCloseSeconds < 0)
                    throw new ArgumentException("❌ CooldownAfterCloseSeconds deve essere ≥ 0.");

                if (CooldownAfterCloseSeconds < 10)
                    Print("⚠️ Avviso: Cooldown post-chiusura molto breve. Possibili rientri immediati.");

                if (TrailingTPUpdateDelaySec < 1)
                    throw new ArgumentException("❌ Il delay tra aggiornamenti TP deve essere almeno 1 secondo.");
            }

            if (EnableBE)
            {
                if (BETrigger < 0)
                    throw new ArgumentException("❌ BETrigger non può essere negativo.");

                if (TriggerDDBE < 0 || TriggerDDBE > 100)
                    throw new ArgumentException("❌ TriggerDDBE deve essere compreso tra 0 e 100%.");

                if (TriggerDDBE > 50)
                    Print("⚠️ Avviso: TriggerDDBE molto alto. Il BE potrebbe attivarsi solo in drawdown gravi.");
            }

            if (EnableRecovery)
            {
                if (MaxAllowedLots <= 0)
                    throw new ArgumentException("❌ Lotto massimo consentito deve essere maggiore di 0.");

                if (MaxAllowedLots > 50)
                    Print("⚠️ Avviso: MaxAllowedLots elevato. Verifica compatibilità con il margine del conto.");

                if (RecoveryMultiplier <= 1)
                    throw new ArgumentException("❌ RecoveryMultiplier deve essere maggiore di 1.");

                if (RecoveryMultiplier > 3)
                    Print("⚠️ Avviso: RecoveryMultiplier molto aggressivo (>3). Rischio esponenziale.");

                if (MaxRecoveryTrades < 1)
                    throw new ArgumentException("❌ MaxRecoveryTrades deve essere almeno 1.");

                if (RecoveryTriggerPercent < 0 || RecoveryTriggerPercent > 100)
                    throw new ArgumentException("❌ RecoveryTriggerPercent deve essere compreso tra 0 e 100%.");
            }

            // Configura il modulo di recovery esteso se abilitato
            if (_extendedRecoveryModule != null)
            {
                _extendedRecoveryModule.EnableEmergencyMode = EnableExtendedRecovery;
                _extendedRecoveryModule.CriticalDrawdownThreshold = CriticalDrawdownThreshold;
            }

            if (EnableMinProfitCheck)
            {
                if (MinProfitOverMarginPercent < 0)
                    throw new ArgumentException("❌ MinProfitOverMarginPercent non può essere negativo.");
            }

            if (FreeMarginMinimoEuro < 0)
                throw new ArgumentException("❌ FreeMarginMinimoEuro non può essere negativo.");

            if (MinMarginLevelPercent < 0)
                throw new ArgumentException("❌ MinMarginLevelPercent non può essere negativo.");

            if (SafeModeRecoveryFreeMargin < 0)
                throw new ArgumentException("❌ SafeModeRecoveryFreeMargin non può essere negativo.");

            if (MinDistancePips < 0 || RecoveryCooldownPips < 0 || MinDDIncreasePercent < 0 || MinDistanceBEpips < 0)
                throw new ArgumentException("❌ I parametri di distanza o peggioramento DD non possono essere negativi.");

            if (EnableRSIFilter || EnableSignalRSI)
            {
                if (RSIPeriod <= 1 || RsiPeriodBase <= 1 || RsiPeriodHigher <= 1)
                    throw new ArgumentException("❌ I periodi RSI devono essere maggiori di 1.");

                if (RSIMinBuy < 0 || RSIMinBuy > 100 || RSIMaxSell < 0 || RSIMaxSell > 100)
                    throw new ArgumentException("❌ I livelli RSI devono essere compresi tra 0 e 100.");

                if (MinRsiDelta < 0)
                    throw new ArgumentException("❌ MinRsiDelta non può essere negativo.");
            }

            if (EnableFlashCrashProtection)
            {
                if (FlashCrashPips < 0 || FlashCrashPauseSeconds < 0)
                    throw new ArgumentException("❌ I parametri di protezione Flash Crash devono essere ≥ 0.");
            }

            // === LOG RIEPILOGATIVO (se attivo) ===
            if (MostraLogAvvio)
            {
                Print("");
                Print("📋 CONFIGURAZIONE COMPLETA - PARAMETRI AVVIO");

                Print("▶️ Generale:");
                Print($"• VolumeInLots: {VolumeInLots} | SignalLotSize: {SignalLotSize}");
                Print($"• SL/TP segnale: {SignalStopLossPips} pips / {SignalTakeProfitPips} pips");

                Print("📈 TP Dinamico / BE:");
                Print($"• TPStart: {TPStart}€ | TPDrawdown: {TPDrawdown}% | TPStartPercent: {TPStartPercent}%");
                Print($"• CooldownAfterClose: {CooldownAfterCloseSeconds}s | TPUpdateDelay: {TrailingTPUpdateDelaySec}s");
                Print($"• BETrigger: {BETrigger}€ | TriggerDDBE: {TriggerDDBE}%");

                Print("🔁 Recovery:");
                Print($"• MaxLots: {MaxAllowedLots} | Multiplier: {RecoveryMultiplier} | Max Trades: {MaxRecoveryTrades}");
                Print($"• RecoveryTrigger%: {RecoveryTriggerPercent} | MinProfitOverMargin: {MinProfitOverMarginPercent}%");

                Print("📐 Filtri & Sicurezza:");
                Print($"• FreeMarginMinimo: {FreeMarginMinimoEuro}€ | MinMarginLevel: {MinMarginLevelPercent}%");
                Print($"• SafeModeFreeMargin: {SafeModeRecoveryFreeMargin}€");
                Print($"• SpreadCritico: {SpreadCriticoPips} | FlashCrash: {FlashCrashPips}p / {FlashCrashPauseSeconds}s");

                Print("📊 RSI & Segnali:");
                Print($"• RSI Base: {RsiPeriodBase} / {RSIMinBuy} - {RSIMaxSell}");
                Print($"• RSI HighTF: {RsiPeriodHigher} / Δmin: {MinRsiDelta}");

                Print("✅ Fine validazione e riepilogo parametri.");
                Print("");
            }

            if (SalvaLogAvvioFile)
            {
                var log = new System.Text.StringBuilder();
                log.AppendLine("📋 CONFIGURAZIONE COMPLETA - PARAMETRI AVVIO");

                log.AppendLine("▶️ Generale:");
                log.AppendLine($"• VolumeInLots: {VolumeInLots} | SignalLotSize: {SignalLotSize}");
                log.AppendLine($"• SL/TP segnale: {SignalStopLossPips} pips / {SignalTakeProfitPips} pips");

                log.AppendLine("📈 TP Dinamico / BE:");
                log.AppendLine($"• TPStart: {TPStart}€ | TPDrawdown: {TPDrawdown}% | TPStartPercent: {TPStartPercent}%");
                log.AppendLine($"• CooldownAfterClose: {CooldownAfterCloseSeconds}s | TPUpdateDelay: {TrailingTPUpdateDelaySec}s");
                log.AppendLine($"• BETrigger: {BETrigger}€ | TriggerDDBE: {TriggerDDBE}%");

                log.AppendLine("🔁 Recovery:");
                log.AppendLine($"• MaxLots: {MaxAllowedLots} | Multiplier: {RecoveryMultiplier} | Max Trades: {MaxRecoveryTrades}");
                log.AppendLine($"• RecoveryTrigger%: {RecoveryTriggerPercent} | MinProfitOverMargin: {MinProfitOverMarginPercent}%");

                log.AppendLine("📐 Filtri & Sicurezza:");
                log.AppendLine($"• FreeMarginMinimo: {FreeMarginMinimoEuro}€ | MinMarginLevel: {MinMarginLevelPercent}%");
                log.AppendLine($"• SafeModeFreeMargin: {SafeModeRecoveryFreeMargin}€");
                log.AppendLine($"• SpreadCritico: {SpreadCriticoPips} | FlashCrash: {FlashCrashPips}p / {FlashCrashPauseSeconds}s");

                log.AppendLine("📊 RSI & Segnali:");
                log.AppendLine($"• RSI Base: {RsiPeriodBase} / {RSIMinBuy} - {RSIMaxSell}");
                log.AppendLine($"• RSI HighTF: {RsiPeriodHigher} / Δmin: {MinRsiDelta}");

                if (AbilitaFiltroPersistenzaRSI)
                    log.AppendLine($"• Persistenza segnale: {MinBarrePersistenzaSegnale} barre");

                if (MinBarreConfermaSegnale > 0)
                {
                    string timingLabel = ModalitaTimingApertura switch
                    {
                        TimingAperturaPosizione.AllaChiusuraBarraConferma => "chiusura barra conferma",
                        TimingAperturaPosizione.AllaChiusuraBarraSuccessiva => "chiusura barra successiva",
                        _ => "non specificato"
                    };
                    log.AppendLine($"• Conferma segnale: {MinBarreConfermaSegnale} barre | Apertura: {timingLabel}");
                }

                if (AbilitaFiltroDeltaCrescenteRSI)
                    log.AppendLine("• Filtro: Δ RSI crescente ✅");

                if (AbilitaFiltroCurvaturaRSIBase)
                    log.AppendLine("• Filtro: curvatura RSI base ✅");

                log.AppendLine("✅ Fine validazione e riepilogo parametri.");

                try
                {
                    var filename = $"ProfitSentinel_Log_Avvio_{Server.Time:yyyyMMdd_HHmm}.txt";
                    var fullPath = System.IO.Path.Combine(Environment.CurrentDirectory, filename);
                    System.IO.File.WriteAllText(fullPath, log.ToString());
                    Print($"📂 Log riepilogativo salvato in: {fullPath}");
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore salvataggio log: {ex.Message}");
                }
            }
        }

        //==========================================================================
        // 🔁 BLOCCO 11 — FUNZIONI DI RESET & EVENTI POSIZIONI
        //==========================================================================

        // Reset dei valori massimi e contatori quando tutte le posizioni sono chiuse
        private void Reset()
        {
            maxTP = 0;
            maxFixedTP = 0;
            maxEquity = Account.Equity;
            recoveryCount = 0;
            lastRecoveryDrawdown = 0.0;
            recoveryCooldownActive = false;
            lastRecoveryPrice = 0.0;
            triggerBreakevenAttivo = false;
            maxProfitAfterTrigger = 0;

            Chart.RemoveObject(TP_DYNAMIC_LINE);
            Chart.RemoveObject(TP_DYNAMIC_LABEL);

            // 🔁 Reset anche della soglia fissa calcolata al trigger del Breakeven
            fixedBreakEvenProfitThreshold = 0.0;
        }

        //==========================================================================
        // 📡 ON BAR
        //==========================================================================

        private bool? pendingLongSignalValid = null;  // Memorizza validità segnale LONG
        private bool? pendingShortSignalValid = null; // Memorizza validità segnale SHORT
        protected override void OnBar()
        {
            try
            {
                // Esecuzione principale se abilitata in modalità "OnBar"
                if (Mode == ExecutionMode.OnBar)
                {
                    Print($"▶ [DEBUG] OnBar() attivato - Time: {Time}");
                    AggiornaRSI(true);   // LONG
                    AggiornaRSI(false);  // SHORT
                }

                // Verifica se ci sono già posizioni aperte (esclusi i recovery)
                bool hasInitialPositions = Positions.Count(p => p.Label == null ||
                                           (!p.Label.Contains("RECOVERY") && !p.Label.StartsWith("ExtRec_"))) > 0;

                // Esegui la logica di recovery solo se abilitata
                if (EnableRecovery)
                    ExecuteLogic();

                // Esci se i segnali RSI non sono abilitati o se ci sono già posizioni aperte
                if (!EnableSignalRSI || (hasInitialPositions && !EnableClosingOnlyMode))
                {
                    if (hasInitialPositions && EnableDebugLogs && EnableSignalRSI)
                        Print("⚠️ Segnali RSI sospesi: ci sono già posizioni aperte");

                    return;
                }

                if (Bars.Count < 2)
                {
                    Print("⏳ Attesa barre sufficienti (Bars.Count = " + Bars.Count + ")");
                    return;
                }

                double prezzo = Bars.ClosePrices.Last(1);

                if (string.IsNullOrEmpty(SymbolName))
                {
                    Print("❌ SymbolName non valido. Verifica l'inizializzazione.");
                    return;
                }

                // Memorizza se siamo in modalità TrendFollowing per uso successivo
                bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

                // -------------------- GESTIONE ESECUZIONI PENDENTI --------------------
                // Controlliamo PRIMA se ci sono esecuzioni pendenti programmate per questa barra
                bool longExecuted = false;
                bool shortExecuted = false;

                // Verifica esecuzione pendente LONG
                if (pendingExecutionLongTime != null && Bars.OpenTimes.Last() > pendingExecutionLongTime.Value)
                {
                    Print($"✅ [LONG] Barra successiva rilevata: {Bars.OpenTimes.Last()} > {pendingExecutionLongTime.Value}");
                    lastSignalTimeLong = Time;

                    // Usa SEMPRE il valore memorizzato, indipendentemente dalle condizioni attuali
                    bool segnaleDaAprire = pendingLongSignalValid.Value;
                    DrawSegnaleGraficoRSI(segnaleDaAprire, Time, prezzo);
                    EseguiSegnaleRSI(segnaleDaAprire, Time, prezzo);
                    Print($"✅ Segnale {(segnaleDaAprire ? "LONG" : "SHORT")} eseguito (chiusura barra successiva)");

                    // Reset completo dopo l'esecuzione
                    confermaBarreLong = 0;
                    pendingExecutionLongTime = null;
                    pendingSignalLongTime = null;
                    pendingLongSignalValid = null;
                    longExecuted = true;
                }

                // Verifica esecuzione pendente SHORT
                if (pendingExecutionShortTime != null && Bars.OpenTimes.Last() > pendingExecutionShortTime.Value)
                {
                    Print($"✅ [SHORT] Barra successiva rilevata: {Bars.OpenTimes.Last()} > {pendingExecutionShortTime.Value}");
                    lastSignalTimeShort = Time;

                    // Usa SEMPRE il valore memorizzato, indipendentemente dalle condizioni attuali
                    bool segnaleDaAprire = pendingShortSignalValid.Value;
                    DrawSegnaleGraficoRSI(segnaleDaAprire, Time, prezzo);
                    EseguiSegnaleRSI(segnaleDaAprire, Time, prezzo);
                    Print($"✅ Segnale {(segnaleDaAprire ? "LONG" : "SHORT")} eseguito (chiusura barra successiva)");

                    // Reset completo dopo l'esecuzione
                    confermaBarreShort = 0;
                    pendingExecutionShortTime = null;
                    pendingSignalShortTime = null;
                    pendingShortSignalValid = null;
                    shortExecuted = true;
                }

                // Uscire se ci sono posizioni aperte dopo l'esecuzione delle operazioni pendenti
                if (Positions.Count > 0 && !EnableClosingOnlyMode)
                {
                    if (EnableDebugLogs)
                        Print("⚠️ Analisi segnali sospesa: posizioni aperte dopo esecuzione segnali pendenti");
                    return;
                }

                // -------------------- ANALISI NUOVI SEGNALI --------------------

                // === VALIDAZIONE RSI LONG ===
                var diagnosiLong = ValidaSegnaleRSIConQualita(true);
                bool segnaleLong = diagnosiLong.SegnaleFinale;
                double deltaLong = rsiSuperiorValueLong - rsiBaseValueLong;

                hudRsiQualitaLong = GeneraStringaQualitaSegnale(true, rsiBaseValueLong, rsiSuperiorValueLong, deltaLong, diagnosiLong);

                Print($"➤ RSI LONG {(segnaleLong ? "valido ✅" : "non valido ❌")} | " +
                      $"Base: {rsiBaseValueLong:F2} | Sup: {rsiSuperiorValueLong:F2} | Δ: {deltaLong:F2} | " +
                      GeneraStatoFiltriRSI(diagnosiLong, true));

                // Logica conferma LONG (solo se non abbiamo già eseguito un segnale pendente)
                if (!longExecuted)
                {
                    if (segnaleLong)
                    {
                        confermaBarreLong++;
                        Print($"🕒 Segnale LONG in conferma: {confermaBarreLong}/{MinBarreConfermaSegnale}");

                        if (confermaBarreLong >= MinBarreConfermaSegnale)
                        {
                            // In modalità TrendFollowing un segnale LONG è generato quando l'RSI è alto (ipercomprato)
                            // e viene tradotto in una posizione LONG (non SHORT come in Contrarian)
                            bool apriLong = true; // Aprire SEMPRE LONG quando il segnale è LONG

                            if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraConferma)
                            {
                                lastSignalTimeLong = Time;
                                DrawSegnaleGraficoRSI(apriLong, Time, prezzo);
                                EseguiSegnaleRSI(apriLong, Time, prezzo);
                                Print($"✅ Segnale LONG confermato e eseguito (chiusura barra conferma)");
                                confermaBarreLong = 0;
                                pendingExecutionLongTime = null;
                                pendingSignalLongTime = null;
                                pendingLongSignalValid = null;
                            }
                            else if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraSuccessiva)
                            {
                                if (pendingExecutionLongTime == null)
                                {
                                    // Memorizziamo esplicitamente l'apertura della barra corrente come riferimento
                                    pendingExecutionLongTime = Bars.OpenTimes.Last();
                                    pendingSignalLongTime = Time;
                                    pendingLongSignalValid = apriLong;
                                    Print($"🕒 Segnale LONG confermato su barra {pendingExecutionLongTime.Value.ToString("dd/MM HH:mm")}, attesa chiusura barra successiva");
                                }
                            }
                        }
                    }
                    else
                    {
                        // Non resettare il contatore se c'è già un'esecuzione pendente programmata
                        if (pendingExecutionLongTime == null)
                        {
                            confermaBarreLong = 0;
                        }

                        // Aggiornamento del tempo del segnale pendente
                        if (diagnosiLong.FiltroPersistenzaSuperato || deltaLong >= MinRsiDelta)
                        {
                            if (pendingSignalLongTime == null)
                                pendingSignalLongTime = Time;
                        }
                        else
                        {
                            pendingSignalLongTime = null;
                        }
                    }
                }

                // === VALIDAZIONE RSI SHORT ===
                var diagnosiShort = ValidaSegnaleRSIConQualita(false);
                bool segnaleShort = diagnosiShort.SegnaleFinale;
                double deltaShort = rsiBaseValueShort - rsiSuperiorValueShort;

                hudRsiQualitaShort = GeneraStringaQualitaSegnale(false, rsiBaseValueShort, rsiSuperiorValueShort, deltaShort, diagnosiShort);

                Print($"➤ RSI SHORT {(segnaleShort ? "valido ✅" : "non valido ❌")} | " +
                      $"Base: {rsiBaseValueShort:F2} | Sup: {rsiSuperiorValueShort:F2} | Δ: {deltaShort:F2} | " +
                      GeneraStatoFiltriRSI(diagnosiShort, false));

                // Logica conferma SHORT (solo se non abbiamo già eseguito un segnale pendente)
                if (!shortExecuted)
                {
                    if (segnaleShort)
                    {
                        confermaBarreShort++;
                        Print($"🕒 Segnale SHORT in conferma: {confermaBarreShort}/{MinBarreConfermaSegnale}");

                        if (confermaBarreShort >= MinBarreConfermaSegnale)
                        {
                            // In modalità TrendFollowing un segnale SHORT è generato quando l'RSI è basso (ipervenduto)
                            // e viene tradotto in una posizione SHORT (non LONG come in Contrarian)
                            bool apriLong = false; // Aprire SEMPRE SHORT quando il segnale è SHORT

                            if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraConferma)
                            {
                                lastSignalTimeShort = Time;
                                DrawSegnaleGraficoRSI(apriLong, Time, prezzo);
                                EseguiSegnaleRSI(apriLong, Time, prezzo);
                                Print($"✅ Segnale SHORT confermato e eseguito (chiusura barra conferma)");
                                confermaBarreShort = 0;
                                pendingExecutionShortTime = null;
                                pendingSignalShortTime = null;
                                pendingShortSignalValid = null;
                            }
                            else if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraSuccessiva)
                            {
                                if (pendingExecutionShortTime == null)
                                {
                                    // Memorizziamo esplicitamente l'apertura della barra corrente come riferimento
                                    pendingExecutionShortTime = Bars.OpenTimes.Last();
                                    pendingSignalShortTime = Time;
                                    pendingShortSignalValid = apriLong;
                                    Print($"🕒 Segnale SHORT confermato su barra {pendingExecutionShortTime.Value.ToString("dd/MM HH:mm")}, attesa chiusura barra successiva");
                                }
                            }
                        }
                    }
                    else
                    {
                        // Non resettare il contatore se c'è già un'esecuzione pendente programmata
                        if (pendingExecutionShortTime == null)
                        {
                            confermaBarreShort = 0;
                        }

                        // Aggiornamento del tempo del segnale pendente
                        if (diagnosiShort.FiltroPersistenzaSuperato || deltaShort >= MinRsiDelta)
                        {
                            if (pendingSignalShortTime == null)
                                pendingSignalShortTime = Time;
                        }
                        else
                        {
                            pendingSignalShortTime = null;
                        }
                    }
                }

                // Logging diagnostico per timing e segnali
                if (segnaleLong || segnaleShort)
                {
                    string tipoSegnale = segnaleLong ? "LONG" : "SHORT";
                    Print($"🔍 [TIMING] Segnale {tipoSegnale} valido - Verifico timing apertura...");
                    Print($"🔍 [TIMING] Modalità: {ModalitaTimingApertura}, MinBarreConfermaSegnale: {MinBarreConfermaSegnale}");
                }

                // Debugging esecuzioni pendenti
                if (pendingExecutionLongTime != null || pendingExecutionShortTime != null)
                {
                    Print($"🔄 [DEBUG ESECUZIONI PENDENTI] LONG: {(pendingExecutionLongTime != null ? pendingExecutionLongTime.Value.ToString() : "nessuna")}, " +
                          $"SHORT: {(pendingExecutionShortTime != null ? pendingExecutionShortTime.Value.ToString() : "nessuna")}");
                }

                // Aggiorna HUD e altri elementi grafici
                if (ShowRSIDiagnostics && ShowHUD)
                    DrawHUD_RSI();

                // Pulizia etichette obsolete
                CleanupRSILabels();
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in OnBar: {ex.Message}");
            }
        }

        // ==========================================================================
        // 📡 ON TICK
        // ==========================================================================
        protected override void OnTick()
        {
            // Verifica periodica della licenza (ogni giorno)
            if (!isLicenseValid || (licenseExpirationDate != DateTime.MinValue &&
                licenseExpirationDate < Server.Time))
            {
                if (!VerifyLicense()) // Replace CheckLicense with VerifyLicense
                    return;
                if (!isLicenseValid)
                    return; ;
            }

            // Verifica periodica degli aggiornamenti
            if ((Server.Time - lastUpdateCheck).TotalHours >= 24)
                CheckForUpdates();

            // Controllo per rimuovere il messaggio della licenza dopo il tempo configurato
            if (_licenseInfoDisplayed && LicenseInfoDisplaySeconds > 0 &&
                (Server.Time - _licenseInfoDisplayTime).TotalSeconds >= LicenseInfoDisplaySeconds)
            {
                Chart.RemoveObject("license_info");
                _licenseInfoDisplayed = false;
                Print($"[License] Messaggio info licenza rimosso dopo {LicenseInfoDisplaySeconds} secondi");
            }

            if (Mode == ExecutionMode.OnTick)
                ExecuteLogic();

            // Aggiorna periodicamente lo stato EMA
            if (EnableEmaFilter && ema != null && (Server.Time.Second % 5 == 0))
            {
                var (_, recommendation, recommendationColor) = CheckPriceAgainstEMA();
                emaStatus = recommendation;
                emaStatusColor = recommendationColor;
            }

            // Esecuzione principale se abilitata in modalità "OnBar"
            if (Mode == ExecutionMode.OnTick)
            {
                // Queste chiamate riguardano solo HUD e monitoraggio
                Print("▶ [DEBUG] OnBar() attivato - Time: " + Time);
                AggiornaRSI(true);   // LONG
                AggiornaRSI(false);  // SHORT
            }

            // Verifica se non ci sono posizioni aperte ma i valori non sono stati resettati
            if (!Positions.Any(p => p.SymbolName == SymbolName) && (maxTP > 0 || tpDinamicoAttivato))
            {
                ResetTPDynamicValues();
            }

            // Calcolo profitto netto attuale su tutte le posizioni aperte
            double netProfit = GetNetProfitSymbol();

            // Gestione TP Dinamico (spostata qui da OnBar)
            var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            if (positions.Any())
            {
                // double netProfit = positions.Sum(p => p.NetProfit);
                ManageTakeProfit(positions, netProfit);
            }

            // IMPORTANTE: Verifica sempre il TP Dinamico indipendentemente dalla modalità generale
            if (EnableTrailingTP)
            {
                ManageDynamicTP(positions, netProfit);
            }

            CleanupRSILabels();

            // Aggiorna il contatore recovery in base alle posizioni attualmente aperte
            recoveryCount = GetActiveRecoveryCount();

            if (ShowHUD)
            {
                // Recupero posizioni per il simbolo corrente
                var posizioni = Positions.Where(p => p.SymbolName == SymbolName).ToList();
                double profitto = posizioni.Sum(p => p.NetProfit);
                double breakEven = GetBreakEvenPrice(posizioni);
                double referenceValue = GetRecoveryReferenceValue();
                double recoveryDD = -SafeDivide(netProfit, referenceValue) * 100.0;

                int posizioniAperte = posizioni.Count;

                // Aggiornamento TP dinamico (1 volta al secondo)
                if ((Server.Time - lastTPDynamicUpdate).TotalSeconds >= 1)
                {
                    var tpDynamicInfo = CalculateDynamicTPThreshold(posizioni);
                    lastCalculatedMinProfitToClose = tpDynamicInfo.minProfitToClose;
                    lastTPDynamicStatus = tpDynamicInfo.statusMessage;
                    lastTPDynamicColor = tpDynamicInfo.statusColor;
                    lastTPDynamicProgress = tpDynamicInfo.progress;
                    lastTPDynamicUpdate = Server.Time;
                }

                // Condizione di aggiornamento HUD (solo se cambia qualcosa)
                bool necessitaAggiornamentoHUD =
                    profitto != lastProfitHUD ||
                    recoveryDD != lastRecoveryDDHUD ||
                    posizioniAperte != lastPosizioniAperteHUD ||
                    breakEven != lastBreakEvenHUD ||
                    recoveryCount != lastRecoveryCountHUD;

                if (necessitaAggiornamentoHUD)
                {
                    var refPos = posizioni.LastOrDefault();
                    DrawHUD(profitto, maxTP, recoveryDD, 0, breakEven, refPos);

                    lastProfitHUD = profitto;
                    lastRecoveryDDHUD = recoveryDD;
                    lastRecoveryCountHUD = recoveryCount;
                    lastBreakEvenHUD = breakEven;
                    lastPosizioniAperteHUD = posizioniAperte;
                }

                // ➤ LOGICA BREAKEVEN ATTIVO
                if (EnableBE && triggerBreakevenAttivo && posizioni.Any())
                {
                    double targetFixedTP = BETrigger * (1 - TriggerDDBE / 100.0);
                    var refPos = posizioni.LastOrDefault();
                    if (refPos != null)
                        DrawBreakEvenLineSafe(refPos, targetFixedTP);

                    double profittoAttuale = posizioni.Sum(p => p.NetProfit);
                    GestioneBreakEven(posizioni, profittoAttuale);
                }

                

                // ➤ Diagnostica multi-simbolo attiva
                DiagnosticaMultiSimboloHUD();

               

            }
        }

        // Nuovo metodo per processare i segnali RSI in base al timing configurato
        private void ProcessareSegnaliRSI(bool longValid, bool shortValid)
        {
            bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;
            double currentPrice = Symbol.Bid;

            // Se è richiesta conferma su più barre, aggiorna contatori
            if (AbilitaBarreConfermaSegnale && MinBarreConfermaSegnale > 0)
            {
                // Gestione contatori
                if (longValid)
                {
                    consecutiveValidLong++;
                    lastValidatedBarTimeLong = Time;
                    if (consecutiveValidLong >= MinBarreConfermaSegnale)
                    {
                        Print($"🔍 [TIMING] Segnale LONG valido - Verifico timing apertura...");
                        Print($"🔍 [TIMING] Modalità: {ModalitaTimingApertura}, MinBarreConfermaSegnale: {MinBarreConfermaSegnale}");

                        if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraConferma)
                        {
                            EseguiSegnaleRSI(true, Time, currentPrice);
                            consecutiveValidLong = 0;
                        }
                    }
                }
                else
                {
                    consecutiveValidLong = 0;
                }

                if (shortValid)
                {
                    consecutiveValidShort++;
                    lastValidatedBarTimeShort = Time;
                    if (consecutiveValidShort >= MinBarreConfermaSegnale)
                    {
                        Print($"🔍 [TIMING] Segnale SHORT valido - Verifico timing apertura...");
                        Print($"🔍 [TIMING] Modalità: {ModalitaTimingApertura}, MinBarreConfermaSegnale: {MinBarreConfermaSegnale}");

                        if (ModalitaTimingApertura == TimingAperturaPosizione.AllaChiusuraBarraConferma)
                        {
                            EseguiSegnaleRSI(false, Time, currentPrice);
                            consecutiveValidShort = 0;
                        }
                    }
                }
                else
                {
                    consecutiveValidShort = 0;
                }
            }
            else
            {
                // Esecuzione immediata senza conferma
                if (longValid)
                    EseguiSegnaleRSI(true, Time, currentPrice);

                if (shortValid)
                    EseguiSegnaleRSI(false, Time, currentPrice);
            }
        }

        //==========================================================================
        // ⚙️ EXECUTE LOGIC
        //==========================================================================
        private void ExecuteLogic()
        {

            var positions = Positions
                .Where(p => p.SymbolName == SymbolName)
                .OrderBy(p => p.EntryTime)
                .ToList();

            if (!positions.Any())
            {
                Reset();
                Chart.RemoveObject("BreakEvenTriggerLine");
                Chart.RemoveObject("BreakEvenTriggerLabel");

                if (ShowHUD)
                    DrawHUD(0, 0, 0, 0, Symbol.Bid, null);

                triggerBreakevenAttivo = false;
                return;
            }

            double netProfit = GetNetProfitSymbol();
            double breakEven = GetBreakEvenPrice(positions);
            Position reference = positions.LastOrDefault();

            // Gestione TP (Dinamico o Fisso)
            ManageTakeProfit(positions, netProfit);

            // Aggiornamento massimi
            if (netProfit > maxTP) maxTP = netProfit;
            if (netProfit > maxFixedTP) maxFixedTP = netProfit;
            if (Account.Equity > maxEquity) maxEquity = Account.Equity;

            double riferimentoRecovery = GetRecoveryReferenceValue();
            double recoveryDD = Math.Max(0, -netProfit / riferimentoRecovery * 100.0);
            double recoveryPips = reference != null ? Math.Abs(Symbol.Bid - reference.EntryPrice) / Symbol.PipSize : 0;

            actualDDpercent = recoveryDD;

            // Aggiorna il contatore recovery in base alle posizioni attualmente aperte
            recoveryCount = GetActiveRecoveryCount();

            // === GESTIONE BREAKEVEN ===
            if (EnableBE)
            {
                double triggerTarget = BETrigger;
                if (!triggerBreakevenAttivo && netProfit >= triggerTarget)
                {
                    triggerBreakevenAttivo = true;
                    fixedBreakEvenProfitThreshold = netProfit * (1 - TriggerDDBE / 100.0);
                    Print($"🎯 Trigger BE attivato! Profit: {netProfit:F2}€, Soglia fissata: {fixedBreakEvenProfitThreshold:F2}€");
                    DrawBreakEvenLineSafe(reference, fixedBreakEvenProfitThreshold);
                }

                if (triggerBreakevenAttivo)
                {
                    GestioneBreakEven(positions, netProfit);
                    // Non fare return qui, permetti l'esecuzione del TP Dinamico
                }
            }

            // === TP DINAMICO ===
            if (EnableTrailingTP)
                ManageDynamicTP(positions, netProfit);

            // Aggiungi questo codice nella funzione ExecuteLogic() dopo la gestione del Take Profit/BE
            if (EnableRecoveryTrailingStopLoss && positions.Any() && recoveryCount > 0)
            {
                ManageRecoveryTrailingStopLoss(positions);
            }

            // === RECOVERY === 
            // IMPORTANTE: eseguiamo il recovery solo se non siamo in fase di trailing o breakeven
            // Permetti recovery se siamo sotto il TPStart o se siamo tornati a una perdita significativa
            if (EnableRecovery && !triggerBreakevenAttivo &&
                (maxTP < TPStart || (netProfit < 0 && recoveryDD >= RecoveryTriggerPercent)))
                TryRecovery(positions, recoveryDD, recoveryPips);
            else
                Print("[DEBUG] TryRecovery non chiamato perché EnableRecovery = false");

            if (ShowHUD)
                DrawHUD(netProfit, maxTP, recoveryDD, recoveryPips, breakEven, reference);

           // var positions = Positions.FindAll(SymbolName);

            // ... altra logica esistente ...

            // Gestione del TSL per i recovery normali
            if (EnableRecoveryTrailingStopLoss)
            {
                ManageRecoveryTrailingStopLoss(positions);
            }

            // Gestione del TSL per i recovery estesi
            if (_extendedRecoveryModule != null)
            {
                _extendedRecoveryModule.ManageExtendedRecoveryTrailingStopLoss(positions);
            }
        }

        // Modifica il metodo ManageRecoveryTrailingStopLoss per tracciare le posizioni chiuse
        private void ManageRecoveryTrailingStopLoss(List<Position> positions)
        {
            try
            {
                // Rimozione oggetti grafici se non ci sono posizioni di recovery
                if (!positions.Any() || !EnableRecoveryTrailingStopLoss)
                {
                    CleanupAllTslLines();
                    trailingStopLossAttivo = false;
                    lastTrailingStopLossPrice = 0;
                    return;
                }

                // Identifica le posizioni di recovery nel simbolo corrente
                var recoveryPositions = positions.Where(p =>
                    p.SymbolName == SymbolName &&
                    ((p.Label != null && p.Label.Contains("RECOVERY")) ||
                     (p.Comment != null && p.Comment.Contains("RECOVERY")))).ToList();

                if (!recoveryPositions.Any())
                {
                    CleanupAllTslLines();
                    trailingStopLossAttivo = false;
                    lastTrailingStopLossPrice = 0;
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"\n• TRAILING STOPLOSS PER RECOVERY ({Symbol.Name}):");
                bool anyActive = false;

                // Gestisci ogni posizione recovery individualmente
                foreach (var position in recoveryPositions)
                {
                    string positionId = $"{position.Id}";
                    string positionLabel = position.Label ?? position.Comment ?? "Unlabeled";
                    double positionProfit = position.NetProfit;

                    // Ottieni o crea il tracker per questa posizione
                    if (!tslPositionTrackers.ContainsKey(position.Id))
                    {
                        tslPositionTrackers[position.Id] = new TslPositionData(position.Id, positionLabel);
                    }

                    var tracker = tslPositionTrackers[position.Id];

                    // Verifica se il trailing stop è già attivo per questa posizione
                    if (!tracker.IsActive)
                    {
                        // Attiva il trailing quando il profitto della SINGOLA posizione supera il trigger
                        if (positionProfit >= RecoveryTrailingStopLossTriggerEuro)
                        {
                            tracker.IsActive = true;
                            tracker.MaxProfit = positionProfit;
                            tracker.StopLossValue = positionProfit * (1 - RecoveryTrailingStopLossDistancePercent / 100.0);
                            tracker.Volume = Symbol.VolumeInUnitsToQuantity(position.VolumeInUnits);
                            tracker.Direction = position.TradeType;

                            Print($"🔄 Trailing StopLoss attivato per posizione {positionId} ({positionLabel}) a {positionProfit:F2}€");
                            sb.AppendLine($"  ✅ ATTIVO posizione {positionLabel}: {positionProfit:F2}€");
                            sb.AppendLine($"  ➤ Stop: {tracker.StopLossValue:F2}€ | Massimo: {tracker.MaxProfit:F2}€");

                            // Aggiorna lo stato generale per compatibilità
                            if (!trailingStopLossAttivo)
                            {
                                trailingStopLossAttivo = true;
                                lastTrailingStopLossPrice = positionProfit;
                            }

                            anyActive = true;

                            // Disegna una linea TSL specifica per questa posizione
                            DrawIndividualTslLine(position, tracker.MaxProfit, tracker.StopLossValue);
                        }
                        else
                        {
                            sb.AppendLine($"  ⏳ In attesa trigger per {positionLabel}: {positionProfit:F2}€/{RecoveryTrailingStopLossTriggerEuro}€");
                        }
                    }
                    else
                    {
                        // Aggiorna il massimo profitto se superato
                        if (positionProfit > tracker.MaxProfit)
                        {
                            tracker.MaxProfit = positionProfit;
                            tracker.StopLossValue = positionProfit * (1 - RecoveryTrailingStopLossDistancePercent / 100.0);
                            Print($"🔄 Nuovo massimo profitto per posizione {positionId} ({positionLabel}): {positionProfit:F2}€");

                            // Aggiorna la linea TSL per questa posizione
                            DrawIndividualTslLine(position, tracker.MaxProfit, tracker.StopLossValue);
                        }

                        sb.AppendLine($"  ✅ ATTIVO posizione {positionLabel}: attuale {positionProfit:F2}€");
                        sb.AppendLine($"  ➤ Max: {tracker.MaxProfit:F2}€ | Stop: {tracker.StopLossValue:F2}€ | Chiusura futura: {tracker.StopLossValue:F2}€");

                        anyActive = true;

                        // Verifica se è stato raggiunto lo stop loss
                        if (positionProfit <= tracker.StopLossValue)
                        {
                            Print($"🛑 Trailing StopLoss raggiunto per posizione {positionId} ({positionLabel}): chiusura a {positionProfit:F2}€");

                            // Memorizza informazioni dettagliate prima di chiudere
                            var closedPosition = new TslPositionData(
                                positionLabel,
                                lastRecoveryDrawdown,
                                GetRecoveryReferenceValue(),
                                position.TradeType,
                                Symbol.VolumeInUnitsToQuantity(position.VolumeInUnits),
                                Server.Time
                            );
                            closedPosition.PositionId = position.Id;

                            // Chiudi la posizione
                            var result = position.Close();
                            if (result.IsSuccessful)
                            {
                                Print($"✅ Posizione {positionId} ({positionLabel}) chiusa con successo tramite TSL");

                                // Rimuovi la linea TSL solo per questa posizione
                                RemoveTslLine(position.Id);
                                tslPositionTrackers.Remove(position.Id);

                                // Aggiungi alla lista con dati completi
                                tslClosedPositions.Add(closedPosition);
                                Print($"📝 Posizione {positionLabel} aggiunta all'elenco delle posizioni chiuse da TSL con dati completi");

                                // Aggiorna il contatore recovery dopo la chiusura
                                UpdateRecoveryCounter();
                            }
                            else
                            {
                                Print($"❌ Errore nella chiusura della posizione {positionId} ({positionLabel}): {result.Error}");
                            }
                        }
                    }
                }

                // Usa il valore di 'anyActive' per aggiornare lo stato generale
                if (!anyActive)
                {
                    trailingStopLossAttivo = false;
                    lastTrailingStopLossPrice = 0;
                }

                // Fai pulizia dei tracker per posizioni chiuse
                CleanupTslTrackers(positions);

                // Aggiorna info HUD con informazioni dettagliate
                trailingTPWarningHUD = sb.ToString();
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in ManageRecoveryTrailingStopLoss: {ex.Message}");
                Print($"Stack: {ex.StackTrace}");
            }
        }


        // Nuovo metodo per disegnare una linea TSL specifica per una singola posizione
        private void DrawIndividualTslLine(Position position, double maxProfit, double slValue)
        {
            try
            {
                string lineId = $"{TRAILING_SL_LINE}_{position.Id}";
                string labelId = $"{TRAILING_SL_LINE}_{position.Id}_label";

                // Rimuovi oggetti esistenti specifici per questa posizione
                Chart.RemoveObject(lineId);
                Chart.RemoveObject(labelId);

                // Calcola il prezzo dello stop loss per questa posizione
                double pipValue = position.Quantity * Symbol.PipValue;
                if (pipValue <= 0.0000001)
                {
                    pipValue = 0.0001;
                }

                // Calcoliamo direttamente il prezzo per slValue
                double pointsForSL = slValue / pipValue;

                double slPrice;
                if (position.TradeType == TradeType.Buy)
                {
                    slPrice = position.EntryPrice + pointsForSL;
                }
                else
                {
                    slPrice = position.EntryPrice - pointsForSL;
                }

                if (double.IsNaN(slPrice) || double.IsInfinity(slPrice) || slPrice <= 0)
                {
                    slPrice = position.EntryPrice;
                }

                // Crea il testo dell'etichetta con informazioni complete
                string positionLabel = position.Label ?? position.Comment ?? $"Pos #{position.Id}";
                string symbolInfo = $"Symbol: {Symbol.Name}";
                string maxProfitInfo = $"Massimo: {maxProfit:F2}€";
                string stopInfo = $"Stop: {slValue:F2}€";
                string ddInfo = $"DD: {RecoveryTrailingStopLossDistancePercent}%";
                string volumeInfo = $"Vol: {Symbol.VolumeInUnitsToQuantity(position.VolumeInUnits):F2} lots";

                string labelText = $"🛑 Recovery TSL - {positionLabel}\n{symbolInfo} | {maxProfitInfo}\n{stopInfo} | {ddInfo} | {volumeInfo}";

                // Disegna la linea orizzontale specifica per questa posizione
                Chart.DrawHorizontalLine(lineId, slPrice, Color.MediumVioletRed, 1, LineStyle.DotsRare);

                // Disegna l'etichetta specifica per questa posizione
                var label = Chart.DrawText(
                    labelId,
                    labelText,
                    Server.Time,
                    slPrice,
                    Color.MediumVioletRed
                );

                // Imposta dimensione del font
                label.FontSize = 11;

                Print($"🖌️ Disegnata linea TSL per {positionLabel} a prezzo {slPrice:F5} (max: {maxProfit:F2}€, stop: {slValue:F2}€)");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore disegno TSL per posizione {position.Id}: {ex.Message}");
            }
        }

        // Nuovo metodo per rimuovere la linea e l'etichetta TSL di una specifica posizione
        private void RemoveTslLine(int positionId)
        {
            string lineId = $"{TRAILING_SL_LINE}_{positionId}";
            string labelId = $"{TRAILING_SL_LINE}_{positionId}_label";

            Chart.RemoveObject(lineId);
            Chart.RemoveObject(labelId);

            Print($"🧹 Rimossa linea TSL per posizione {positionId}");
        }

        // Nuovo metodo per rimuovere tutte le linee e etichette TSL
        private void CleanupAllTslLines()
        {
            // Rimuovi la linea e l'etichetta generale (backward compatibility)
            Chart.RemoveObject(TRAILING_SL_LINE);
            Chart.RemoveObject(TRAILING_SL_LINE + "_label");

            // Rimuovi anche le linee specifiche per ogni posizione
            foreach (var tracker in tslPositionTrackers)
            {
                RemoveTslLine(tracker.Key);
            }

            Print($"🧹 Rimosse tutte le linee TSL");
        }

        // Aggiungi/modifica questo metodo per calcolare il numero di posizioni recovery attive
        private int GetActiveRecoveryCount()
        {
            // Conta le posizioni attive che hanno la parola "RECOVERY" nella label o nel commento
            return Positions.Count(p =>
                p.SymbolName == SymbolName &&
                ((p.Label != null && p.Label.Contains("RECOVERY")) ||
                 (p.Comment != null && p.Comment.Contains("RECOVERY")))
            );
        }
        private void CleanupTslTrackers(List<Position> activePositions)
        {
            try
            {
                // Rimuovi i tracker per posizioni che non esistono più
                var activeIds = activePositions.Select(p => p.Id).ToHashSet();
                var keysToRemove = tslPositionTrackers.Keys.Where(id => !activeIds.Contains(id)).ToList();

                foreach (var key in keysToRemove)
                {
                    tslPositionTrackers.Remove(key);
                    Print($"🧹 Rimosso tracker per posizione ID {key}");
                }

                // Verifica se c'è ancora qualche posizione con TSL attivo
                var anyTslActive = tslPositionTrackers.Any(t => t.Value.IsActive);

                // Se non ci sono più posizioni con TSL attivo, ripulisci completamente
                if (!anyTslActive)
                {
                    trailingStopLossAttivo = false;
                    lastTrailingStopLossPrice = 0;

                    // Rimuovi definitivamente gli oggetti grafici
                    Chart.RemoveObject(TRAILING_SL_LINE);
                    Chart.RemoveObject(TRAILING_SL_LINE + "_label");
                    Print($"🧹 Reset completo stato TSL - Nessuna posizione attiva");
                }
                else
                {
                    trailingStopLossAttivo = true;

                    // Se c'è almeno una posizione attiva, aggiorna il massimo profitto complessivo
                    var maxActiveProfit = tslPositionTrackers
                        .Where(t => t.Value.IsActive)
                        .Max(t => t.Value.MaxProfit);

                    lastTrailingStopLossPrice = maxActiveProfit;
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in CleanupTslTrackers: {ex.Message}");
            }
        }

        private void DrawRecoveryTrailingStopLossLine(List<Position> positions, double maxProfit, double slValue)
        {
            try
            {
                Print("\n===== INIZIO CALCOLO TRAILING STOPLOSS LINE =====");
                Print($"Parametri iniziali: maxProfit={maxProfit:F2}€, slValue={slValue:F2}€");

                Chart.RemoveObject(TRAILING_SL_LINE);
                Chart.RemoveObject(TRAILING_SL_LINE + "_label");
                Print("Oggetti grafici precedenti rimossi");

                // Se non ci sono posizioni, non disegniamo nulla
                if (!positions.Any() || maxProfit <= 0)
                {
                    Print("Nessuna posizione o maxProfit <= 0, uscita dal metodo");
                    return;
                }

                Print($"Numero di posizioni: {positions.Count}");

                // Ottieni la posizione di riferimento per il calcolo del prezzo
                var referencePos = positions.FirstOrDefault();
                if (referencePos == null)
                {
                    Print("Posizione di riferimento nulla, uscita dal metodo");
                    return;
                }

                Print($"Posizione di riferimento ID: {referencePos.Id}, TradeType: {referencePos.TradeType}, EntryPrice: {referencePos.EntryPrice:F5}");

                // Calcola il prezzo effettivo dove posizionare la linea di stop loss
                Print("\n--- CALCOLO PREZZO STOPLOSS ---");
                double pipValue = referencePos.Quantity * Symbol.PipValue;
                Print($"Quantity: {referencePos.Quantity}, Symbol.PipValue: {Symbol.PipValue}, pipValue calcolato: {pipValue:F8}");

                // Controlla se pipValue è troppo piccolo o zero
                if (pipValue <= 0.0000001)
                {
                    Print($"⚠️ ATTENZIONE: pipValue quasi zero o negativo: {pipValue:F10}");
                    // Usa un valore di fallback per evitare divisione per zero
                    pipValue = 0.0001;
                    Print($"Usando valore fallback: {pipValue:F4}");
                }

                // MODIFICA PRINCIPALE: Ora calcoliamo direttamente il prezzo per slValue (non per la differenza)
                // Il valore slValue è già il livello di profitto con il drawdown applicato
                double pointsForSL = slValue / pipValue;
                Print($"Points for SL: slValue / pipValue = {slValue:F2} / {pipValue:F8} = {pointsForSL:F5}");

                // Calcolo del valore in pips
                double pipsForSL = pointsForSL / Symbol.PipSize;
                Print($"Pips for SL: pointsForSL / Symbol.PipSize = {pointsForSL:F5} / {Symbol.PipSize:F5} = {pipsForSL:F2} pips");

                double slPrice;
                if (referencePos.TradeType == TradeType.Buy)
                {
                    slPrice = referencePos.EntryPrice + pointsForSL;
                    Print($"BUY: slPrice = EntryPrice + pointsForSL = {referencePos.EntryPrice:F5} + {pointsForSL:F5} = {slPrice:F5}");
                }
                else
                {
                    slPrice = referencePos.EntryPrice - pointsForSL;
                    Print($"SELL: slPrice = EntryPrice - pointsForSL = {referencePos.EntryPrice:F5} - {pointsForSL:F5} = {slPrice:F5}");
                }

                Print("\n--- CONTROLLI DI VALIDITÀ ---");
                Print($"Prezzo di stop loss calcolato: {slPrice:F5}");
                Print($"Bid attuale: {Symbol.Bid:F5}, Ask attuale: {Symbol.Ask:F5}");

                if (double.IsNaN(slPrice) || double.IsInfinity(slPrice) || slPrice <= 0)
                {
                    Print($"⚠️ ATTENZIONE: prezzo stop loss non valido: {slPrice:F5}");
                    // Usa il prezzo di entrata come fallback
                    slPrice = referencePos.EntryPrice;
                    Print($"Usando prezzo di entrata come fallback: {slPrice:F5}");
                }

                // Confronto con prezzo attuale
                double distanzaInPips = Math.Abs(Symbol.Bid - slPrice) / Symbol.PipSize;
                Print($"Distanza dal prezzo attuale: {distanzaInPips:F1} pips");

                // Preparazione testo dell'etichetta con informazioni complete
                Print("\n--- PREPARAZIONE ETICHETTA ---");
                string symbolInfo = $"Symbol: {Symbol.Name}";
                string maxProfitInfo = $"Massimo: {maxProfit:F2}€";
                string stopInfo = $"Stop: {slValue:F2}€";
                string ddInfo = $"DD: {RecoveryTrailingStopLossDistancePercent}%";

                string labelText = $"🛑 Recovery TSL\n{symbolInfo}\n{maxProfitInfo}\n{stopInfo}\n{ddInfo}";
                Print($"Testo dell'etichetta preparato: \n{labelText}");

                Print("\n--- DISEGNO OGGETTI GRAFICI ---");
                Print($"Disegno linea orizzontale al prezzo di STOP LOSS: {slPrice:F5}");
                Chart.DrawHorizontalLine(TRAILING_SL_LINE, slPrice, Color.OrangeRed, 1, LineStyle.DotsRare);

                // Disegna l'etichetta allo stesso prezzo della linea di stop loss
                Print($"Disegno etichetta alla stessa posizione Y: {slPrice:F5}");
                var label = Chart.DrawText(
                    TRAILING_SL_LINE + "_label",
                    labelText,
                    Server.Time,
                    slPrice,  // Etichetta posizionata allo stesso livello della linea di stop loss
                    Color.OrangeRed
                );

                // Aggiungiamo dimensione del font
                label.FontSize = 11;
                Print($"Dimensione font etichetta impostata a 11");

                Print($"🖌️ Disegnata linea TSL a prezzo {slPrice:F5} (max profit: {maxProfit:F2}€, SL value: {slValue:F2}€)");
                Print("===== FINE CALCOLO TRAILING STOPLOSS LINE =====\n");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore disegno Trailing SL: {ex.Message}");
                Print($"Stack trace: {ex.StackTrace}");
            }
        }

        private bool HasRecentTSLClosures()
        {
            // Considera chiusure negli ultimi 30 minuti come recenti
            return tslClosedPositions.Any(p => p.CloseTime.HasValue &&
                                            (Server.Time - p.CloseTime.Value).TotalMinutes < 30);
        }

        //==========================================================================
        // ⚙️ MANAGE TAKE PROFIT
        //==========================================================================
        private void ManageTakeProfit(List<Position> positions, double netProfit)
        {
            if (positions.Count == 0) return;

            Print($"\n=== DEBUG TP DINAMICO ===");
            Print($"Simbolo: {Symbol.Name}");
            Print($"Spread: {Symbol.Spread}");
            Print($"PipValue: {Symbol.PipValue}");
            Print($"PipSize: {Symbol.PipSize}");
            Print($"Net Profit: {netProfit:F2}€");
            Print($"Max TP: {maxTP:F2}€");
            Print($"Threshold: {GetTrailingTPThreshold(maxTP):F2}€");

            if (!positions.Any()) return;
            if (!IsSpreadSafeForClosing()) return;

            // === GESTIONE TP FISSO ===
            if (EnableFixedTP && !EnableTrailingTP)
            {
                double targetProfit = FixedTPAmount;

                if (netProfit >= targetProfit)
                {
                    // Usa il nuovo metodo GetSymbolMargin per un calcolo corretto
                    bool minProfitOK = !EnableMinProfitCheck || CheckMinProfit(positions);
                    if (minProfitOK)
                    {
                        Print($"✅ TP Fisso raggiunto: {netProfit:F2}€ ≥ {targetProfit:F2}€");
                        SafeCloseAllPositions();
                    }
                    else
                    {
                        Print($"⚠️ Chiusura TP Fisso ritardata: MinProfit non soddisfatto");
                    }
                }
                return;
            }

            // Verifica se il recovery esteso può chiudere tutte le posizioni
            if (_extendedRecoveryModule != null && _extendedRecoveryModule.IsExtendedModeActive)
            {
                if (_extendedRecoveryModule.CheckForCoordinatedExit(positions, netProfit))
                {
                    Print("🎯 Chiusura coordinata per recovery esteso attivata!");
                    SafeCloseAllPositions();
                    return; // Importante: esci dopo aver chiuso le posizioni
                }
            }

            // === GESTIONE TP DINAMICO ===
            if (EnableTrailingTP)
            {
                double effectiveTPStart = CalculateEffectiveTPStart();

                // Aggiornamento maxTP se il profitto è salito
                if (netProfit > maxTP)
                {
                    maxTP = netProfit;
                    DebugLog($"📈 Nuovo MaxTP: {maxTP:F2}€");
                }

                // CORREZIONE: Se maxTP supera TPStart, attiva il trailing
                if (maxTP >= effectiveTPStart && !tpDinamicoAttivato)
                {
                    tpDinamicoAttivato = true;
                    DebugLog($"🚀 TP Dinamico ATTIVATO: MaxTP {maxTP:F2}€ ha superato soglia {effectiveTPStart:F2}€");
                }

                // Procedi solo se il TP Dinamico è attivato
                if (tpDinamicoAttivato)
                {
                    double trailingThreshold = GetTrailingTPThreshold(maxTP);

                    // Aggiorna la linea e l'etichetta del TP Dinamico
                    DrawTPDynamicLineSafe(positions, trailingThreshold);

                    DebugLog($"[TPD] MaxTP: {maxTP:F2}€, Threshold: {trailingThreshold:F2}€, NetProfit: {netProfit:F2}€");

                    // Verifica condizioni di chiusura - netProfit deve essere sceso sotto la soglia di trailing
                    if (netProfit <= trailingThreshold && netProfit > 0)
                    {
                        bool minProfitOK = !EnableMinProfitCheck || CheckMinProfit(positions);
                        if (minProfitOK)
                        {
                            Print($"✅ TP Dinamico: Chiusura a {netProfit:F2}€ (Max: {maxTP:F2}€, Soglia: {trailingThreshold:F2}€)");
                            SafeCloseAllPositions(trailingThreshold);  // Passa la soglia per verifica
                            lastTrailingUpdateTime = Server.Time;
                        }
                        else
                        {
                            Print($"⚠️ Chiusura TP Dinamico ritardata: MinProfit non soddisfatto");
                        }
                    }
                }
                else
                {
                    DebugLog($"[TPD] Attesa attivazione - MaxTP: {maxTP:F2}€ < Target: {effectiveTPStart:F2}€");
                }
            }

            // Aggiornamento HUD
            UpdateTPStatusHUD(netProfit, EnableTrailingTP ? CalculateEffectiveTPStart() : (EnableFixedTP ? FixedTPAmount : 0));
            UpdateTPStatusHUDWithMinProfit(netProfit,
                                           EnableTrailingTP ? CalculateEffectiveTPStart() : (EnableFixedTP ? FixedTPAmount : 0),
                                           EnableMinProfitCheck ? CalculateRequiredMinProfit(positions) : 0);
        }

        //==========================================================================
        // ⚙️ TRY RECOVERY
        //==========================================================================
        private void TryRecovery(List<Position> positions, double recoveryDD, double recoveryPips)
        {
            if (positions.Count == 0) return;

            Print("\n======== DIAGNOSTICA RECOVERY ========");
            Print($"• EnableRecovery: {EnableRecovery}");
            Print($"• Recovery Reference: {RecoveryReference} = {GetRecoveryReferenceValue():F2}€");
            Print($"• Net Profit: {GetNetProfitSymbol():F2}€");
            double perditaPercentuale = Math.Abs(GetNetProfitSymbol() / GetRecoveryReferenceValue() * 100.0);
            Print($"• Perdita percentuale: {perditaPercentuale:F2}% (Trigger: {RecoveryTriggerPercent:F2}%)");
            Print($"• Free Margin: {Account.FreeMargin:F2}€ (Min: {FreeMarginMinimoEuro:F2}€)");
            double marginLevel = Account.Margin > 0 ? (Account.Equity / Account.Margin) * 100.0 : 0.0;
            Print($"• Margin Level: {marginLevel:F2}% (Min: {MinMarginLevelPercent:F2}%)");
            Print($"• Filtri attivi: RSI={EnableRSIFilter}, Distanza={EnableDistanceFilter}, Swing={EnableSwingFilter}");
            Print($"• ActiveRecoveryCount: {GetActiveRecoveryCount()}/{MaxRecoveryTrades}");
            Print("=======================================\n");

            Print("\n============= ANALISI RECOVERY COMPLETA =============");
            Print($"• RecoveryDD attuale: {recoveryDD:F2}%, Recovery Pips: {recoveryPips:F2}");

            // Aggiornamento contatore posizioni di recovery effettivamente attive
            int activeRecoveryCount = GetActiveRecoveryCount();
            Print($"• Recovery abilitato: {EnableRecovery}, Count: {activeRecoveryCount}/{MaxRecoveryTrades}");

            double netProfit = GetNetProfitSymbol();
            Print($"• Profitto netto: {netProfit:F2}€");

            // Controllo iniziale: deve esserci almeno una posizione non di recovery già aperta
            var nonRecoveryPositions = positions.Where(p => p.Label == null ||
                                                     (!p.Label.Contains("RECOVERY") &&
                                                      !p.Label.StartsWith("ExtRec_"))).ToList();

            if (nonRecoveryPositions.Count == 0)
            {
                Print("⚠️ TryRecovery abortito: nessuna posizione base (non recovery) aperta");
                return;
            }

            // Controllo importante: consenti solo una posizione iniziale non di recovery
            if (nonRecoveryPositions.Count > 1)
            {
                Print($"⚠️ TryRecovery abortito: rilevate {nonRecoveryPositions.Count} posizioni base (deve esserci solo 1)");
                return;
            }

            // === CONTROLLI PRELIMINARI ===
            if (netProfit >= 0)
            {
                Print($"❌ BLOCCO RECOVERY: profitto netto attuale = {netProfit:F2}€ ➜ Nessuna perdita in corso.");
                return;
            }

            // Verifica se è possibile aprire posizioni
            if (!CanOpenNewPositions() || !EnableRecovery)
                return;

            Position last = positions.LastOrDefault();
            if (last == null)
                return;

            // === VERIFICA NUMERO MAX RECOVERY ===
            bool canOpenRegularRecovery = true;
            if (activeRecoveryCount >= MaxRecoveryTrades)
            {
                Print($"❌ BLOCCO RECOVERY: raggiunto numero massimo di recovery attivi ({activeRecoveryCount}/{MaxRecoveryTrades})");
                canOpenRegularRecovery = false;
            }

            // === CALCOLO PERDITA PERCENTUALE ===
            double riferimentoValore = GetRecoveryReferenceValue();
            double perditaAttuale = Math.Abs(netProfit / riferimentoValore * 100.0);

            // === GESTIONE DRAWDOWN DOPO TSL ===
            // Reset lastRecoveryDrawdown solo se non ci sono posizioni di recovery attive e non ci sono state chiusure recenti da TSL
            bool recentTslClosure = tslClosedPositions.Any(p => (Server.Time - p.CloseTime.Value).TotalMinutes < 30);

            // Prosegui con la logica di recovery standard solo se possibile
            if (canOpenRegularRecovery)
            {
                if (activeRecoveryCount == 0)
            {
                // Verifica se ci sono state posizioni chiuse recentemente per TSL
                if (recentTslClosure)
                {
                    // Trova l'ultima posizione chiusa da TSL
                    var lastClosedTsl = tslClosedPositions
                        .Where(p => (Server.Time - p.CloseTime.Value).TotalMinutes < 30)
                        .OrderByDescending(p => p.CloseTime)
                        .FirstOrDefault();

                    if (lastClosedTsl != null)
                    {
                        // Usa il drawdown della posizione chiusa più recente tramite TSL
                        Print($"• Usato drawdown dalla recente chiusura TSL: {lastClosedTsl.InitialDrawdown:F2}%");
                        lastRecoveryDrawdown = lastClosedTsl.InitialDrawdown;
                        lastRecoveryReferenceValue = lastClosedTsl.ReferenceValue;
                    }
                    else if (lastRecoveryDrawdown > 0)
                    {
                        Print($"• Mantenuto drawdown esistente: {lastRecoveryDrawdown:F2}%");
                    }
                }
                else if (lastRecoveryDrawdown > 0)
                {
                    Print($"• Reset stato recovery: tutte le posizioni recovery chiuse precedentemente");
                    lastRecoveryDrawdown = 0.0;
                }
            }
            

            Print($"• Riferimento: {RecoveryReference} = {riferimentoValore:F2}€");
            Print($"• Perdita attuale: {perditaAttuale:F2}%");
            Print($"• Ultimo recovery DD: {lastRecoveryDrawdown:F2}%");
            Print($"• Impostazione DD minimo richiesto: +{MinDDIncreasePercent:F2}%");

            // === VERIFICA SOGLIE DI TRIGGER ===
            // Prima verifica base - il DD deve essere sopra RecoveryTriggerPercent
            if (perditaAttuale < RecoveryTriggerPercent)
            {
                Print($"❌ RECOVERY BLOCCATO: DD insufficiente ({perditaAttuale:F2}%) < Trigger base ({RecoveryTriggerPercent:F2}%)");
                return;
            }

            // Calcolo soglia minima per il recovery successivo
            double sogliaMinima;

            if (activeRecoveryCount == 0 && !recentTslClosure)
            {
                // Prima posizione recovery (senza recenti chiusure TSL) - usa RecoveryTriggerPercent diretto
                sogliaMinima = RecoveryTriggerPercent;
                Print($"🎯 Prima posizione recovery - Soglia base {RecoveryTriggerPercent:F2}%");
            }
            else
            {
                // Posizioni successive - incrementa basandosi sulla perdita della posizione precedente
                double ultimaPerdita = Math.Abs(lastRecoveryDrawdown);
                sogliaMinima = ultimaPerdita + MinDDIncreasePercent;
                Print($"🎯 Recovery successivo - Ultima perdita {ultimaPerdita:F2}% + MinDD {MinDDIncreasePercent:F2}%");
            }

            // Stato dei filtri attivi
            if (!EnableDistanceFilter && !EnableRSIFilter && !EnableSwingFilter)
                Print($"🎯 Filtri disattivati - Usando RecoveryTriggerPercent come base");
            else
                Print($"🎯 Filtri attivi: {(EnableDistanceFilter ? "Distanza ✓ " : "")}{(EnableRSIFilter ? "RSI ✓ " : "")}{(EnableSwingFilter ? "Swing ✓" : "")}");

            Print($"• Perdita attuale: {perditaAttuale:F2}%");
            Print($"• Soglia minima richiesta: {sogliaMinima:F2}%");

            if (perditaAttuale < sogliaMinima)
            {
                Print($"❌ RECOVERY BLOCCATO: perdita attuale ({perditaAttuale:F2}%) < soglia minima ({sogliaMinima:F2}%)");
                return;
            }

            Print($"✅ Perdita sopra soglia minima: {perditaAttuale:F2}% >= {sogliaMinima:F2}% ➜ OK");

            // === CALCOLO VOLUME ===
            Print("\n=== CALCOLO VOLUME RECOVERY ===");
            Print($"• Lotto massimo consentito: {MaxAllowedLots:F2}");
            Print($"• Recovery Multiplier: {RecoveryMultiplier:F2}");
            Print($"• Recovery mode: {SelectedRecoveryMode}, Adaptive: {EnableAdaptiveRecovery}");

            double lastLots = Symbol.VolumeInUnitsToQuantity(last.VolumeInUnits);
            Print($"• Lotti posizione precedente: {lastLots:F4}");

            double calculatedLots = EnableAdaptiveRecovery
                ? CalculateAdaptiveRecoveryLots(last, RecoveryMultiplier)
                : CalculateRecoveryLots(last, RecoveryMultiplier);

            Print($"• Lotti calcolati: {calculatedLots:F4}");

            if (calculatedLots <= 0)
            {
                Print($"❌ RECOVERY BLOCCATO: Volume calcolato non valido ({calculatedLots:F4} <= 0)");
                return;
            }

            if (calculatedLots > MaxAllowedLots)
            {
                Print($"❌ RECOVERY BLOCCATO: Volume troppo alto ({calculatedLots:F4} > {MaxAllowedLots:F2})");
                return;
            }

            Print($"✅ Volume verificato: {calculatedLots:F4} lots ➜ OK");

            // === CALCOLO DRAWDOWN INCREMENTALE ===
            Print("\n=== CALCOLO DRAWDOWN INCREMENTALE ===");

            // Calcolo base utilizzando il metodo dinamico (già gestisce recoveryCount internamente)
            double dynamicDDIncrease = GetDynamicDDIncreasePercent(last, calculatedLots);
            Print($"• Base DD incrementale: {dynamicDDIncrease:F2}% (Tipo calcolo: {DDCalcType})");

            // Applica fattore volatilità se abilitato
            if (EnableAdaptiveRecovery)
            {
                double volatilityFactor = CalculateVolatilityIndex(20);
                Print($"• Fattore volatilità: {volatilityFactor:F2}x");

                // Sensibilità parametrizzata
                double sensitivity = VolatilitySensitivityPercent / 100.0;
                double adjustment = (volatilityFactor - 1.0) * sensitivity;
                Print($"• Sensibilità: {VolatilitySensitivityPercent:F0}%, Adj: {adjustment:F2}");

                // Adatta il DD in base alla volatilità (può aumentare o diminuire)
                dynamicDDIncrease = dynamicDDIncrease * (1.0 + adjustment);
                Print($"• DD adattato per volatilità: {dynamicDDIncrease:F2}%");
            }

            // Calcola target minimo per DD di recovery
            double targetDDminimo = lastRecoveryDrawdown + dynamicDDIncrease;
            Print($"• Soglia DD minima per recovery: {targetDDminimo:F2}%\n(Ultimo Recovery DD {lastRecoveryDrawdown:F2}% + Aggiustamento {dynamicDDIncrease:F2}%)");

            // Verifica peggioramento DD con soglia dinamica
            if (perditaAttuale < targetDDminimo)
            {
                Print($"❌ RECOVERY BLOCCATO: DD insufficiente");
                Print($"• DD Attuale: {perditaAttuale:F2}%");
                Print($"• Ultimo DD: {lastRecoveryDrawdown:F2}%");
                Print($"• Incremento richiesto: +{dynamicDDIncrease:F2}%");
                Print($"• Target minimo: {targetDDminimo:F2}%");
                return;
            }

            Print($"✅ DD verificato: {perditaAttuale:F2}% >= {targetDDminimo:F2}% ➜ OK");

            // === COOLDOWN E DISTANZA ===
            if (EnableDistanceFilter)
            {
                Print("\n=== VERIFICA COOLDOWN E DISTANZA ===");

                if (EnableDynamicCooldown)
                {
                    var cooldown = CalculateDynamicCooldown(positions, RecoveryCooldownPips);
                    Print($"• Cooldown dinamico attivo: {cooldown.IsActive}");

                    if (cooldown.IsActive)
                    {
                        Print($"⏳ Cooldown dinamico bloccante: {cooldown.Status}");
                        Print($"• Volume totale: {positions.Sum(p => Symbol.VolumeInUnitsToQuantity(p.VolumeInUnits)):F2} lots");
                        Print($"• Moltiplicatore: x{cooldown.VolumeMultiplier:F2}");
                        Print($"• Pips richiesti: {cooldown.RequiredPips:F1}");
                        Print($"• Distanza attuale: {cooldown.CurrentDistance:F1}");
                        return;
                    }
                    else
                    {
                        Print($"✅ Cooldown dinamico completato");
                        recoveryCooldownActive = false;
                    }
                }
                else // Cooldown statico originale
                {
                    if (recoveryCooldownActive)
                    {
                        double distanceFromLastRecovery = Math.Abs(Symbol.Bid - lastRecoveryPrice) / Symbol.PipSize;
                        Print($"• Distanza dall'ultimo recovery: {distanceFromLastRecovery:F1} pips");
                        Print($"• Distanza minima richiesta: {RecoveryCooldownPips:F1} pips");

                        if (distanceFromLastRecovery < RecoveryCooldownPips)
                        {
                            Print($"⏳ Cooldown statico bloccante: {distanceFromLastRecovery:F1}/{RecoveryCooldownPips} pips");
                            return;
                        }
                        Print($"✅ Cooldown statico completato");
                        recoveryCooldownActive = false;
                    }
                    else
                    {
                        Print($"• Cooldown statico: non attivo");
                    }
                }
            }

            // === APPLICAZIONE FILTRI SE ATTIVI ===
            Print("\n=== VERIFICA FILTRI AGGIUNTIVI ===");

            if (EnableRSIFilter)
            {
                Print($"• Filtro RSI attivo");
                double rsiValue = Indicators.RelativeStrengthIndex(Bars.ClosePrices, RSIPeriod).Result.LastValue;
                Print($"• RSI attuale: {rsiValue:F2}");
                Print($"• Direzione trade: {last.TradeType}");

                bool rsiValid = (last.TradeType == TradeType.Buy && rsiValue <= RSIMinBuy) ||
                                (last.TradeType == TradeType.Sell && rsiValue >= RSIMaxSell);

                Print($"• Condizioni RSI: Buy <= {RSIMinBuy}, Sell >= {RSIMaxSell}");

                if (!rsiValid)
                {
                    Print("❌ Filtro RSI non superato - Recovery bloccato");
                    return;
                }
                Print($"✅ Filtro RSI superato");
            }

            if (EnableDistanceFilter)
            {
                Print($"• Filtro distanza attivo");
                double distanceFromEntry = Math.Abs(Symbol.Bid - last.EntryPrice) / Symbol.PipSize;

                // Usa distanza dinamica in base ai volumi e modalità
                double dynamicMinDistance = CalculateDynamicDistanceFilter(MinDistancePips, last, calculatedLots);

                Print($"• Distanza dal prezzo di entrata: {distanceFromEntry:F1} pips");
                Print($"• Distanza minima base: {MinDistancePips:F1} pips");
                Print($"• Distanza minima dinamica: {dynamicMinDistance:F1} pips");

                if (distanceFromEntry < dynamicMinDistance)
                {
                    Print("❌ Distanza minima non rispettata - Recovery bloccato");
                    return;
                }
                Print($"✅ Filtro distanza superato");

                // Verifica la distanza dal prezzo di BreakEven
                if (!CheckMinDistanceFromBE(positions, calculatedLots))
                {
                    Print("❌ Distanza dal BreakEven insufficiente - Recovery bloccato");
                    return;
                }
                Print($"✅ Filtro distanza BreakEven superato");
            }

            if (EnableSwingFilter)
            {
                Print($"• Filtro Swing attivo");
                TradeType? swingAttualeFix = TrovaSwingAttuale();
                Print($"• Swing attuale: {swingAttualeFix}");
                Print($"• Direzione trade: {last.TradeType}");

                if (swingAttualeFix == null)
                {
                    Print("❌ Nessuno swing rilevato - Recovery bloccato");
                    return;
                }

                if (swingAttualeFix != last.TradeType)
                {
                    Print("❌ Swing contrario alla direzione del trade - Recovery bloccato");
                    return;
                }
                Print($"✅ Filtro Swing superato");
            }

            // === VERIFICA MARGINI ===
            Print("\n=== VERIFICA REQUISITI MARGINE ===");
            Print($"• Free Margin: {Account.FreeMargin:F2}€");
            Print($"• Minimo richiesto: {FreeMarginMinimoEuro:F2}€");
            Print($"• Margin Level: {(Account.Margin > 0 ? (Account.Equity / Account.Margin) * 100.0 : 0.0):F2}%");
            Print($"• Minimo richiesto: {MinMarginLevelPercent:F2}%");

            if (!CheckMarginRequirements())
            {
                Print("❌ Requisiti di margine non soddisfatti - Recovery bloccato");
                return;
            }
            Print($"✅ Requisiti di margine soddisfatti");

            // === DEBUG INFO DISTANZE DINAMICHE ===
            Print(GetDynamicDistancesDebugInfo());

            // === ESECUZIONE RECOVERY ===
            Print("\n=== ESECUZIONE RECOVERY ===");
            string label = GenerateRecoveryLabel();
            string comment = label; // Usa esattamente la stessa label come commento
            Print($"• Label: {label}");
            Print($"• Comment: {comment}");

            var volume = Symbol.QuantityToVolumeInUnits(calculatedLots);
            Print($"• Volume convertito: {volume} unità");

            if (volume <= 0)
            {
                Print($"❌ Conversione volume in unità fallita: {volume}");
                return;
            }

            Print($"• Esecuzione ordine: {last.TradeType}, {volume} unità, {Symbol.Name}");

            try
            {
                var result = ExecuteMarketOrder(last.TradeType, SymbolName, volume, label, null, null, comment);

                if (result.IsSuccessful)
                {
                    // Non incrementare più manualmente il contatore, verrà aggiornato da UpdateRecoveryCounter
                    recoveryCooldownActive = true;
                    lastRecoveryPrice = Symbol.Bid;
                    lastRecoveryDrawdown = perditaAttuale;  // Memorizza la perdita attuale
                    lastRecoveryReferenceValue = riferimentoValore;

                    // Aggiorna contatore in base alle posizioni effettivamente aperte
                    UpdateRecoveryCounter();

                    // Log migliorato con informazioni sul recovery adattivo
                    if (EnableAdaptiveRecovery)
                    {
                        double volatilityIndex = CalculateVolatilityIndex(20);
                        double baseDD = MinDDIncreasePercent;
                        double adjustedDD = CalculateVolatilityAdjustedDD(baseDD);
                        double marketFactor = GetMarketDepthFactor();

                        Print($"✅ Recovery #{recoveryCount} ESEGUITO: {calculatedLots:F2} lots a {perditaAttuale:F2}% di perdita");
                        Print($"📊 Analisi Recovery Adattivo:");
                        Print($"• Volatilità: {volatilityIndex:F2}x | Mercato: {marketFactor:F2}x");
                        Print($"• DD Base: {baseDD:F2}% → Adattato: {adjustedDD:F2}%");
                        Print($"• Volume adattato in base alle condizioni di mercato");
                    }
                    else
                    {
                        Print($"✅ Recovery #{recoveryCount} ESEGUITO: {calculatedLots:F2} lots a {perditaAttuale:F2}% di perdita");
                    }
                }
                else
                {
                    Print($"❌ Errore esecuzione Recovery: {result.Error}");
                    Print($"• Controllare limiti broker, margine disponibile o restrizioni trading");
                }
            
            }
            catch (Exception ex)
            {
                Print($"❌ EXCEPTION in TryRecovery: {ex.Message}");
                Print($"Stack: {ex.StackTrace}");
            }
            }

            // Dopo aver tentato il recovery standard, verifica se attivare il recovery esteso
            if (_extendedRecoveryModule != null)
            {
                // Se standard recovery non può agire (ad esempio limite raggiunto o filtri falliti)
                // ma il drawdown continua ad aumentare, valuta recovery esteso
                if (_extendedRecoveryModule.ShouldActivateExtendedRecovery(positions, netProfit, recoveryDD))
                {
                    Print("🔄 Attivazione recovery esteso...");
                    _extendedRecoveryModule.ApplyExtendedRecovery(positions, recoveryDD, recoveryPips);
                }
            }

            Print("============= FINE ANALISI RECOVERY =============\n");
        }

        //==========================================================================
        // ⚙️ GESTIONE BREAKEVEN
        //==========================================================================
        private void GestioneBreakEven(List<Position> positions, double netProfit)
        {
            // Solo controllo spread, NO MinActivationPips per BE
            if (!IsSpreadSafeForClosing()) return;

            var symbolPositions = positions.Where(p => p.SymbolName == SymbolName).ToList();
            if (!symbolPositions.Any()) return;

            // Verifica spread critico
            double spreadPips = Symbol.Spread / Symbol.PipSize;
            if (spreadPips > SpreadCriticoPips)
            {
                DebugLog($"❌ Breakeven bloccato: spread critico ({spreadPips:F1} > {SpreadCriticoPips} pips)");
                return;
            }

            // Calcolo margine utilizzato con fallback sicuro
            double marginUsed = 0;
            try
            {
                marginUsed = symbolPositions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits));
                if (marginUsed <= 0) throw new Exception("Invalid margin");
            }
            catch
            {
                marginUsed = symbolPositions.Sum(p => (p.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue);
            }

            // Verifica MinProfitCheck se attivo
            double minProfitRequired = 0;
            if (EnableMinProfitCheck)
            {
                minProfitRequired = marginUsed * (1 + MinProfitOverMarginPercent / 100.0);

                // Verifica soft per tolleranza
                bool softCheckOK = CheckMinProfitSoft(symbolPositions);
                if (!softCheckOK)
                {
                    DebugLog($"⛔ BE: Check soft profit non superato");
                    return;
                }

                if (netProfit < minProfitRequired)
                {
                    DebugLog($"⛔ Chiusura BE impedita: profitto lordo insufficiente. Richiesto: {minProfitRequired:F2} €, Attuale: {netProfit:F2}€");
                    return;
                }
            }

            DebugLog($"[BE] Soglia fissa: {fixedBreakEvenProfitThreshold:F2} € | Profitto attuale: {netProfit:F2} €");

            // Gestione chiusura BE
            if (netProfit <= fixedBreakEvenProfitThreshold)
            {
                bool hardCheckOK = !EnableMinProfitCheck || CheckMinProfit(symbolPositions);
                bool softCheckOK = !EnableMinProfitCheck || CheckMinProfitSoft(symbolPositions);

                if (hardCheckOK || softCheckOK)
                {
                    foreach (var p in symbolPositions)
                        SafeClosePosition(p);

                    Print($"✅ Chiusura BE eseguita a {netProfit:F2} € (soglia fissata: {fixedBreakEvenProfitThreshold:F2} €)");
                    Reset();
                }
                else
                {
                    Print($"⛔ Chiusura BE impedita: profitto lordo insufficiente.");
                    DebugLog($"[BE] ❌ Chiusura bloccata: MinProfitCheck attivo e profitto NON soddisfa margine richiesto.");
                }
            }
        }

        //==========================================================================
        // ⚙️ AGGIORNA RSI
        //==========================================================================
        private void AggiornaRSI(bool isLong)
        {
            try
            {
                if (isLong)
                {
                    // Calcolo RSI LONG (ipervenduto)
                    rsiBaseValueLong = rsi.Result.LastValue;

                    // Metodo per ottenere l'RSI su timeframe diverso
                    if (RsiHigherTimeFrame != TimeFrame)
                    {
                        try
                        {
                            // Otteniamo le barre dal timeframe superiore
                            var barsHigher = MarketData.GetBars(RsiHigherTimeFrame);
                            var indicatorHigher = Indicators.RelativeStrengthIndex(barsHigher.ClosePrices, RsiPeriodHigher);

                            // Assicurati che ci sia almeno un valore
                            if (indicatorHigher.Result.Count > 0)
                            {
                                rsiSuperiorValueLong = indicatorHigher.Result.LastValue;
                                rsiSuperiorValueShort = indicatorHigher.Result.LastValue;
                            }
                            else
                            {
                                // Fallback: usa gli stessi valori del timeframe base
                                rsiSuperiorValueLong = rsiBaseValueLong;
                                rsiSuperiorValueShort = rsiBaseValueShort;
                                Print("⚠️ Nessun dato RSI disponibile sul timeframe superiore, uso valori del timeframe corrente");
                            }
                        }
                        catch (Exception ex)
                        {
                            // In caso di errore, usa gli stessi valori del timeframe base
                            rsiSuperiorValueLong = rsiBaseValueLong;
                            rsiSuperiorValueShort = rsiBaseValueShort;
                            Print($"❌ Errore nel calcolo RSI sul timeframe superiore: {ex.Message}");
                        }
                    }
                    else
                    {
                        // Se il timeframe è lo stesso, usiamo il valore RSI di base
                        rsiSuperiorValueLong = rsiBaseValueLong;
                        rsiSuperiorValueShort = rsiBaseValueShort;
                    }

                    // Delta = differenza tra RSI superiore e base
                    double delta = rsiSuperiorValueLong - rsiBaseValueLong;

                    // Determina validità del segnale (SOLO in base ai valori RSI)
                    bool isValid = (rsiBaseValueLong < RsiBaseOversold) && (delta >= MinRsiDelta);

                    // Aggiorna storici
                    if (storicoRsiBaseLong.Count >= MaxStoricoRSI)
                        storicoRsiBaseLong.Dequeue();
                    storicoRsiBaseLong.Enqueue(rsiBaseValueLong);

                    if (storicoDeltaLong.Count >= MaxStoricoRSI)
                        storicoDeltaLong.Dequeue();
                    storicoDeltaLong.Enqueue(delta);

                    if (storicoSegnaleValidoLong.Count >= MaxStoricoRSI)
                        storicoSegnaleValidoLong.Dequeue();
                    storicoSegnaleValidoLong.Enqueue(isValid);

                    // Aggiorna HUD
                    hudRsiInfoLong = $"📉 LONG | TF Base ({TimeFrame}): {rsiBaseValueLong:F1} / TF Sup ({RsiHigherTimeFrame}): {rsiSuperiorValueLong:F1} | Δ: {delta:F1} \nSoglia Min Δ: {MinRsiDelta} | {(isValid ? "VALIDO ✅" : "NON valido ❌")}";

                    Print($"ℹ️ RSI aggiornato (LONG) → Base: {rsiBaseValueLong:F2} | Sup: {rsiSuperiorValueLong:F2} | Δ: {delta:F2} | Valido: {(isValid ? "✔" : "✖")}");
                }
                else
                {
                    // Calcolo RSI SHORT (ipercomprato)
                    rsiBaseValueShort = rsi.Result.LastValue;

                    // Metodo per ottenere l'RSI su timeframe diverso
                    if (RsiHigherTimeFrame != TimeFrame)
                    {
                        try
                        {
                            // Otteniamo le barre dal timeframe superiore
                            var barsHigher = MarketData.GetBars(RsiHigherTimeFrame);
                            var indicatorHigher = Indicators.RelativeStrengthIndex(barsHigher.ClosePrices, RsiPeriodHigher);

                            // Assicurati che ci sia almeno un valore
                            if (indicatorHigher.Result.Count > 0)
                            {
                                rsiSuperiorValueLong = indicatorHigher.Result.LastValue;
                                rsiSuperiorValueShort = indicatorHigher.Result.LastValue;
                            }
                            else
                            {
                                // Fallback: usa gli stessi valori del timeframe base
                                rsiSuperiorValueLong = rsiBaseValueLong;
                                rsiSuperiorValueShort = rsiBaseValueShort;
                                Print("⚠️ Nessun dato RSI disponibile sul timeframe superiore, uso valori del timeframe corrente");
                            }
                        }
                        catch (Exception ex)
                        {
                            // In caso di errore, usa gli stessi valori del timeframe base
                            rsiSuperiorValueLong = rsiBaseValueLong;
                            rsiSuperiorValueShort = rsiBaseValueShort;
                            Print($"❌ Errore nel calcolo RSI sul timeframe superiore: {ex.Message}");
                        }
                    }
                    else
                    {
                        // Se il timeframe è lo stesso, usiamo il valore RSI di base
                        rsiSuperiorValueLong = rsiBaseValueLong;
                        rsiSuperiorValueShort = rsiBaseValueShort;
                    }

                    // Delta = differenza tra RSI base e superiore
                    double delta = rsiBaseValueShort - rsiSuperiorValueShort;

                    // Determina validità del segnale (SOLO in base ai valori RSI)
                    bool isValid = (rsiBaseValueShort > RsiBaseOverbought) && (delta >= MinRsiDelta);

                    // Aggiorna storici
                    if (storicoRsiBaseShort.Count >= MaxStoricoRSI)
                        storicoRsiBaseShort.Dequeue();
                    storicoRsiBaseShort.Enqueue(rsiBaseValueShort);

                    if (storicoDeltaShort.Count >= MaxStoricoRSI)
                        storicoDeltaShort.Dequeue();
                    storicoDeltaShort.Enqueue(delta);

                    if (storicoSegnaleValidoShort.Count >= MaxStoricoRSI)
                        storicoSegnaleValidoShort.Dequeue();
                    storicoSegnaleValidoShort.Enqueue(isValid);

                    // Aggiorna HUD
                    hudRsiInfoShort = $"📈 SHORT | TF Base ({TimeFrame}): {rsiBaseValueShort:F1} / TF Sup ({RsiHigherTimeFrame}): {rsiSuperiorValueShort:F1} | Δ: {delta:F1} \nSoglia Min Δ: {MinRsiDelta} | {(isValid ? "VALIDO ✅" : "NON valido ❌")}";

                    Print($"ℹ️ RSI aggiornato (SHORT) → Base: {rsiBaseValueShort:F2} | Sup: {rsiSuperiorValueShort:F2} | Δ: {delta:F2} | Valido: {(isValid ? "✔" : "✖")}");
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in AggiornaRSI: {ex.Message}");
            }
        }

        //==========================================================================
        // ⚙️ IS SEGNALE RSI VALIDO
        //==========================================================================
        /* private bool IsSegnaleRSIValido(bool isLong)
         {
             // ✅ Forzatura attiva (test/debug)
             if (ForzaSegnaleRSI)
             {
                 Print($"🧪 [TEST] Forzatura RSI attiva → Segnale {(isLong ? "LONG" : "SHORT")} valido.");
                 return true;
             }

             // ✅ Se i segnali RSI sono disabilitati, ignora
             if (!EnableSignalRSI)
             {
                 Print("⚠️ Segnali RSI disabilitati da parametro.");
                 return false;
             }

             // ✅ Verifica dati RSI disponibili e validi
             if (Bars.Count < 2)
             {
                 Print("⏳ Attesa barre sufficienti per segnale RSI.");
                 return false;
             }

             if (isLong)
             {
                 if (double.IsNaN(rsiBaseValueLong) || double.IsNaN(rsiSuperiorValueLong))
                 {
                     Print("⚠️ RSI LONG non disponibile (NaN).");
                     return false;
                 }

                 double delta = rsiSuperiorValueLong - rsiBaseValueLong;
                 double minuti = (lastSignalTimeLong == default) ? double.MaxValue : Time.Subtract(lastSignalTimeLong).TotalMinutes;
                 string tempoStr = (minuti == double.MaxValue) ? "mai" : $"{minuti:N1} min fa";
                 Print($"📉 [RSI LONG] Base: {rsiBaseValueLong:N2}, Sup: {rsiSuperiorValueLong:N2}, Δ: {delta:N2}, Ultimo: {tempoStr}");

                 if (minuti < SignalCooldownMinutes)
                 {
                     Print("🕒 Cooldown LONG attivo ➜ nessun nuovo segnale.");
                     return false;
                 }

                 // CORREZIONE IMPORTANTE: Usa sempre la stessa logica di validazione 
                 // Un RSI basso (ipervenduto) genera SEMPRE un segnale LONG valido
                 bool condizione = (rsiBaseValueLong < RsiBaseOversold) && (delta >= MinRsiDelta);

                 Print($"✅ RSI LONG → {(condizione ? "VALIDO ✅" : "NON valido ❌")}");

                 // Parte LONG
                 hudRsiInfoLong = "📉 LONG | RSI non disponibile";
                 hudRsiInfoLong = $"📉 LONG | TF Base ({TimeFrame}): {rsiBaseValueLong:F1} / TF Sup ({RsiHigherTimeFrame}): {rsiSuperiorValueLong:F1} | Δ: {delta:F1} \nSoglia Min Δ: {MinRsiDelta} | {(condizione ? "VALIDO ✅" : "NON valido ❌")}";

                 return condizione;
             }
             else
             {
                 if (double.IsNaN(rsiBaseValueShort) || double.IsNaN(rsiSuperiorValueShort))
                 {
                     Print("⚠️ RSI SHORT non disponibile (NaN).");
                     return false;
                 }

                 double delta = rsiBaseValueShort - rsiSuperiorValueShort;
                 double minuti = (lastSignalTimeShort == default) ? double.MaxValue : Time.Subtract(lastSignalTimeShort).TotalMinutes;
                 string tempoStr = (minuti == double.MaxValue) ? "mai" : $"{minuti:N1} min fa";
                 Print($"📈 [RSI SHORT] Base: {rsiBaseValueShort:N2}, Sup: {rsiSuperiorValueShort:N2}, Δ: {delta:N2}, Ultimo: {tempoStr}");

                 if (minuti < SignalCooldownMinutes)
                 {
                     Print("🕒 Cooldown SHORT attivo ➜ nessun nuovo segnale.");
                     return false;
                 }

                 // CORREZIONE IMPORTANTE: Usa sempre la stessa logica di validazione
                 // Un RSI alto (ipercomprato) genera SEMPRE un segnale SHORT valido
                 bool condizione = (rsiBaseValueShort > RsiBaseOverbought) && (delta >= MinRsiDelta);

                 Print($"✅ RSI SHORT → {(condizione ? "VALIDO ✅" : "NON valido ❌")}");

                 // Parte SHORT
                 hudRsiInfoShort = "📈 SHORT | RSI non disponibile";
                 hudRsiInfoShort = $"📈 SHORT | TF Base ({TimeFrame}): {rsiBaseValueShort:F1} / TF Sup ({RsiHigherTimeFrame}): {rsiSuperiorValueShort:F1} | Δ: {delta:F1} \nSoglia Min Δ: {MinRsiDelta} | {(condizione ? "VALIDO ✅" : "NON valido ❌")}";

                 return condizione;
             }
         }*/

        private bool IsEmaFilterPassed(bool isLong)
        {
            if (!ForceEmaCheck)
                return true;

            var emaCheck = CheckPriceAgainstEMA();
            bool isPriceAboveEma = emaCheck.isPriceAboveEma;

            // NON invertire la direzione dell'ordine qui - isLong è già la direzione FINALE dell'ordine
            bool isOrderDirectionLong = isLong;

            // Regola EMA: LONG richiede prezzo sopra EMA, SHORT richiede prezzo sotto EMA
            bool isCorrectDirection = (isOrderDirectionLong && isPriceAboveEma) ||
                                     (!isOrderDirectionLong && !isPriceAboveEma);

            if (!isCorrectDirection)
            {
                Print($"🔒 ForceEmaCheck attivo: segnale RSI {(isLong ? "LONG" : "SHORT")} bloccato - " +
                      $"❌ EMA: Prezzo{(isPriceAboveEma ? ">" : "<")}EMA non supporta questa direzione");
                return false;
            }

            Print($"✅ EMA Check: Prezzo{(isPriceAboveEma ? ">" : "<")}EMA supporta " +
                  $"segnale RSI {(isLong ? "LONG" : "SHORT")}");
            return true;
        }

        // Funzione per verificare e visualizzare la corretta interpretazione dei segnali
        private string GetOperativeDirectionDescription(bool isLongSignal)
        {
            string rawSignal = isLongSignal ? "LONG" : "SHORT";

            // In modalità Contrarian, il segnale operativo è lo stesso del segnale grezzo
            // In modalità TrendFollowing, è invertito
            string operativeSignal = ModalitaRSI == ModalitaOperativaRSI.Contrarian
                ? rawSignal
                : (isLongSignal ? "SHORT" : "LONG");

            TradeType tradeType = ModalitaRSI == ModalitaOperativaRSI.Contrarian
                ? (isLongSignal ? TradeType.Buy : TradeType.Sell)
                : (isLongSignal ? TradeType.Sell : TradeType.Buy);

            return $"Segnale RSI: {rawSignal}, Modalità: {ModalitaRSI}, Operazione: {tradeType}";
        }

        //==========================================================================
        // ⚙️ ESEGUI SEGNALE RSI
        //==========================================================================
        private void EseguiSegnaleRSI(bool isLong, DateTime time, double prezzo)
        {
            // Protezione contro aperture simultanee di posizioni - blocco con lock thread-safe
            lock (_positionLock)
            {
                // Se c'è già un'operazione di apertura posizione in corso, usciamo
                if (_pendingPositionExecution)
                {
                    Print("⚠️ Segnale RSI ignorato: operazione già in corso");
                    return;
                }

                // Verifica se ci sono già posizioni aperte sullo stesso simbolo
                if (Positions.Count(p => p.SymbolName == SymbolName) > 0)
                {
                    Print("⚠️ Segnale RSI ignorato: posizione già esistente su questo simbolo");
                    return;
                }

                // Protezione contro segnali troppo ravvicinati (es. 1 secondo)
                if ((DateTime.Now - _lastPositionOpenTime).TotalSeconds < 1)
                {
                    Print("⚠️ Segnale RSI ignorato: segnale troppo ravvicinato all'ultima apertura");
                    return;
                }

                // Imposta il flag di operazione pendente
                _pendingPositionExecution = true;
            }

            try
            {
                bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

                // Se in modalità TrendFollowing, invertiamo la direzione dell'etichetta
                // ma NON invertiamo la direzione dell'ordine!
                string labelType = isTrendFollowing ?
                    (isLong ? "SELL" : "BUY") :  // Etichetta opposta in TrendFollowing
                    (isLong ? "BUY" : "SELL");   // Etichetta normale in Contrarian

                // Direzione dell'ordine basata sul segnale finale
                bool finalOrderLong = isLong;  // Non invertire qui

                // Crea una label unica per il segnale
                string labelId = $"RSI_{labelType}_{DateTime.Now.Ticks}";
                int barIndex = Bars.Count - 1;

                // Aggiungi l'etichetta alla lista per la pulizia automatica
                rsiLabels.Add(new RSILabel
                {
                    Tag = labelId,
                    CreationTime = time,
                    CreationBarIndex = barIndex
                });

                // Disegna l'etichetta sul grafico
                Chart.DrawIcon(labelId, ChartIconType.UpArrow, time, prezzo - 20 * Symbol.PipSize, isLong ? Color.Green : Color.Red);
                Print($"📌 Disegnata etichetta RSI: {labelId} | Bar: {barIndex}");

                // Descrizione operativa per log
                string operativeDescription = GetOperativeDirectionDescription(isLong);
                Print(operativeDescription);

                // Se non dobbiamo eseguire ordini, ma solo generare segnali, esci
                if (!IsOrderEnabled)
                {
                    _pendingPositionExecution = false; // Reset del flag in questo caso
                    return;
                }

                // Se il segnale è in attesa di conferma ulteriore, esci
                if (AbilitaBarreConfermaSegnale && MinBarreConfermaSegnale > 0)
                {
                    if (isLong)
                    {
                        confermaBarreLong = 1;
                        Print($"🕒 Segnale LONG in conferma: {confermaBarreLong}/{MinBarreConfermaSegnale}");
                    }
                    else
                    {
                        confermaBarreShort = 1;
                        Print($"🕒 Segnale SHORT in conferma: {confermaBarreShort}/{MinBarreConfermaSegnale}");
                    }
                    _pendingPositionExecution = false; // Reset del flag se usciamo in attesa di conferma
                    return;
                }

                // Se siamo qui, significa che il segnale è confermato o non richiede conferma
                if (EnableEmaFilter && ForceEmaCheck && !IsEmaFilterPassed(finalOrderLong))
                {
                    Print($"⛔ Esecuzione segnale {(isLong ? "LONG" : "SHORT")} bloccata dal filtro EMA");
                    _pendingPositionExecution = false; // Reset del flag se il filtro EMA blocca
                    return;
                }

                // Esegui l'ordine
                if (IsTradeAllowed())
                {
                    Print($"🔍 [TIMING] Segnale {(isLong ? "LONG" : "SHORT")} valido - Verifico timing apertura...");

                    EseguiOrdine(finalOrderLong, prezzo);

                    // Aggiorna il timestamp dell'ultima apertura
                    _lastPositionOpenTime = DateTime.Now;

                    Print($"✅ Segnale {(isLong ? "LONG" : "SHORT")} confermato e eseguito (chiusura barra conferma)");
                }
                else
                {
                    Print($"⛔ Trading non consentito per il segnale {(isLong ? "LONG" : "SHORT")}");
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in EseguiSegnaleRSI: {ex.Message}");
            }
            finally
            {
                // Assicuriamoci di resettare il flag in ogni caso
                _pendingPositionExecution = false;
            }
        }

        //==========================================================================
        // ⚙️ GET SPREAD INFO
        //==========================================================================
        private string GetSpreadInfo()
        {
            // 1. Ottieni valori base necessari
            double pipValue = Symbol.PipValue;
            double avgPrice = (Symbol.Bid + Symbol.Ask) / 2;
            double currentSpreadPips = Symbol.Spread / Symbol.PipSize;

            // 2. Calcolo spread critico dinamico universale
            double criticalSpreadPips = EnableAutoSpreadProtection
                ? Math.Round((SpreadCriticoPips * (AutoSpreadCoefficient * 100.0)) *
                            (pipValue / Math.Max(1, avgPrice)) * 100, 2)
                : SpreadCriticoPips;

            // 3. Verifica stato spread
            bool isCritical = currentSpreadPips > criticalSpreadPips;

            // 4. Formatta output con warning se necessario
            string status = isCritical
                ? "\n⚠️ Spread Fisso Troppo Basso ⚠️\n▶️ Aumentare il valore\n" +
                  "▶️ per consentire il corretto\n▶️ funzionamento del TP Dinamico\n"
                : "✓\n";
            string color = isCritical ? "🔴" : "🟢";

            // 5. Debug log se abilitato
            if (EnableDebugLogs)
            {
                Print($"\n=== SPREAD CHECK ===");
                Print($"Simbolo: {Symbol.Name}");
                Print($"Spread corrente: {currentSpreadPips:F1} pips");
                Print($"Spread critico calcolato: {criticalSpreadPips:F1} pips");
                Print($"Coefficiente: {AutoSpreadCoefficient}%");
            }

            // 6. Restituisci stringa formattata per HUD
            return $"{color} Spread Auto Ricavato: {criticalSpreadPips} pips {status}";

        }

        //==========================================================================
        // ⚙️ IS SPREAD SAFE FOR CLOSING
        //==========================================================================
        private bool IsSpreadSafeForClosing()
        {
            double currentSpreadPips = Symbol.Spread / Symbol.PipSize;
            double criticalSpreadPips = SpreadCriticoPips;
            string spreadSource = "base";

            if (EnableAutoSpreadProtection)
            {
                // Calcola la media del movimento degli ultimi 5 ticks
                double avgMovement = 0;
                int barsToCheck = 5;
                for (int i = 1; i <= barsToCheck; i++)
                {
                    if (i < Bars.Count)
                        avgMovement += Math.Abs(Bars.HighPrices[Bars.Count - i] - Bars.LowPrices[Bars.Count - i]) / Symbol.PipSize;
                }
                avgMovement /= barsToCheck;

                // Calcolo spread critico con metodo centralizzato
                double autoSpreadPips = CalculateAutoSpreadThreshold();

                // Se lo spread automatico è maggiore di quello base, usa quello
                if (autoSpreadPips > criticalSpreadPips)
                {
                    criticalSpreadPips = autoSpreadPips;
                    spreadSource = "auto";
                }

                // Log dettagliato
                if (EnableDebugLogs)
                {
                    Print($"\n=== SPREAD CHECK ===");
                    Print($"Simbolo: {Symbol.Name}");
                    Print($"Spread corrente: {currentSpreadPips:F1} pips");
                    Print($"Volatilità media: {avgMovement:F1} pips");
                    Print($"Fattore volatilità: {avgMovement / 10:F2}x");
                    Print($"Spread critico base: {SpreadCriticoPips:F1} pips");
                    Print($"Spread critico calcolato: {autoSpreadPips:F1} pips");
                    Print($"Spread critico utilizzato: {criticalSpreadPips:F1} pips ({spreadSource})");
                    Print($"Coefficiente: {AutoSpreadCoefficient}%");
                }
            }

            // Risultato finale
            bool isSpreadSafe = currentSpreadPips <= criticalSpreadPips;

            // Salva il risultato per debug e HUD
            lastCheckSpreadResult = isSpreadSafe;
            lastCheckSpreadValue = criticalSpreadPips;

            // Messaggio di log specifico se blocca
            if (!isSpreadSafe)
                Print($"⚠️ Spread troppo alto: {currentSpreadPips:F1} > {criticalSpreadPips:F1} pips ({spreadSource})");

            return isSpreadSafe;
        }

        //==========================================================================
        // ⚙️ CALCULATE AUTO SPREAD THRESHOLD
        //==========================================================================
        // Metodo helper per calcolare la soglia spread automatica
        private double CalculateAutoSpreadThreshold()
        {
            double pipValue = Symbol.PipValue;
            double avgPrice = (Symbol.Bid + Symbol.Ask) / 2;

            // Calcolo volatilità per fattore
            double volatilityFactor = 1.0;
            if (Bars.Count >= 5)
            {
                double avgMovement = 0;
                for (int i = 1; i <= 5; i++)
                {
                    if (i < Bars.Count)
                        avgMovement += Math.Abs(Bars.HighPrices[Bars.Count - i] - Bars.LowPrices[Bars.Count - i]) / Symbol.PipSize;
                }
                avgMovement /= 5;
                volatilityFactor = Math.Max(1.0, avgMovement / 10.0);
            }

            // Formula coerente per tutti i calcoli di spread
            return SpreadCriticoPips * (1 + (AutoSpreadCoefficient / 100.0)) * volatilityFactor;
        }

        //==========================================================================
        // ⚙️ CHECK MARGIN REQUIREMENTS
        //==========================================================================
        private bool CheckMarginRequirements()
        {
            // === Protezione Free Margin ===
            if (Account.FreeMargin < FreeMarginMinimoEuro)
            {
                Print($"⚠️ Free Margin insufficiente: {Account.FreeMargin:F2}€ (minimo richiesto {FreeMarginMinimoEuro:F2}€). Recovery annullato.");
                DebugLog($"FreeMargin attuale: {Account.FreeMargin:F2}€");
                return false;
            }

            // === Protezione Margin Level ===
            double marginLevel = (Account.Margin > 0) ? (Account.Equity / Account.Margin) * 100.0 : 0.0;
            if (marginLevel < MinMarginLevelPercent)
            {
                Print($"⚠️ Margin Level troppo basso: {marginLevel:F2}% (minimo richiesto {MinMarginLevelPercent:F2}%). Recovery annullato.");
                DebugLog($"MarginLevel attuale: {marginLevel:F2}%");
                return false;
            }

            // === Verifica SafeMode ===
            if (EnableSafeModeMarginProtection && Account.FreeMargin < SafeModeMinFreeMargin)
            {
                Print($"⚠️ SafeMode attivo: FreeMargin {Account.FreeMargin:F2}€ sotto soglia {SafeModeMinFreeMargin:F2}€");
                DebugLog($"SafeMode attivo ➜ Recovery bloccato per protezione margine.");
                return false;
            }

            return true;
        }

        //==========================================================================
        // ⚙️ GET DYNAMIC DD INCREASE PERCENT
        //==========================================================================
        private double GetDynamicDDIncreasePercent(Position lastPosition, double nextLots)
        {
            // Ottieni il parametro appropriato in base al contesto
            double baseDDIncrease = (recoveryCount == 0)
                ? RecoveryTriggerPercent  // Prima posizione usa il trigger
                : MinDDIncreasePercent;   // Posizioni successive usano l'incremento

            // Prima posizione recovery o posizione non valida
            if (lastPosition == null || nextLots <= 0)
            {
                Print($"• Parametri posizione non validi → uso base DD: {baseDDIncrease}%");
                return baseDDIncrease;
            }

            // Calcola il volume totale delle posizioni già aperte
            double totalOpenLots = Positions
                .Where(p => p.SymbolName == SymbolName)
                .Sum(p => Symbol.VolumeInUnitsToQuantity(p.VolumeInUnits));

            // Calcola il rapporto corretto tra nuovo volume e volume precedente
            double previousLots = Symbol.VolumeInUnitsToQuantity(lastPosition.VolumeInUnits);

            if (previousLots < 0.001) // Protezione valori troppo piccoli
            {
                Print($"• Volume precedente troppo piccolo ({previousLots:F6}) → uso base DD: {baseDDIncrease}%");
                return baseDDIncrease;
            }

            // Rapporto tra nuovo volume e volume totale esistente
            double lotRatio = nextLots / totalOpenLots;

            // Aggiungiamo un fattore di proporzione diretta col volume per aumentare le distanze
            double volumeScalingFactor = 1.0 + Math.Log10(1.0 + totalOpenLots);

            // Cap sul ratio per sicurezza
            double maxSafeRatio = 10.0;
            if (lotRatio > maxSafeRatio)
            {
                Print($"⚠️ Ratio volumi eccessivo ({lotRatio:F2}) → limitato a {maxSafeRatio:F1}x");
                lotRatio = maxSafeRatio;
            }

            // Fattore di progressione che aumenta con ogni recovery - potenziato per crescita geometrica
            double progressionFactor = 1.0 + (recoveryCount * 0.75); // Aumentato da 0.5 a 0.75 per crescere più rapidamente

            // Calcola il moltiplicatore DD in base al tipo selezionato
            double ddMultiplier = DDCalcType switch
            {
                DDCalculationType.Conservativo => Math.Pow(lotRatio, 0.09) * progressionFactor * volumeScalingFactor,
                DDCalculationType.Enhanced => Math.Pow(lotRatio, 0.81) * progressionFactor * volumeScalingFactor,
                DDCalculationType.Aggressive => lotRatio * progressionFactor * volumeScalingFactor * 0.63, // Riduzione per attivazione anticipata
                _ => Math.Pow(lotRatio, 0.36) * progressionFactor * volumeScalingFactor
            };

            // Applica anche il fattore temporale se abilitato
            if (EnableTimeBasedRecovery)
            {
                // Adatta il moltiplicatore in base all'ora del giorno (riduce durante ore di bassa volatilità)
                var hour = Server.Time.Hour;
                if ((hour < 8 || hour > 20)) // Ore di minor liquidità/attività
                {
                    ddMultiplier *= 1.5; // Richiedi più DD durante le ore di minor attività
                    Print($"• Orario a bassa liquidità ({hour:D2}:00) → DD aumentato del 50%");
                }
            }

            // Applica il fattore moltiplicativo configurabile
            ddMultiplier = ddMultiplier * DDMultiplier;

            // Limita il moltiplicatore finale a un valore massimo ragionevole
            double maxMultiplier = 15.0;
            if (ddMultiplier > maxMultiplier)
            {
                Print($"⚠️ DD multiplier eccessivo ({ddMultiplier:F2}) → limitato a {maxMultiplier:F1}x");
                ddMultiplier = maxMultiplier;
            }

            double dynamicDDIncrease = baseDDIncrease * ddMultiplier;

            // Output dettagliato per maggiore visibilità
            Print($"• Volume totale esistente: {totalOpenLots:F4} lots, nuovo volume: {nextLots:F4} lots");
            Print($"• Ratio volume/totale: {lotRatio:F2}x, fattore scaling: {volumeScalingFactor:F2}x");
            Print($"• Progressione per recovery #{recoveryCount}: {progressionFactor:F2}x");
            Print($"• Calcolo DD: base={baseDDIncrease:F2}% × multiplier={ddMultiplier:F2} = {dynamicDDIncrease:F2}%");

            return dynamicDDIncrease;
        }

        //==========================================================================
        // ⚙️ CALCULATE EFFECTIVE TP START
        //==========================================================================
        private double CalculateEffectiveTPStart()
        {
            if (TPStartPercent <= 0) return TPStart;

            double referenceValue = TPStartReference switch
            {
                RecoveryReferenceType.Balance => Account.Balance,
                RecoveryReferenceType.Equity => Account.Equity,
                RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                _ => Account.Equity
            };

            return Math.Max(TPStartMinimo, referenceValue * TPStartPercent / 100.0);
        }

        //==========================================================================
        // ⚙️ IS PROFIT SUFFICIENTE PER CHIUSURA
        //==========================================================================
        private bool IsProfitSufficientePerChiusura(double netProfit)
        {
            if (!EnableMinProfitCheck)
            {
                DebugLog("[CHECK] ✅ MinProfitCheck disattivato: chiusura sempre consentita.");
                return true;
            }

            var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();

            if (positions == null || !positions.Any())
                return false;

            // Usa il metodo centralizzato per calcolare il margine del simbolo
            double marginUsed = GetSymbolMargin(SymbolName);
            try
            {
                marginUsed = positions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits));
                if (marginUsed <= 0)
                    throw new Exception("Invalid margin");
            }
            catch
            {
                marginUsed = positions.Sum(p => (p.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue);
            }

            // Calcolo minDynamicTP = soglia minima assoluta (basata su TPStartPercent)
            double minDynamicTP = TPStart;
            if (TPStartPercent > 0)
            {
                double referenceValue = TPStartReference switch
                {
                    RecoveryReferenceType.Balance => Account.Balance,
                    RecoveryReferenceType.Equity => Account.Equity,
                    RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                    _ => Account.Equity
                };

                minDynamicTP = Math.Max(TPStartMinimo, referenceValue * TPStartPercent / 100.0);
            }

            // Calcolo soglia minima di profitto richiesta
            double minProfitRequired = Math.Round(Math.Max(minDynamicTP, marginUsed * (1 + MinProfitOverMarginPercent / 100.0)), 2);

            bool sufficiente = netProfit >= minProfitRequired;

            DebugLog($"[CHECK] Profitto attuale: {netProfit:F2}€ | Margine usato (solo {SymbolName}): {marginUsed:F2}€ | Richiesto minimo: {minProfitRequired:F2}€ → {(sufficiente ? "✅ OK" : "⛔ BLOCCATO")}");

            return sufficiente;
        }

        //==========================================================================
        // ⚙️ DRAW HUD
        //==========================================================================
        private void DrawHUD(double profit, double tpMax, double ddRecovery, double pips, double be, Position refPos)
        {
            List<Position> positions = Positions.Where(p => p.SymbolName.Equals(SymbolName, StringComparison.OrdinalIgnoreCase)).ToList();
            double currentProfit = positions.Sum(p => p.NetProfit);
            double minProfitRequired = Math.Round(Account.Margin * (1 + MinProfitOverMarginPercent / 100.0), 2);
            double targetTP = CalculateEffectiveTPStart();

            // Aggiungi informazioni sul recovery esteso se attivo
            if (_extendedRecoveryModule != null && _extendedRecoveryModule.IsExtendedModeActive)
            {
                string recoveryInfo = $"Recovery Esteso: Attivo #{_extendedRecoveryModule.ExtendedPositionsOpened}";
                if (_extendedRecoveryModule.MaxDrawdownRegistered > 0)
                    recoveryInfo += $" (Max DD: {_extendedRecoveryModule.MaxDrawdownRegistered:F2}%)";

                Chart.DrawStaticText("ExtRecoveryHUD", recoveryInfo, VerticalAlignment.Top, HorizontalAlignment.Right, Color.Purple);
            }

            if (HUDCompatto)
            {
                DrawHUDCompatto(profit, tpMax, ddRecovery, pips, be, refPos);
                return;
            }

            // HUD esteso con sezioni modulari
            DrawHUD_Operativo(profit, tpMax, ddRecovery, pips, be, refPos, currentProfit, targetTP, minProfitRequired);
            DrawHUD_RSI();
        }

        //==========================================================================
        // ⚙️ DRAW HUD OPERATIVO
        //==========================================================================
        private void DrawHUD_Operativo(double profit, double tpMax, double recoveryDD, double pips, double be, Position refPos, double currentProfit, double targetTP, double minProfitRequired)
        {
            if (!MostraHUDOperativo)
                return;

            // Verifica NetProfit
            double netProfit = GetNetProfitSymbol();

            string BuildVersion = BUILD_ID;

            var sb = new StringBuilder();
            sb.AppendLine($"{NAME} • Build ID: {BuildVersion}\n");

            double profitPercent = SafeDivide(profit, Account.Equity) * 100.0;
            sb.AppendLine($"• PROFITTO: {profit:F2} € ({profitPercent:F2}%)");
            sb.AppendLine($"• Max TP: {tpMax:F2} €");

            var positionsForTP = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            var tpDynamicInfo = CalculateDynamicTPThreshold(positionsForTP);
            lastCalculatedMinProfitToClose = tpDynamicInfo.minProfitToClose;
            lastTPDynamicStatus = tpDynamicInfo.statusMessage;
            lastTPDynamicColor = tpDynamicInfo.statusColor;
            lastTPDynamicProgress = tpDynamicInfo.progress;

            if (!MostraHUDOperativo) return;

            if (!ShowHUD) return;

            double spreadPips = Symbol.Spread / Symbol.PipSize;

            {
                // Calcolo spread critico dinamico ottimizzato
                double pipValue = Symbol.PipValue;
                double avgPrice = (Symbol.Bid + Symbol.Ask) / 2;
                double criticalSpreadPips = Math.Round((SpreadCriticoPips * (AutoSpreadCoefficient * 100.0)) * (pipValue / Math.Max(1, avgPrice)) * 100, 2);
                double volatilityPips = GetAverageVolatility() / Symbol.PipSize;

                sb.AppendLine($" \n=== SPREAD CHECK ===");
                sb.AppendLine($"Simbolo: {Symbol.Name}");
                sb.AppendLine($"Spread corrente: {spreadPips:F1} pips");
                sb.AppendLine($"Spread medio: {GetAverageSpread():F1} pips (su {spreadHistory.Count} campioni)");
                sb.AppendLine($"Volatilità media: {volatilityPips:F1} pips");
                sb.AppendLine($"Fattore volatilità: {(volatilityPips / SpreadCriticoPips):F2}x");
                sb.AppendLine($"Spread critico base: {SpreadCriticoPips:F1} pips");
                sb.AppendLine($"Coefficiente: {AutoSpreadCoefficient}%");
                // Add spread information at the top
                sb.AppendLine(GetSpreadInfo());
            }

            // === BREAKEVEN ===
            var posCorrenti = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            double breakEvenPrice = (EnableBE && refPos != null && triggerBreakevenAttivo && fixedBreakEvenProfitThreshold > 0)
                ? GetBreakEvenTargetPrice(refPos)
                : GetBreakEvenPrice(posCorrenti);

            if (ShowBreakEvenHUDInfo && refPos != null && IsBreakEvenPriceValid(breakEvenPrice))
            {
                double pipSize = Symbol.PipSize;
                if (pipSize <= 0 || double.IsNaN(pipSize) || double.IsInfinity(pipSize))
                    pipSize = 0.0001;
                double distance = Math.Abs(Symbol.Bid - breakEvenPrice) / pipSize;
                string statusBE = netProfit >= 0 ? "🟢 Sopra BreakEven" : "🔴 Sotto BreakEven";
                sb.AppendLine($"• BREAKEVEN: {breakEvenPrice:F5}");
                sb.AppendLine($"• Stato BreakEven: {statusBE}");
                if (ShowBreakEvenSlider)
                {
                    int blocksTotal = 12;
                    int blocksFilled = (int)Math.Min(blocksTotal, distance / 5.0);
                    string barFilled = new string('■', blocksFilled);
                    string barEmpty = new string('░', blocksTotal - blocksFilled);
                    sb.AppendLine($"[{barFilled}{barEmpty}] {distance:F1} pips");
                }
                else
                {
                    sb.AppendLine($"• Distanza BE: {distance:F1} pips");
                }
            }

            if (EnableBE)
            {
                sb.AppendLine($"• BE Trigger: ✅ {BETrigger} € (DD {TriggerDDBE}%)");
                //double targetFixedTP = BETrigger * (1 - TriggerDDBE / 100.0);
                double targetFixedTP = Math.Round(BETrigger * (1 - TriggerDDBE / 100.0), 2);
                sb.AppendLine($"➤ 🎯 Soglia minima (calcolata) BE: {targetFixedTP} €");

                if (EnableMinProfitCheck)
                {
                    // Calcola correttamente il minProfitRequired usando solo il margine del simbolo attuale
                    double symbolMargin = GetSymbolMargin(SymbolName);
                    double correctMinProfitRequired = Math.Round(symbolMargin * (1 + MinProfitOverMarginPercent / 100.0), 2);

                    bool hardOK = CheckMinProfit(posCorrenti);
                    bool softOK = CheckMinProfitSoft(posCorrenti);
                    string icona = hardOK ? "🟢" : softOK ? "🟡" : "🔴";
                    string stato = hardOK ? "Attivo" : softOK ? "margine borderline (tolleranza)" : "NON soddisfatto!";
                    sb.AppendLine($"  ➤ {icona} MinProfitCheck: {stato} • Min. Profit: {correctMinProfitRequired:F2} €");

                    if (!hardOK)
                    {
                        sb.AppendLine(softOK
                            ? "⚠️ Profitto sotto soglia, ma tolleranza minima accettata (soft OK)."
                            : $"⛔ Chiusura BE impedita: profitto lordo è {profit:F2} € / {correctMinProfitRequired:F2} €, insufficiente.");
                    }
                }
                else
                {
                    sb.AppendLine("  ➤ ⚪ MinProfitCheck: OFF — chiusura BE sempre consentita");
                }
            }
            else
            {
                sb.AppendLine("• BE Trigger: ❌ OFF");
            }

            if (EnableTrailingTP)
            {
                double minProfit = tpMax * (1 - TPDrawdown / 100.0);

                double dynamicTPStartHUD = TPStart;
                if (TPStartPercent > 0)
                {
                    double referenceValue = TPStartReference switch
                    {
                        RecoveryReferenceType.Balance => Account.Balance,
                        RecoveryReferenceType.Equity => Account.Equity,
                        RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                        _ => Account.Equity
                    };
                    dynamicTPStartHUD = Math.Max(TPStartMinimo, referenceValue * TPStartPercent / 100.0);
                }

                if (maxTP >= dynamicTPStartHUD)
                {
                    sb.AppendLine($"\n• PROFITTO Min. GARANTITO: ➤➤➤ {minProfit:F2} €");
                    sb.AppendLine($"• {GetDynamicTPDisplay(profit, tpDynamicInfo.minProfitToClose, tpDynamicInfo.progress)}");
                    sb.AppendLine($"  ➤ Riferimento: {TPStartReference} | Modo: {TPMode}");
                    sb.AppendLine($"  ➤ Soglia chiusura: {tpDynamicInfo.minProfitToClose:F2} € | DD massimo: {TPDrawdown}%");

                    if (tpDynamicInfo.progress >= 0 && tpDynamicInfo.minProfitToClose > 0)
                    {
                        string sliderTP = GeneraSliderTP(profit, tpDynamicInfo.minProfitToClose, 12);
                        sb.AppendLine($"  {sliderTP}");
                    }
                }
                else
                {
                    sb.AppendLine($"\n• TP DINAMICO: 🕒 In attesa trigger (MaxTP {maxTP:F2} < Start {dynamicTPStartHUD:F2} €)");
                }
                // === SEZIONE TAKE PROFIT ===
                if (EnableTrailingTP && maxTP >= targetTP)
                {
                    double progress = (currentProfit / maxTP) * 100; // Calcolo corretto del progresso
                    sb.AppendLine($"Take Profit Dinamico attivo");
                    sb.AppendLine($"Valore corrente: {currentProfit:F2} €");
                    sb.AppendLine($"Target: {targetTP:F2}€");
                    sb.AppendLine($"Massimo: {maxTP:F2}€ ({progress:F1}%)");
                }
                else
                {
                    double progress = (currentProfit / targetTP) * 100;
                    sb.AppendLine($"\nTP Dinamico in attesa");
                    sb.AppendLine($"Valore corrente: {currentProfit:F2} €");
                    sb.AppendLine($"Target: {targetTP:F2} €");
                    sb.AppendLine($"Progresso: {progress:F1}%");
                }
            }
            else
            {
                sb.AppendLine("\n• TP DINAMICO: ❌ OFF");
            }

            if (EnableFixedTP)
            {
                sb.AppendLine($"\n• TP FISSO: ✅ ON ({FixedTPAmount:F2} €)");

                if (profit > 0)
                {
                    double progressPercent = Math.Min(100, (profit / FixedTPAmount) * 100);
                    string sliderTP = GeneraSliderTP(profit, FixedTPAmount, 12);
                    sb.AppendLine($"  ➤ Progresso: {progressPercent:F1}% ({profit:F2} €/{FixedTPAmount:F2} €)");
                    sb.AppendLine($"  {sliderTP}");
                }
            }
            else
            {
                sb.AppendLine("\n• TP FISSO: ❌ OFF");
            }

            if (TPStartPercent == 0)
            {
                sb.AppendLine("\n• TP DINAMICO ADATTIVO: ❌ OFF");
            }
            else
            {
                sb.AppendLine($" \n• TP DINAMICO ADATTIVO: ✔ ON\n• Trigger: {TPStartPercent} % di: {TPStartReference}");
            }

            if (EnableTrailingTP && EnableFixedTP)
            {
                sb.AppendLine("");
                sb.AppendLine("⚠️ ATTENZIONE: TP Dinamico e TP Fisso entrambi ATTIVI!");
                sb.AppendLine("   ➤ Il TP Dinamico ha priorità e sarà l'unico utilizzato");
                sb.AppendLine("   ➤ Per utilizzare il TP Fisso, disattivare il TP Dinamico");
            }

            var cooldownStatus = GetCooldownStatus();
            if (cooldownStatus.IsActive)
            {
                sb.AppendLine($"Cooldown: {cooldownStatus.Status}");
                string progressBar = GeneraSliderColorato(cooldownStatus.Progress, 10);
                sb.AppendLine($"Progress: {progressBar}");
            }

            var riferimento = RecoveryReference switch
            {
                RecoveryReferenceType.Balance => "🔵 Balance",
                RecoveryReferenceType.Equity => "🟢 Equity",
                RecoveryReferenceType.FreeMargin => "🟠 FreeMargin",
                _ => "⚪ Unknown"
            };

            var modo = SelectedRecoveryMode switch
            {
                RecoveryMode.Standard => "🧩 Standard",
                RecoveryMode.Bilanciato => "⚖️ Bilanciato",
                RecoveryMode.Aggressivo => "🔥 Aggressivo",
                _ => "⚪ Unknown"
            };

            if (tpDynamicInfo.progress >= 0)
            {
                sb.AppendLine($"\n• ➤ RECOVERY Riferimento: {riferimento} | Modo: {modo}");
                sb.AppendLine($"  ➤ Soglia chiusura: {tpDynamicInfo.minProfitToClose:F2} €");
                sb.AppendLine($"  ➤ Drawdown massimo: {TPDrawdown}%");
            }

            if (EnableRecovery)
                sb.AppendLine($"\n• RECOVERY Attivo: ✅ {recoveryCount}/{MaxRecoveryTrades}");
            else
                sb.AppendLine("• RECOVERY: ❌ OFF");

            // Calcolo valore di riferimento e DD in euro
            double riferimentoValore = GetRecoveryReferenceValue();
            double ddEuroTrigger = riferimentoValore * (RecoveryTriggerPercent / 100.0);

            if (recoveryDD > 0)
            {
                sb.AppendLine(recoveryDD > 0
                 ? $"➤ Drawdown: {recoveryDD:F1}% / Trigger Recovery: {RecoveryTriggerPercent}% ({ddEuroTrigger:F2} €)"
                 : $"➤ Drawdown: 🟢 Nessun Drawdown attivo / Trigger Recovery: {RecoveryTriggerPercent}%");
                double ddAttuale = riferimentoValore * (recoveryDD / 100.0);
                sb.AppendLine($"➤ DD Attuale: {ddAttuale:F2} € / {ddEuroTrigger:F2} €");
            }
            else
            {
                sb.AppendLine($"➤ Drawdown: 🟢 Nessun DD / Trigger Recovery: {RecoveryTriggerPercent}% ({ddEuroTrigger:F2} €)");
            }

            actualDDpercent = Math.Abs(GetNetProfitSymbol() / GetRecoveryReferenceValue()) * 100.0;

            // Modifica la linea dell'HUD
            if (netProfit < 0)
            {
                sb.AppendLine($"➤ Drawdown Corrente: {actualDDpercent:F2}% | Ultimo DD Recovery: {lastRecoveryDrawdown:F2}%");
            }
            else
            {
                sb.AppendLine($"➤ Drawdown Corrente: 🟢 Nessun DD | Ultimo DD Recovery: {lastRecoveryDrawdown:F2}%");
            }

            if (EnableRecovery && recoveryCount > 0)
            {
                double sogliaMinima = Math.Abs(lastRecoveryDrawdown) + MinDDIncreasePercent;
                double baseDD = MinDDIncreasePercent;

                // Calcolo della soglia dinamica in base al volume e altri fattori
                var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();
                var lastPosition = positions.LastOrDefault();
                double calculatedLots = 0;

                if (lastPosition != null)
                    calculatedLots = EnableAdaptiveRecovery
                        ? CalculateAdaptiveRecoveryLots(lastPosition, RecoveryMultiplier)
                        : CalculateRecoveryLots(lastPosition, RecoveryMultiplier);

                // Calcolo DD dinamico per mostare nell'HUD
                double dynamicDDIncrease = GetDynamicDDIncreasePercent(lastPosition, calculatedLots);
                double targetDDminimo = lastRecoveryDrawdown + dynamicDDIncrease;

                // Calcolo dei valori in euro
                double drawdownTotaleEuro = riferimentoValore * targetDDminimo / 100.0;
                double equityResidua = riferimentoValore - drawdownTotaleEuro;

                double riferimentoCorrente = GetRecoveryReferenceValue();
                double perditaStimata = riferimentoCorrente * actualDDpercent / 100.0;
                double valoreResiduoStimato = riferimentoCorrente - perditaStimata;

                // Aggiunta del formato richiesto nell'HUD
                sb.AppendLine($"➤ Soglia DD minima per recovery: {targetDDminimo:F2}%\n(Ultimo Recovery DD {lastRecoveryDrawdown:F2}% + Aggiustamento {dynamicDDIncrease:F2}%)");
                sb.AppendLine($"→ Nuovo Recovery a DD = {targetDDminimo:F2}% ➜ Perdita prevista: {drawdownTotaleEuro:F2} €");
                sb.AppendLine($"→ Valore residuo stimato: {valoreResiduoStimato:F2} € su {RecoveryReference} attuale: {riferimentoCorrente:F2} €");
            }

            double distanzaUltimaPosizione = 0.0;
            var ultimaPosizione = Positions
                .Where(p => p.SymbolName == SymbolName)
                .OrderByDescending(p => p.EntryTime)
                .FirstOrDefault();

            if (ultimaPosizione != null)
                distanzaUltimaPosizione = Math.Abs(Symbol.Bid - ultimaPosizione.EntryPrice) / Symbol.PipSize;

            string distanzaOK = distanzaUltimaPosizione >= MinDistancePips ? "✔" : "❌";
            sb.AppendLine($"➤ Distanza: {distanzaUltimaPosizione:F1} pips / Min: {MinDistancePips} {distanzaOK}");

            int sliderBlocks = 12;
            double progressRatio = MinDistancePips > 0 ? distanzaUltimaPosizione / MinDistancePips : 0;
            int filled = (int)Math.Min(sliderBlocks, Math.Round(sliderBlocks * progressRatio));
            int empty = sliderBlocks - filled;

            string barra = new string('■', filled) + new string('░', empty);
            sb.AppendLine($"  [{barra}], {distanzaOK}");

            if (EnableRecovery)
            {
                // NON SERVE E' DOPPIA sb.AppendLine($"\n• RECOVERY Attivo: ✅ {recoveryCount}/{MaxRecoveryTrades}");

                // NUOVO BLOCCO: Aggiungi queste informazioni sul Recovery Adattivo
                if (EnableAdaptiveRecovery)
                {
                    sb.AppendLine($"\n• RECOVERY Adattivo: ✅ Attivo");

                    // Calcola e mostra l'indice di volatilità corrente
                    double volatilityIndex = CalculateVolatilityIndex(20);
                    string volatilityStatus = volatilityIndex > 1.5 ? "🔴 ALTA" :
                                              volatilityIndex > 1.0 ? "🟠 MEDIA" : "🟢 BASSA";

                    sb.AppendLine($"• Volatilità: {volatilityStatus} ({volatilityIndex:F2}x)");

                    // Mostra fattori di adattamento
                    sb.AppendLine($"• Sensibilità: {VolatilitySensitivityPercent}%");

                    // Mostra il fattore di smorzamento
                    sb.AppendLine($"• Smorzamento: {ProgressionDampeningFactor:F2}");

                    // Mostra fattori di mercato se abilitati
                    if (EnableLiquidityProtection)
                    {
                        double marketDepthFactor = GetMarketDepthFactor();
                        sb.AppendLine($"• Fattore liquidità: {marketDepthFactor:F2}x");
                    }

                    // Mostra se è attivo l'adattamento orario
                    if (EnableTimeBasedRecovery)
                    {
                        var serverHour = Server.Time.Hour;
                        bool optimalTradingHours = (serverHour >= 8 && serverHour <= 16);
                        sb.AppendLine($"• Orario mercato: {(optimalTradingHours ? "🟢 OTTIMALE" : "🟠 RIDOTTO")}");
                    }

                    // Se abbiamo un recovery attivo, mostra l'impatto della volatilità sul DD e volumi
                    if (recoveryCount > 0)
                    {
                        // Calcolo dell'impatto della volatilità sul DD
                        double baseDD = MinDDIncreasePercent;
                        double adjustedDD = CalculateVolatilityAdjustedDD(baseDD);
                        double impact = ((adjustedDD / baseDD) - 1) * 100;
                        string impactSymbol = impact >= 0 ? "↑" : "↓";

                        sb.AppendLine($"• DD Base: {baseDD:F2}% → Adattato: {adjustedDD:F2}% ({impactSymbol}{Math.Abs(impact):F1}%)");

                        // Se la posizione precedente esiste, calcola il prossimo volume adattivo stimato
                        var lastPosition = Positions.Where(p => p.SymbolName == SymbolName)
                                                  .OrderByDescending(p => p.EntryTime)
                                                  .FirstOrDefault();

                        if (lastPosition != null)
                        {
                            // Volume normale vs. adattivo
                            double standardLots = CalculateRecoveryLots(lastPosition, RecoveryMultiplier);
                            double adaptiveLots = CalculateAdaptiveRecoveryLots(lastPosition, RecoveryMultiplier);
                            double volumeImpact = ((adaptiveLots / standardLots) - 1) * 100;
                            string volumeImpactSymbol = volumeImpact >= 0 ? "↑" : "↓";

                            sb.AppendLine($"• Volume standard: {standardLots:F2} lots");
                            sb.AppendLine($"• Volume adattivo: {adaptiveLots:F2} lots ({volumeImpactSymbol}{Math.Abs(volumeImpact):F1}%)");
                        }
                    }
                }
                else
                {
                    sb.AppendLine($"\n• RECOVERY Adattivo: ⚠️ Disattivato");
                }

                // Aggiungi nel metodo DrawHUD_Operativo, prima della chiusura del metodo
                // Nel metodo DrawHUD_Operativo - modifica la sezione che mostra info sul Trailing SL
                if (EnableRecoveryTrailingStopLoss && recoveryCount > 0)
                {
                    sb.AppendLine("\n• TRAILING STOPLOSS PER RECOVERY:");

                    if (trailingStopLossAttivo)
                    {
                        List<Position> positions = Positions.Where(p => string.Equals(p.SymbolName, SymbolName, StringComparison.OrdinalIgnoreCase)).ToList();
                        double totalNetProfit = positions.Sum(p => p.NetProfit);
                        double slValue = lastTrailingStopLossPrice * (1 - RecoveryTrailingStopLossDistancePercent / 100.0);

                        sb.AppendLine($"  ✅ ATTIVO - Massimo: {lastTrailingStopLossPrice:F2} €");
                        sb.AppendLine($"  ➤ Stop: {slValue:F2} € | Attuale: {totalNetProfit:F2} €");
                        sb.AppendLine($"  ➤ DD massimo: {RecoveryTrailingStopLossDistancePercent}%");
                    }
                    else
                    {
                        sb.AppendLine($"  ⏳ In attesa trigger ({RecoveryTrailingStopLossTriggerEuro} €)");
                        sb.AppendLine($"  ➤ DD massimo: {RecoveryTrailingStopLossDistancePercent}%");
                    }
                }
            }
            else
            {
                sb.AppendLine("• RECOVERY: ❌ OFF");

                sb.AppendLine($"➤ Cooldown Recovery: {RecoveryCooldownPips:F0} pips");
                sb.AppendLine($"➤ Peggioramento DD: +{MinDDIncreasePercent:F1}%");
                sb.AppendLine($"➤ Distanza BE-Prezzo: {MinDistanceBEpips:F0} pips");

                double baseMultiplier = RecoveryMultiplier;
                double dynamicMultiplier = SelectedRecoveryMode switch
                {
                    RecoveryMode.Standard => baseMultiplier,
                    RecoveryMode.Bilanciato => Math.Max(1.5, baseMultiplier * 0.8),
                    RecoveryMode.Aggressivo => Math.Min(3.0, baseMultiplier * 1.5),
                    _ => baseMultiplier
                };

                double nextLots = VolumeInLots * Math.Pow(dynamicMultiplier, recoveryCount + 1);
                sb.AppendLine($"➤ Moltiplicatori: Base: {baseMultiplier:F2} | Effettivo: {dynamicMultiplier:F2}");
                sb.AppendLine($"➤ Prossimo volume previsto: {nextLots:F2} lotti");
            }

            double currentFreeMargin = Account.FreeMargin;
            double currentMarginLevel = (Account.Margin > 0) ? (Account.Equity / Account.Margin) * 100.0 : 0.0;

            sb.AppendLine(currentFreeMargin < FreeMarginMinimoEuro
                ? $"\n⚠️ Free Margin Minimo: {currentFreeMargin:F2} € (min {FreeMarginMinimoEuro:F2} €)"
                : $"\n• Free Margin Minimo: {currentFreeMargin:F2} € (min {FreeMarginMinimoEuro:F2} €)");

            sb.AppendLine(currentMarginLevel < MinMarginLevelPercent
                ? $"⚠️ Margin Level Minimo: {currentMarginLevel:F2}% (min {MinMarginLevelPercent:F2}%)"
                : $"• Margin Level Minimo: {currentMarginLevel:F2}% (min {MinMarginLevelPercent:F2}%)");

            if (!string.IsNullOrEmpty(trailingTPWarningHUD))
            {
                sb.AppendLine("");
                sb.AppendLine(trailingTPWarningHUD);
            }

            string fullText = sb.ToString();
            Color hudColor = GetColorFromProfitPercent(profitPercent);

            try
            {
                if (_hudOperativoPanel != null)
                    Chart.RemoveControl(_hudOperativoPanel);

                _hudOperativoPanel = new Border
                {
                    BackgroundColor = HUDOperativoBackgroundColor,
                    BorderColor = Color.Transparent,
                    CornerRadius = 4,
                    Padding = 6,
                    Margin = 6,
                    HorizontalAlignment = HUDOperativoHorizontal,
                    VerticalAlignment = HUDOperativoVertical,
                    Child = new TextBlock
                    {
                        Text = fullText,
                        FontSize = 11,
                        ForegroundColor = hudColor,
                        FontWeight = FontWeight.Normal
                    }
                };

                Chart.AddControl(_hudOperativoPanel);
            }
            catch (Exception ex)
            {
                Print($"⚠️ Errore disegno HUD Operativo: {ex.Message}");
            }
        }

        //==========================================================================
        // ⚙️ DRAW HUD RSI
        //==========================================================================
        private void DrawHUD_RSI()
        {
            if (!MostraHUDDiagnosticoRSI)
                return;

            // Verifica se ci sono posizioni aperte sul simbolo attuale
            bool hasPosizioni = Positions.Any(p => p.SymbolName == SymbolName);

            var sb = new StringBuilder();
            sb.AppendLine($"📊 RSI Multi-Timeframe & Segnale");

            // Se ci sono posizioni aperte, mostra solo un messaggio informativo e non elabora i segnali
            if (hasPosizioni)
            {
                string modalitaRSI = ModalitaRSI == ModalitaOperativaRSI.Contrarian ? "Contrarian" : "TrendFollowing";
                sb.AppendLine($"MODALITA': {modalitaRSI}\n");
                sb.AppendLine("⚠️ POSIZIONI APERTE RILEVATE");
                sb.AppendLine("Analisi segnali RSI temporaneamente sospesa.");
                sb.AppendLine("Verrà riattivata dopo la chiusura di tutte le posizioni.");
            }
            else
            {
                // Codice originale per l'elaborazione dei segnali RSI quando non ci sono posizioni aperte
                string modalitaRSI = ModalitaRSI == ModalitaOperativaRSI.Contrarian ? "Contrarian" : "TrendFollowing";
                sb.AppendLine($"MODALITA': {modalitaRSI}\n");

                if (EnableSignalRSI && RsiHigherTimeFrame <= TimeFrame)
                {
                    sb.AppendLine("⚠️ CONFIGURAZIONE ERRATA:");
                    sb.AppendLine($"   ➤ TimeFrame RSI superiore ({RsiHigherTimeFrame}) <= TimeFrame base ({TimeFrame})");
                    sb.AppendLine("   ➤ Δ RSI sarà sempre 0 ➜ nessun segnale valido.");
                }

                if (!EnableSignalRSI)
                {
                    sb.AppendLine("ℹ️ RSI Multi-TF disattivato");
                }
                else
                {
                    double deltaLONG = rsiSuperiorValueLong - rsiBaseValueLong;
                    double deltaSHORT = rsiBaseValueShort - rsiSuperiorValueShort;

                    var diagnosticaLong = ValidaSegnaleRSIConQualita_ReadOnly(true);
                    var diagnosticaShort = ValidaSegnaleRSIConQualita_ReadOnly(false);

                    // I segnali grezzi dal sistema RSI
                    bool segnaleLONG_grezzo = diagnosticaLong.SegnaleFinale;
                    bool segnaleSHORT_grezzo = diagnosticaShort.SegnaleFinale;

                    // Flag per segnali in formazione (grezzi)
                    bool staFormandosiLONG_grezzo = deltaLONG >= MinRsiDelta || diagnosticaLong.FiltroPersistenzaSuperato;
                    bool staFormandosiSHORT_grezzo = deltaSHORT >= MinRsiDelta || diagnosticaShort.FiltroPersistenzaSuperato;

                    // Verifica posizioni effettivamente aperte
                    bool posizioneLongAperta = Positions.Any(p => p.SymbolName == SymbolName && p.TradeType == TradeType.Buy);
                    bool posizioneShortAperta = Positions.Any(p => p.SymbolName == SymbolName && p.TradeType == TradeType.Sell);

                    // Verifica ultimo ordine eseguito
                    bool ultimoOrdineLong = !string.IsNullOrEmpty(ultimoMessaggioOrdine) && ultimoMessaggioOrdine.Contains("Buy");
                    bool ultimoOrdineShort = !string.IsNullOrEmpty(ultimoMessaggioOrdine) && ultimoMessaggioOrdine.Contains("Sell");

                    sb.AppendLine($"➤ RSI TF Base ({TimeFrame}): {rsiBaseValueLong:F2} | RSI TF Superiore ({RsiHigherTimeFrame}): {rsiSuperiorValueLong:F2}\n     Δ: {Math.Abs(deltaLONG):F2} | Min Δ: {MinRsiDelta}");

                    // Aggiunta informazione stato RSI Base
                    string statoRSIBase = "";
                    if (rsiBaseValueLong <= RsiBaseOversold)
                        statoRSIBase = $"🟢 IPERVENDUTO ({rsiBaseValueLong:F2}/{RsiBaseOversold})";
                    else if (rsiBaseValueLong >= RsiBaseOverbought)
                        statoRSIBase = $"🔴 IPERCOMPRATO ({rsiBaseValueLong:F2}/{RsiBaseOverbought})";
                    else
                        statoRSIBase = "⚪ NEUTRO";

                    // Aggiunta informazione stato RSI Superiore
                    string statoRSISup = "";
                    if (rsiSuperiorValueLong <= RsiHigherOversold)
                        statoRSISup = $"🟢 IPERVENDUTO ({rsiSuperiorValueLong:F2}/{RsiHigherOversold})";
                    else if (rsiSuperiorValueLong >= RsiHigherOverbought)
                        statoRSISup = $"🔴 IPERCOMPRATO ({rsiSuperiorValueLong:F2}/{RsiHigherOverbought})";
                    else
                        statoRSISup = "⚪ NEUTRO";

                    sb.AppendLine($"➤ Stato: TF Base {statoRSIBase}\n     TF Superiore {statoRSISup}");
                    double sliderDelta = Math.Max(deltaLONG, deltaSHORT);
                    sb.AppendLine("Intensità segnale:");
                    sb.AppendLine(GeneraSliderTecnico(sliderDelta, 0, MinRsiDelta * 2, MinRsiDelta));

                    // Determina il messaggio di stato in base alla modalità operativa e posizioni aperte
                    string statoSegnale;

                    if (ModalitaRSI == ModalitaOperativaRSI.Contrarian)
                    {
                        // In modalità Contrarian, priorità alla posizione aperta
                        if (posizioneShortAperta || ultimoOrdineShort || segnaleSHORT_grezzo)
                            statoSegnale = $"📉 Apertura SHORT confermata ☑";
                        else if (posizioneLongAperta || ultimoOrdineLong || segnaleLONG_grezzo)
                            statoSegnale = $"📈 Apertura LONG confermata ☑";
                        else if (staFormandosiSHORT_grezzo)
                            statoSegnale = $"📉 Segnale SHORT in formazione ⏳";
                        else if (staFormandosiLONG_grezzo)
                            statoSegnale = $"📈 Segnale LONG in formazione ⏳";
                        else
                            statoSegnale = $"⛔ Nessun segnale valido";
                    }
                    else // TrendFollowing
                    {
                        // In modalità TrendFollowing, priorità alla posizione aperta
                        if (posizioneLongAperta || ultimoOrdineLong || segnaleSHORT_grezzo)
                            statoSegnale = $"📈 Apertura LONG confermata ☑";
                        else if (posizioneShortAperta || ultimoOrdineShort || segnaleLONG_grezzo)
                            statoSegnale = $"📉 Apertura SHORT confermata ☑";
                        else if (staFormandosiSHORT_grezzo)
                            statoSegnale = $"📈 Segnale LONG in formazione ⏳";
                        else if (staFormandosiLONG_grezzo)
                            statoSegnale = $"📉 Segnale SHORT in formazione ⏳";
                        else
                            statoSegnale = $"⛔ Nessun segnale valido";
                    }

                    sb.AppendLine($"\n{statoSegnale}");

                    sb.AppendLine("\n🧠 Diagnostica Avanzata:");

                    // Aggiorna la sezione di diagnostica avanzata per essere coerente con la modalità
                    if (ModalitaRSI == ModalitaOperativaRSI.Contrarian)
                    {
                        // In Contrarian, mostra i dati relativi al segnale grezzo
                        if (segnaleSHORT_grezzo || staFormandosiSHORT_grezzo)
                        {
                            sb.AppendLine($"• Δ SHORT: {deltaSHORT:F2} {(deltaSHORT >= MinRsiDelta ? "✔" : "✖")}" +
                                          $" | Persistenza: {consecutiveValidShort}/{MinBarrePersistenzaSegnale} {(diagnosticaShort.FiltroPersistenzaSuperato ? "✔" : "✖")}" +
                                          $" | Δ crescente: {(diagnosticaShort.FiltroDeltaCrescenteSuperato ? "✔" : "✖")}" +
                                          $"\nDirezione operativa: SHORT");
                        }
                        else if (segnaleLONG_grezzo || staFormandosiLONG_grezzo)
                        {
                            sb.AppendLine($"• Δ LONG: {deltaLONG:F2} {(deltaLONG >= MinRsiDelta ? "✔" : "✖")}" +
                                          $" | Persistenza: {consecutiveValidLong}/{MinBarrePersistenzaSegnale} {(diagnosticaLong.FiltroPersistenzaSuperato ? "✔" : "✖")}" +
                                          $" | Δ crescente: {(diagnosticaLong.FiltroDeltaCrescenteSuperato ? "✔" : "✖")}" +
                                          $"\nDirezione operativa: LONG");
                        }
                    }
                    else // TrendFollowing
                    {
                        // CORREZIONE: In TrendFollowing inverte correttamente la direzione operativa
                        if (segnaleSHORT_grezzo || staFormandosiSHORT_grezzo)
                        {
                            sb.AppendLine($"• Δ SHORT: {deltaSHORT:F2} {(deltaSHORT >= MinRsiDelta ? "✔" : "✖")}" +
                                          $" | Persistenza: {consecutiveValidShort}/{MinBarrePersistenzaSegnale} {(diagnosticaShort.FiltroPersistenzaSuperato ? "✔" : "✖")}" +
                                          $" | Δ crescente: {(diagnosticaShort.FiltroDeltaCrescenteSuperato ? "✔" : "✖")}" +
                                          $"\nDirezione operativa: LONG");
                        }
                        else if (segnaleLONG_grezzo || staFormandosiLONG_grezzo)
                        {
                            sb.AppendLine($"• Δ LONG: {deltaLONG:F2} {(deltaLONG >= MinRsiDelta ? "✔" : "✖")}" +
                                          $" | Persistenza: {consecutiveValidLong}/{MinBarrePersistenzaSegnale} {(diagnosticaLong.FiltroPersistenzaSuperato ? "✔" : "✖")}" +
                                          $" | Δ crescente: {(diagnosticaLong.FiltroDeltaCrescenteSuperato ? "✔" : "✖")}" +
                                          $"\nDirezione operativa: SHORT");
                        }
                    }

                    sb.AppendLine($"\n🧬 Persistenza:\nLONG: {consecutiveValidLong}/{MinBarrePersistenzaSegnale} | SHORT: {consecutiveValidShort}/{MinBarrePersistenzaSegnale}");

                    if (MinBarreConfermaSegnale > 0)
                    {
                        sb.AppendLine($"🕒 Conferma richiesta: {MinBarreConfermaSegnale} barre");
                        sb.AppendLine($"🧭 LONG: {(pendingExecutionLongTime != null ? "⏳ In attesa ..." : "—")} | SHORT: {(pendingExecutionShortTime != null ? "⏳ In attesa ..." : "—")}");
                        string timingLabel = ModalitaTimingApertura switch
                        {
                            TimingAperturaPosizione.AllaChiusuraBarraConferma => "📌 Chiusura barra conferma",
                            TimingAperturaPosizione.AllaChiusuraBarraSuccessiva => "⏱️ Chiusura barra successiva",
                            _ => "❓ Sconosciuta"
                        };
                        sb.AppendLine($"🧭 Apertura posizione: {timingLabel}");
                    }

                    if (AbilitaFiltroDeltaCrescenteRSI || AbilitaFiltroCurvaturaRSIBase)
                    {
                        sb.AppendLine("\nFiltri attivi: " +
                                      (AbilitaFiltroDeltaCrescenteRSI ? "Δ Crescente " : "") +
                                      (AbilitaFiltroCurvaturaRSIBase ? "| Curvatura" : ""));
                    }

                    if (EnableEmaFilter)
                    {
                        sb.AppendLine("\n🎚️ Filtro EMA:");
                        var (isPriceAboveEma, recommendation, _) = CheckPriceAgainstEMA();
                        sb.AppendLine($"• EMA {EmaPeriod} su TF {EmaTimeFrame}: Prezzo {(isPriceAboveEma ? " >" : "<")} EMA");
                        sb.AppendLine($"• {recommendation}");

                        if (ForceEmaCheck)
                            sb.AppendLine("⚠️ Controllo forzato attivo: blocca segnali non conformi");
                        else
                            sb.AppendLine("ℹ️ Controllo consigliato: solo avvisi, nessun blocco");
                    }

                    if (ShowRSIDiagnostics)
                    {
                        sb.AppendLine("\n──── Diagnostica Tecnica Completa ────");

                        string[] lines = null;
                        bool isLongDiagnostics = false;
                        string diagPrefix = "";

                        // Determina quale diagnostica visualizzare in base ai segnali attivi
                        if ((ModalitaRSI == ModalitaOperativaRSI.Contrarian && (segnaleSHORT_grezzo || staFormandosiSHORT_grezzo)) ||
                            (ModalitaRSI == ModalitaOperativaRSI.TrendFollowing && (segnaleLONG_grezzo || staFormandosiLONG_grezzo)))
                        {
                            lines = hudRsiQualitaShort.Split('\n');
                            isLongDiagnostics = false;
                            // Adatta l'etichetta del segnale alla modalità operativa
                            diagPrefix = ModalitaRSI == ModalitaOperativaRSI.Contrarian ? "SHORT" : "LONG";
                            sb.AppendLine($"{diagPrefix} ▶ Segnale {diagPrefix}");
                        }
                        else if ((ModalitaRSI == ModalitaOperativaRSI.Contrarian && (segnaleLONG_grezzo || staFormandosiLONG_grezzo)) ||
                                 (ModalitaRSI == ModalitaOperativaRSI.TrendFollowing && (segnaleSHORT_grezzo || staFormandosiSHORT_grezzo)))
                        {
                            lines = hudRsiQualitaLong.Split('\n');
                            isLongDiagnostics = true;
                            // Adatta l'etichetta del segnale alla modalità operativa
                            diagPrefix = ModalitaRSI == ModalitaOperativaRSI.Contrarian ? "LONG" : "SHORT";
                            sb.AppendLine($"{diagPrefix} ▶ Segnale {diagPrefix}");
                        }

                        if (lines != null)
                        {
                            if (ModalitaRSI == ModalitaOperativaRSI.Contrarian)
                            {
                                // In modalità Contrarian, usa il prefisso diretto
                                diagPrefix = isLongDiagnostics ? "LONG" : "SHORT";
                            }
                            else // TrendFollowing
                            {
                                // In TrendFollowing, inverti il prefisso
                                diagPrefix = isLongDiagnostics ? "SHORT" : "LONG";
                            }

                            foreach (var line in lines)
                                sb.AppendLine($"{diagPrefix} ▶ " + line.Trim());
                        }

                        sb.AppendLine("──────────────────────────────────────");
                    }
                }
            }

            if (!string.IsNullOrEmpty(ultimoMessaggioOrdine))
            {
                sb.AppendLine("\n📝 Ultimo Ordine:");
                sb.AppendLine($"➤ {ultimoMessaggioOrdine}");
                sb.AppendLine($"⏱ {ultimoMessaggioTime:dd.MM.yyyy HH:mm:ss}");
            }

            Color hudColor = Color.LightBlue;

            try
            {
                if (_hudRSIPanel != null)
                    Chart.RemoveControl(_hudRSIPanel);

                _hudRSIPanel = new Border
                {
                    BackgroundColor = HUDRSIBackgroundColor,
                    BorderColor = Color.Transparent,
                    CornerRadius = 4,
                    Padding = 6,
                    Margin = 6,
                    HorizontalAlignment = HUDRSIHorizontal,
                    VerticalAlignment = HUDRSIVertical,
                    Child = new TextBlock
                    {
                        Text = sb.ToString(),
                        FontSize = 11,
                        ForegroundColor = hudColor,
                        FontWeight = FontWeight.Normal
                    }
                };

                Chart.AddControl(_hudRSIPanel);
            }
            catch (Exception ex)
            {
                Print($"⚠️ Errore disegno HUD RSI: {ex.Message}");
            }
        }

        //==========================================================================
        // 🎛️ DRAW HUD COMPATTO A SCHERMO (ORDINATO E COMMENTATO)
        //==========================================================================
        private void DrawHUDCompatto(double profit, double tpMax, double ddRecovery, double pips, double be, Position refPos)
        {
            var sb = new StringBuilder();

            sb.AppendLine("★" + NAME.Split('★')[1] + " " + VERSION.Split('\n')[1].Trim());
            sb.AppendLine($"P/L: {profit:F2} € ({SafeDivide(profit, Account.Equity) * 100:F1}%)");

            var positionsForTP = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            double dynamicTPStart = TPStart;
            double tpFromPercent = 0;
            if (TPStartPercent > 0)
            {
                double referenceValue = TPStartReference switch
                {
                    RecoveryReferenceType.Balance => Account.Balance,
                    RecoveryReferenceType.Equity => Account.Equity,
                    RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                    _ => Account.Equity
                };
                tpFromPercent = referenceValue * TPStartPercent / 100.0;
                dynamicTPStart = Math.Max(TPStartMinimo, tpFromPercent);
            }

            double marginUsed = 0;
            try { marginUsed = positionsForTP.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits)); }
            catch { marginUsed = positionsForTP.Sum(p => (p.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue); }

            double minProfitToClose = (dynamicTPStart / (1 - TPDrawdown / 100.0)) +
                                      (EnableMinProfitCheck ? marginUsed * (MinProfitOverMarginPercent / 100.0) : 0);

            var tpInfo = CalculateDynamicTPThreshold(positionsForTP);

            sb.AppendLine($"Spread: {Symbol.Spread / Symbol.PipSize:F1} pips | Media: {GetAverageSpread():F1} pips");

            // NUOVA IMPLEMENTAZIONE TP
            if (EnableTrailingTP)
            {
                if (tpInfo.progress >= 0)
                {
                    var (emoji, _) = GetDynamicTPStatus(tpInfo.progress);
                    sb.AppendLine($"{emoji} TP Dinamico: {dynamicTPStart:F0} €→{dynamicTPStart * (1 - TPDrawdown / 100.0):F0} € [{GeneraSliderColoratoCompatto(tpInfo.progress)}]");
                }
                else
                {
                    sb.AppendLine($"⏳ TP Dinamico: in attesa ({maxTP:F2}/{dynamicTPStart:F2} €)");
                }
            }
            else if (EnableFixedTP)
            {
                double progressPercent = Math.Min(100, (profit / FixedTPAmount) * 100);
                sb.AppendLine($"🎯 TP Fisso: {profit:F0}/{FixedTPAmount:F0} € [{GeneraSliderColoratoCompatto(progressPercent)}]");
            }
            else
            {
                sb.AppendLine("TP: ❌ OFF");
            }

            if (EnableTrailingTP && EnableFixedTP)
            {
                sb.AppendLine("⚠️ TP Dinamico ha priorità sul TP Fisso");
            }

            // 🔎 Diagnostica TPStart Dinamico Adattivo
            if (TPStartPercent > 0)
            {
                sb.AppendLine($"TP%: {TPStartPercent:F1}% di {TPStartReference} = {tpFromPercent:F2} €");
                sb.AppendLine($"→ Confronto con TPStart fisso ({TPStart:F2} €), Usato: {dynamicTPStart:F2} €");
            }

            double beVisual = (EnableBE && refPos != null && triggerBreakevenAttivo)
                ? GetBreakEvenTargetPrice(refPos)
                : GetBreakEvenPrice(positionsForTP);

            bool beVisualValid = IsBreakEvenPriceValid(beVisual);
            string beText = beVisualValid ? $"{beVisual:F5}" : "⚠️ Errore";
            sb.AppendLine($"BE: {beText} {(EnableBE ? $"✅{BETrigger * (1 - TriggerDDBE / 100.0):F0} €" : "❌")} | Rec: {(EnableRecovery ? $"{recoveryCount}/{MaxRecoveryTrades}" : "OFF")}");

            sb.AppendLine($"FM: {Account.FreeMargin:F0} €/{FreeMarginMinimoEuro:F0}€ | ML: {SafeDivide(Account.Equity, Account.Margin) * 100:F0}%/{MinMarginLevelPercent:F0}%");

            string swingStatus = EnableSwingFilter ?
                                (TrovaSwingAttuale() == TradeType.Buy ? "↓L" :
                                 TrovaSwingAttuale() == TradeType.Sell ? "↑S" : "○") : "─";

            sb.Append($"{swingStatus} | DD: {(ddRecovery > 0 ? $"{ddRecovery:F0}%" : "🟢")} | ");
            sb.AppendLine($"RSI: {(EnableRSIFilter ? (refPos != null && CheckRSIValid(refPos) ? "🟢" : "🔴") : "⚪")}");

            if (EnableMinProfitCheck)
            {
                double minProfitRequired = Math.Round(Account.Margin * (1 + MinProfitOverMarginPercent / 100.0), 2);
                sb.AppendLine($"MinP: +{MinProfitOverMarginPercent}%={minProfitRequired:F0} €");
            }

            if (EnableBE && refPos != null && ShowBreakEvenSlider)
            {
                if (!beVisualValid)
                    sb.AppendLine("BE Target: ⚠️ Valore non valido");
                else
                {
                    var posCorrenti = Positions.Where(p => p.SymbolName == SymbolName).ToList();
                    double breakEvenPrice = (EnableBE && refPos != null && triggerBreakevenAttivo && fixedBreakEvenProfitThreshold > 0)
                        ? GetBreakEvenTargetPrice(refPos)
                        : GetBreakEvenPrice(posCorrenti);

                    double pipSize = Symbol.PipSize;
                    if (pipSize <= 0 || double.IsNaN(pipSize) || double.IsInfinity(pipSize))
                        pipSize = 0.01;

                    double distance = Math.Abs(Symbol.Bid - breakEvenPrice) / pipSize;
                    double beSliderPercent = Math.Max(0, Math.Min(100, distance / 10.0 * 100.0));

                    sb.AppendLine($"BE Target: {GeneraSliderColorato(beSliderPercent, 5)} {BETrigger * (1 - TriggerDDBE / 100.0):F0} €");
                }
            }
            else if (EnableBE && refPos != null)
            {
                double targetFixedTP = BETrigger * (1 - TriggerDDBE / 100.0);
                sb.AppendLine($"BE Target: {targetFixedTP:F0} €");
            }

            if (EnableBE && EnableMinProfitCheck && triggerBreakevenAttivo)
            {
                bool hardOK = CheckMinProfit(positionsForTP);
                bool softOK = CheckMinProfitSoft(positionsForTP);
                sb.AppendLine($"MP Check: {(hardOK ? "🟢" : softOK ? "🟡" : "🔴")} {(hardOK ? "OK" : softOK ? "Toll." : "NO")}");
            }

            if (EnableRecovery && EnableAdaptiveRecovery)
            {
                double volatilityIndex = CalculateVolatilityIndex(20);
                string volatilityEmoji = volatilityIndex > 1.5 ? "🔴" :
                                        volatilityIndex > 1.0 ? "🟠" : "🟢";

                sb.AppendLine($"Rec.Adattivo: {volatilityEmoji} Vol:{volatilityIndex:F2}x");

                // Se c'è almeno un recovery, mostra l'impatto
                if (recoveryCount > 0)
                {
                    double baseDD = MinDDIncreasePercent;
                    double adjustedDD = CalculateVolatilityAdjustedDD(baseDD);
                    double impact = ((adjustedDD / baseDD) - 1) * 100;

                    sb.AppendLine($"DD Adattivo: {baseDD:F1}%→{adjustedDD:F1}% ({(impact >= 0 ? "+" : "")}{impact:F1}%)");
                }
            }

            if (EnableSignalRSI)
            {
                double rsiBase = Indicators.RelativeStrengthIndex(Bars.ClosePrices, RsiPeriodBase).Result.LastValue;
                double rsiSuperiore = Indicators.RelativeStrengthIndex(MarketData.GetBars(RsiHigherTimeFrame).ClosePrices, RsiPeriodHigher).Result.LastValue;
                double delta = Math.Abs(rsiBase - rsiSuperiore);

                bool segnaleLong = (rsiBase < RsiHigherOversold) && ((rsiSuperiore - rsiBase) >= MinRsiDelta);
                bool segnaleShort = (rsiBase > RsiHigherOverbought) && ((rsiBase - rsiSuperiore) >= MinRsiDelta);

                string simbolo = segnaleLong ? "📈" : segnaleShort ? "📉" : "–";
                string stato = segnaleLong ? "LONG" : segnaleShort ? "SHORT" : "nessuno";

                sb.AppendLine($"• RSI Δ: {delta:N2} → {simbolo} {stato}");
            }

            string BuildVersion = BUILD_ID;

            sb.AppendLine($"v{BuildVersion.Split('-')[0].Trim()}");

            try
            {
                Chart.DrawStaticText(HUD_ID, sb.ToString(), HUDVertical, HUDHorizontal,
                                    GetColorFromProfitPercent(SafeDivide(profit, Account.Equity) * 100.0));
            }
            catch (Exception ex) { Print($"⚠️ HUD Compatto: {ex.Message}"); }
        }

        //==========================================================================
        // 🎛️ UTILITIES E FORMATTAZIONE
        //==========================================================================
        // Metodo helper per ottenere il numero corretto di decimali dal broker
        private int GetSymbolDigits()
        {
            return Symbol.Digits;  // Ottiene direttamente i decimali dal broker per il simbolo
        }

        // Metodo helper per formattare i numeri con i decimali corretti
        private string FormatNumber(double value)
        {
            int digits = GetSymbolDigits();
            return value.ToString($"F{digits}", System.Globalization.CultureInfo.InvariantCulture);
        }

        // Metodo helper per formattare i prezzi
        private string FormatPrice(double price)
        {
            return FormatNumber(price);
        }

        // Metodo helper per formattare i pips
        private string FormatPips(double pips)
        {
            return pips.ToString("F1", System.Globalization.CultureInfo.InvariantCulture);  // Pips sempre con 1 decimale
        }

        // Metodo helper per formattare importi monetari (€)
        private string FormatMoney(double amount)
        {
            return amount.ToString("F2", System.Globalization.CultureInfo.InvariantCulture);  // Importi sempre con 2 decimali
        }

        // Divisione sicura con fallback in caso di denominatore = 0
        private double SafeDivide(double numerator, double denominator, double fallback = 0.0)
        {
            return (denominator == 0.0) ? fallback : numerator / denominator;
        }

        private double GetAverageVolatility(int periods = 20)
        {
            if (Bars.Count < periods) return 0;

            double sum = 0;
            for (int i = 1; i <= periods; i++)
            {
                if (i >= Bars.Count) break;
                sum += Math.Abs(Bars.HighPrices[Bars.Count - i] - Bars.LowPrices[Bars.Count - i]);
            }

            return sum / periods;
        }

        // Aggiungi questo metodo nella sezione delle utility
        private void UpdateSpreadHistory()
        {
            // Determina l'intervallo di campionamento in base al TimeFrame
            double samplingMinutes;

            // Conversione TimeFrame in minuti per il sampling
            if (TimeFrame == TimeFrame.Minute)
                samplingMinutes = 0.5;   // Campiona ogni 30 secondi su M1
            else if (TimeFrame == TimeFrame.Minute5)
                samplingMinutes = 1;     // Campiona ogni minuto su M5
            else if (TimeFrame == TimeFrame.Minute15)
                samplingMinutes = 2;     // Campiona ogni 2 minuti su M15
            else if (TimeFrame == TimeFrame.Hour)
                samplingMinutes = 5;     // Campiona ogni 5 minuti su H1
            else if (TimeFrame == TimeFrame.Hour4)
                samplingMinutes = 15;    // Campiona ogni 15 minuti su H4
            else if (TimeFrame == TimeFrame.Daily)
                samplingMinutes = 60;    // Campiona ogni ora su D1
            else
                samplingMinutes = 1;     // Default: ogni minuto

            // Aggiorna solo se è passato il tempo necessario
            if ((Server.Time - lastSpreadRecordTime).TotalMinutes < samplingMinutes)
                return;

            // Ottieni lo spread attuale in pips
            double currentSpreadPips = Symbol.Spread / Symbol.PipSize;

            // Aggiungi alla coda
            spreadHistory.Enqueue(currentSpreadPips);
            spreadSampleCount++;

            // Limita la dimensione della coda in base al TimeFrame
            int maxSamples;

            // Imposta il numero massimo di campioni in base al TimeFrame
            if (TimeFrame == TimeFrame.Minute)
                maxSamples = 60;         // 30 minuti di storia su M1
            else if (TimeFrame == TimeFrame.Minute5)
                maxSamples = 60;         // 60 minuti di storia su M5
            else if (TimeFrame == TimeFrame.Minute15)
                maxSamples = 48;         // 96 minuti di storia su M15
            else if (TimeFrame == TimeFrame.Hour)
                maxSamples = 36;         // 3 ore di storia su H1
            else if (TimeFrame == TimeFrame.Hour4)
                maxSamples = 24;         // 6 ore di storia su H4
            else if (TimeFrame == TimeFrame.Daily)
                maxSamples = 24;         // 24 ore di storia su D1
            else
                maxSamples = 60;         // Default: 60 campioni

            while (spreadHistory.Count > maxSamples)
                spreadHistory.Dequeue();

            // Calcola la media
            averageSpreadPips = spreadHistory.Count > 0 ? spreadHistory.Average() : currentSpreadPips;

            // Aggiorna il timestamp
            lastSpreadRecordTime = Server.Time;

            // Log di debug occasionale (ogni 10 campioni)
            if (spreadSampleCount % 10 == 0 && EnableDebugLogs)
            {
                Print($"[SPREAD] Campioni: {spreadHistory.Count}, Media: {averageSpreadPips:F2} pips, Min: {spreadHistory.Min():F2}, Max: {spreadHistory.Max():F2}");
            }
        }

        // Metodo per ottenere lo spread medio
        private double GetAverageSpread()
        {
            // Se non abbiamo campioni, restituisci lo spread attuale
            if (spreadHistory.Count == 0)
                return Symbol.Spread / Symbol.PipSize;

            return averageSpreadPips;
        }

        //==========================================================================
        // 🎛️ CALCULATE VOLATILITY INDEX
        //==========================================================================
        // Nuovo metodo per calcolare indice di volatilità normalizzato
        private double CalculateVolatilityIndex(int periods)
        {
            if (Bars.Count < periods + 1)
                return 1.0; // Valore neutro se non ci sono abbastanza dati

            // Calcolo ATR personalizzato
            double atr = 0;
            for (int i = 1; i <= periods; i++)
            {
                double trueRange = Math.Max(
                    Bars.HighPrices[Bars.Count - i] - Bars.LowPrices[Bars.Count - i],
                    Math.Max(
                        Math.Abs(Bars.HighPrices[Bars.Count - i] - Bars.ClosePrices[Bars.Count - i - 1]),
                        Math.Abs(Bars.LowPrices[Bars.Count - i] - Bars.ClosePrices[Bars.Count - i - 1])
                    )
                ) / Symbol.PipSize;
                atr += trueRange;
            }
            atr /= periods;

            // Normalizzazione in base all'ATR medio dei periodi
            double baseATR = 10; // ATR base di riferimento (può essere parametrizzato)
            return atr / baseATR;
        }

        //==========================================================================
        // 🎛️ GET MARKET DEPTH FACTOR
        //==========================================================================
        // Metodo per calcolare fattore basato sulla liquidità/profondità del mercato
        private double GetMarketDepthFactor()
        {
            if (!EnableLiquidityProtection)
                return 1.0;

            // In una implementazione reale, questo potrebbe usare dati di order book
            // Per questa versione, semplicemente analizziamo lo spread come proxy di liquidità
            double spreadPips = Symbol.Spread / Symbol.PipSize;
            double spreadFactor = 1.0;

            if (spreadPips > 5.0)
                spreadFactor = 0.7;  // Spread alto = liquidità bassa = volumi più piccoli
            else if (spreadPips > 2.0)
                spreadFactor = 0.85;

            // Time of day factor - riduce volumi in orari a bassa liquidità
            double timeFactor = 1.0;
            if (EnableTimeBasedRecovery)
            {
                var serverHour = Server.Time.Hour;
                timeFactor = (serverHour >= 8 && serverHour <= 16) ? 1.0 : 0.85;
            }

            return spreadFactor * timeFactor;
        }

        //==========================================================================
        // ⚙️ SAFE CLOSE ALL POSITIONS
        //==========================================================================
        private void SafeCloseAllPositions(double? tpThreshold = null)
        {
            // Recupera tutte le posizioni sul simbolo
            var positionsToClose = Positions.Where(p => p.SymbolName == SymbolName).ToList();

            // Calcola soglia trailing
            double trailingMinProfit = GetTrailingTPThreshold(maxTP);

            if (!positionsToClose.Any())
            {
                Print("⛔ Nessuna posizione da chiudere");
                return;
            }

            double netProfit = GetNetProfitSymbol();
            Print($"🔍 Analisi chiusura - NetProfit: {netProfit:F2} €");
            Print($"🔍 Profitto totale al momento della chiusura: {netProfit:F2} € su {positionsToClose.Count} posizioni");
            Print($"🔄 Inizio chiusura sicura di {positionsToClose.Count} posizioni su {SymbolName}...");

            // 1. Verifica profit positivo
            if (netProfit <= 0)
            {
                Print($"⛔ Chiusura bloccata: profit negativo ({netProfit:F2} €)");
                return;
            }

            // 2. Caso speciale: TP Dinamico (trailing stop)
            bool isTpDynamicClose = tpThreshold.HasValue && EnableTrailingTP && tpDinamicoAttivato;

            if (isTpDynamicClose)
            {
                Print($"ℹ️ Verifica TP Dinamico - Trailing stop attivo, Soglia: {tpThreshold.Value:F2} €");

                if (maxTP >= TPStart)
                {
                    // CORREZIONE #2: Verifica che il profitto non sia troppo basso rispetto alla soglia
                    double minAcceptablePercentage = 0.01; // Non chiudere se sotto il 75% della soglia
                    double minAcceptableProfit = tpThreshold.Value * minAcceptablePercentage;

                    if (netProfit < minAcceptableProfit)
                    {
                        Print($"⚠️ Chiusura TP Dinamico bloccata: profitto troppo basso ({netProfit:F2} € < {minAcceptableProfit:F2} €)");
                        return;
                    }

                    Print($"✅ Condizione TP Dinamico confermata: chiusura quando profitto ({netProfit:F2} €) < soglia ({tpThreshold.Value:F2} €)");
                    Print($"⚡ TRIGGER TP DINAMICO ESATTO: Chiusura immediata a {netProfit:F2} € (soglia {trailingMinProfit:F2} €) e (min: {minAcceptablePercentage:F2}%)");
                }
                else
                {
                    Print($"⚠️ MaxTP ({maxTP:F2} €) non ha mai superato TPStart ({TPStart:F2} €) - TP Dinamico non correttamente attivato");
                }
            }

            // 3. Controllo MinProfitCheck (solo per chiusure non-trailing)
            else if (EnableMinProfitCheck && !CheckMinProfit(positionsToClose))
            {
                Print($"⛔ Chiusura bloccata: MinProfitCheck non soddisfatto");
                Print($"Profitto attuale: {netProfit:F2} € insufficiente rispetto al margine");
                return;
            }

            // 4. Verifica Breakeven se attivo
            if (EnableBE && triggerBreakevenAttivo && !isTpDynamicClose)
            {
                var referencePos = positionsToClose.LastOrDefault();
                if (referencePos != null)
                {
                    double beTarget = GetBreakEvenTargetPrice(referencePos);

                    if (!IsBreakEvenPriceValid(beTarget))
                    {
                        Print("⛔ Chiusura bloccata: target BE non valido");
                        return;
                    }
                }
            }

            // 5. Verifica spread SOLO se NON è una chiusura TP Dinamico
            // Per TP Dinamico abbiamo già verificato lo spread in IsSpreadSafeForClosing()
            if (!isTpDynamicClose)
            {
                double spreadPips = Symbol.Spread / Symbol.PipSize;
                double criticalSpreadPips = EnableAutoSpreadProtection
                    ? CalculateAutoSpreadThreshold()
                    : SpreadCriticoPips;

                if (spreadPips > criticalSpreadPips)
                {
                    Print($"⛔ Chiusura bloccata: spread critico ({spreadPips:F1} > {criticalSpreadPips:F1} pips)");
                    return;
                }
            }
            else
            {
                // Messaggio di bypass per TP Dinamico
                Print($"ℹ️ Bypass controllo spread per chiusura TP Dinamico (priorità alta)");
            }

            // Se tutti i controlli sono passati, procedi con la chiusura
            Print($"✅ Controlli superati - Avvio chiusura {positionsToClose.Count} posizioni");
            isClosing = true; // Flag per bloccare nuove entry temporaneamente

            // Procedi con la chiusura
            foreach (var pos in positionsToClose)
            {
                try
                {
                    var result = pos.Close();
                    if (result.IsSuccessful)
                    {
                        Print($"✅ Chiusa posizione {pos.Id}: {pos.NetProfit:F2} €");

                        // Dopo la chiusura di ogni posizione:
                        UpdateRecoveryCounter();
                    }
                    else
                        Print($"❌ Errore chiusura {pos.Id}: {result.Error}");
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore: {ex.Message}");
                }
            }

            // Reset stato
            lastForcedCloseTime = Server.Time;
            Reset();
            ResetTPDynamicValues();
            isClosing = false;

            Print("✅ Chiusura completata. Stato ripristinato.");
            Chart.RemoveAllObjects();
        }

        // Aggiungi questo metodo per aggiornare il contatore recovery
        private void UpdateRecoveryCounter()
        {
            recoveryCount = GetActiveRecoveryCount();
            Print($"🔄 Contatore recovery aggiornato: {recoveryCount} posizioni attive");
        }

        //==========================================================================
        // ⚙️ ON POSITION CLOSED
        //==========================================================================
        // Evento: log informativo quando una posizione viene chiusa
        // Modifica anche OnPositionClosed per aggiornare il contatore
        private void OnPositionClosed(PositionClosedEventArgs args)
        {
            var p = args.Position;
            if (p.SymbolName == SymbolName && (string.IsNullOrEmpty(CustomLabel) || p.Label == CustomLabel))
            {
                Print($"ℹ️ Posizione chiusa: {p.TradeType}, Profitto: {p.NetProfit:F2} €");

                // Aggiorna il contatore recovery
                if ((p.Label != null && p.Label.Contains("RECOVERY")) ||
                    (p.Comment != null && p.Comment.Contains("RECOVERY")))
                {
                    UpdateRecoveryCounter();

                    // Verifica se ci sono ancora posizioni recovery attive
                    bool anyRecoveryLeft = Positions.Any(pos =>
                        pos.SymbolName == SymbolName &&
                        ((pos.Label != null && pos.Label.Contains("RECOVERY")) ||
                         (pos.Comment != null && pos.Comment.Contains("RECOVERY"))));

                    // Se non ci sono più posizioni recovery, rimuovi linee e reset stato
                    if (!anyRecoveryLeft)
                    {
                        Chart.RemoveObject(TRAILING_SL_LINE);
                        Chart.RemoveObject(TRAILING_SL_LINE + "_label");
                        trailingStopLossAttivo = false;
                        lastTrailingStopLossPrice = 0;
                        Print($"🧹 Oggetti TSL rimossi - Nessuna posizione recovery rimasta attiva");
                    }
                    else
                    {
                        // Aggiorna la visualizzazione per le posizioni rimanenti
                        var remainingPositions = Positions.Where(pos => pos.SymbolName == SymbolName).ToList();
                        if (EnableRecoveryTrailingStopLoss && trailingStopLossAttivo)
                        {
                            ManageRecoveryTrailingStopLoss(remainingPositions);
                        }
                    }
                }
            }
        }

        //==========================================================================
        // ⚙️ CLAENUO RSI LABEL
        //==========================================================================
        // Nuovo metodo per la pulizia delle etichette (da chiamare in OnTick):
        /// <summary>
        /// Rimuove le etichette RSI obsolete o tutte se richiesto
        /// </summary>
        private void CleanupRSILabels()
        {
            try
            {
                // Se non ci sono etichette da rimuovere, esci
                if (rsiLabels.Count == 0 || Chart == null)
                    return;

                // Se ci sono posizioni aperte, rimuovi tutte le etichette
                if (Positions.Count > 0)
                {
                    RemoveAllRSILabels();
                    return;
                }

                // Se la pulizia automatica è disabilitata, esci
                if (!EnableAutoDeleteRSILabels)
                    return;

                // Ottieni il tempo corrente e l'indice della barra corrente
                DateTime currentTime = Time;
                int currentBarIndex = Bars.Count - 1;

                // Crea una lista di etichette da rimuovere
                List<RSILabel> labelsToRemove = new List<RSILabel>();

                foreach (var rsiLabel in rsiLabels)
                {
                    bool shouldDelete = false;

                    if (LabelsDeleteMode == DeleteLabelsMode.DopoNBarre)
                    {
                        // Calcola quante barre sono passate dalla creazione
                        int barsPassed = currentBarIndex - rsiLabel.CreationBarIndex;
                        shouldDelete = barsPassed >= BarsBeforeDelete;
                    }
                    else if (LabelsDeleteMode == DeleteLabelsMode.DopoNMinuti)
                    {
                        // Calcola quanti minuti sono passati dalla creazione
                        double minutesPassed = (currentTime - rsiLabel.CreationTime).TotalMinutes;
                        shouldDelete = minutesPassed >= MinutesBeforeDelete;
                    }

                    // Se l'etichetta deve essere rimossa, aggiungerla alla lista
                    if (shouldDelete)
                    {
                        labelsToRemove.Add(rsiLabel);

                        // Rimuovi l'oggetto dal grafico
                        if (!string.IsNullOrEmpty(rsiLabel.Tag))
                        {
                            Chart.RemoveObject(rsiLabel.Tag);
                        }
                    }
                }

                // Rimuovi le etichette dalla lista di tracciamento
                foreach (var labelToRemove in labelsToRemove)
                {
                    rsiLabels.Remove(labelToRemove);
                }

                // Log diagnostico
                if (labelsToRemove.Count > 0 && EnableDebugLogs)
                {
                    Print($"🧹 Rimosse {labelsToRemove.Count} etichette RSI obsolete. Rimaste: {rsiLabels.Count}");
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore durante la pulizia delle etichette RSI: {ex.Message}");
            }
        }

        //==========================================================================
        // ⚙️ MANAGE DYNAMIC TP
        //==========================================================================
        private void ManageDynamicTP(List<Position> positions, double netProfit)
        {
            if (!EnableTrailingTP || !positions.Any())
                return;

            // Calcolo TPStart dinamico
            double dynamicTPStart = CalculateEffectiveTPStart();

            // Aggiorna maxTP se il profitto è salito
            if (netProfit > maxTP)
            {
                maxTP = netProfit;
                DebugLog($"📈 Nuovo MaxTP registrato: {maxTP:F2} €");
            }

            // Attiva il TP dinamico solo se maxTP ha superato la soglia di attivazione
            if (maxTP >= dynamicTPStart && !tpDinamicoAttivato)
            {
                tpDinamicoAttivato = true;
                DebugLog($"🚀 TP Dinamico ATTIVATO: MaxTP {maxTP:F2} € ha superato soglia {dynamicTPStart:F2} €");
            }

            // Calcola soglia trailing
            double trailingMinProfit = GetTrailingTPThreshold(maxTP);

            // IMPORTANTE: Disegniamo SEMPRE la linea del TP Dinamico quando 
            // maxTP ha raggiunto la soglia, anche se tpDinamicoAttivato è ancora false
            if (maxTP >= dynamicTPStart || tpDinamicoAttivato)
            {
                DrawTPDynamicLineSafe(positions, trailingMinProfit);
            }

            // Solo se il TP dinamico è stato attivato procedere con le altre operazioni
            if (!tpDinamicoAttivato)
            {
                DebugLog($"[TPD] TP non attivo: MaxTP {maxTP:F2} < TPStart {dynamicTPStart:F2}");
                return;
            }

            // CONDIZIONE TRIGGER CRITICA: Chiudi IMMEDIATAMENTE ma solo se non troppo sotto la soglia
            double minAcceptablePercentage = 0.01; // Non chiudere se sotto l'1% della soglia
            double minAcceptableProfit = trailingMinProfit * minAcceptablePercentage;

            if (netProfit < trailingMinProfit && netProfit >= minAcceptableProfit && netProfit > 0)
            {
                Print($"⚡ TRIGGER TP DINAMICO ESATTO: Chiusura immediata a {netProfit:F2} € (soglia {trailingMinProfit:F2} €) e (min: {minAcceptablePercentage:F2}%)");

                // CHIUSURA PRIORITARIA CON PROTEZIONE SOGLIA MINIMA
                ExecuteImmediateClose(positions, netProfit, trailingMinProfit, minAcceptablePercentage);
            }
            else if (netProfit < minAcceptableProfit && netProfit > 0)
            {
                Print($"⚠️ Profitto {netProfit:F2} € troppo basso rispetto alla soglia: {trailingMinProfit:F2} € (min: {minAcceptableProfit:F2} €) e (min: {minAcceptablePercentage:F2}%) - Chiusura impedita");
            }
        }

        //==========================================================================
        // ⚙️ EXECUTE IMMEDIATE CLOSE
        //==========================================================================
        // Chiusura con priorità assoluta - nessun controllo aggiuntivo
        private void ExecuteImmediateClose(List<Position> positions, double netProfit, double trailingMinProfit, double minAcceptablePercentage)
        {
            if (!positions.Any()) return;

            // Imposta flag di chiusura attiva
            isClosing = true;

            Print($"⚡ ESECUZIONE CHIUSURA PRIORITARIA: {positions.Count} posizioni");
            Print($"⚡ TRIGGER TP DINAMICO ESATTO: Chiusura immediata a {netProfit:F2} € (soglia {trailingMinProfit:F2} €) e (min: {minAcceptablePercentage:F2}%)");

            // Timestamp esatto per analisi performance
            long startTicks = DateTime.Now.Ticks;

            // Conta le posizioni chiuse con successo per verificare la completezza dell'operazione
            int successfullyClosedPositions = 0;

            // Lista errori per debug
            List<string> errorMessages = new List<string>();

            // Chiusura con robustezza migliorata - prova fino a 3 tentativi per ogni posizione
            foreach (var pos in positions)
            {
                bool closed = false;
                int attempts = 0;

                while (!closed && attempts < 3)
                {
                    attempts++;
                    try
                    {
                        var result = pos.Close();
                        if (result.IsSuccessful)
                        {
                            Print($"⚡ ✅ Posizione {pos.Id}: {pos.NetProfit:F2} € (tentativo {attempts})");
                            successfullyClosedPositions++;
                            closed = true;
                        }
                        else
                        {
                            string errorMsg = $"❌ Tentativo {attempts} - Posizione {pos.Id}: {result.Error}";
                            errorMessages.Add(errorMsg);
                            Print(errorMsg);

                            // Piccola pausa tra i tentativi
                            System.Threading.Thread.Sleep(100);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errorMsg = $"❌ Errore tentativo {attempts} - Posizione {pos.Id}: {ex.Message}";
                        errorMessages.Add(errorMsg);
                        Print(errorMsg);

                        // Piccola pausa tra i tentativi
                        System.Threading.Thread.Sleep(100);
                    }
                }
            }

            // Calcola latenza di esecuzione
            double executionMs = (DateTime.Now.Ticks - startTicks) / TimeSpan.TicksPerMillisecond;
            Print($"⚡ Esecuzione completata in {executionMs:F2}ms - Chiuse {successfullyClosedPositions}/{positions.Count} posizioni");

            // Log riepilogativo se ci sono stati errori
            if (errorMessages.Any())
            {
                Print($"⚠️ {errorMessages.Count} errori durante la chiusura delle posizioni:");
                foreach (var error in errorMessages.Take(5)) // Mostra solo i primi 5 errori per non intasare il log
                    Print($"  - {error}");

                if (errorMessages.Count > 5)
                    Print($"  - ... e altri {errorMessages.Count - 5} errori");
            }

            // Reset stato
            ResetTPDynamicValues();
            lastForcedCloseTime = Server.Time;
            isClosing = false;
            Chart.RemoveAllObjects();
        }

        //==========================================================================
        // ⚙️ FORCE CLOSE ALL POSITIONS
        //==========================================================================
        // Nuovo metodo di chiusura diretta senza controlli aggiuntivi
        private void ForceCloseAllPositions()
        {
            var positionsToClose = Positions.Where(p => p.SymbolName == SymbolName).ToList();

            if (!positionsToClose.Any())
                return;

            isClosing = true;
            Print($"🔄 CHIUSURA FORZATA TP DINAMICO: {positionsToClose.Count} posizioni");

            foreach (var pos in positionsToClose)
            {
                try
                {
                    var result = pos.Close();
                    if (result.IsSuccessful)
                        Print($"✅ Chiusa posizione {pos.Id}: {pos.NetProfit:F2} €");
                    else
                        Print($"❌ Errore chiusura {pos.Id}: {result.Error}");
                }
                catch (Exception ex)
                {
                    Print($"❌ Errore: {ex.Message}");
                }
            }

            // Reset stato
            lastForcedCloseTime = Server.Time;
            Reset();
            ResetTPDynamicValues();
            isClosing = false;

            Print("✅ Chiusura completata. Stato ripristinato.");
            Chart.RemoveAllObjects();
        }

        //==========================================================================
        // ⚙️ GET OPERATION TYPE
        //==========================================================================
        private OperationType GetOperationType(Position position)
        {
            if (string.IsNullOrEmpty(position.Comment))
                return OperationType.Manual;

            if (position.Comment.StartsWith("RSI_"))
                return OperationType.RSI_Signal;

            if (position.Comment.StartsWith("RECOVERY_"))
                return OperationType.Recovery;

            return OperationType.Manual;
        }

        //==========================================================================
        // ⚙️ GET DYNAMIC MULTIPLIER
        //==========================================================================
        // Calcola il moltiplicatore dinamico in base alla modalità recovery selezionata
        private double GetDynamicMultiplier()
        {
            double baseMultiplier = RecoveryMultiplier;

            // Applica logica in base alla modalità scelta
            switch (SelectedRecoveryMode)
            {
                case RecoveryMode.Standard:
                    return baseMultiplier;

                case RecoveryMode.Bilanciato:
                    return Math.Max(1.5, baseMultiplier * 0.8);

                case RecoveryMode.Aggressivo:
                    return Math.Min(3.0, baseMultiplier * 1.5);

                default:
                    return baseMultiplier;
            }
        }

        //==========================================================================
        // ⚙️ CALCULATE RECOVERY LOTS
        //==========================================================================
        // Calcola il volume del prossimo recovery trade
        private double CalculateRecoveryLots(Position lastPosition, double multiplier)
        {
            // Per la prima posizione di recovery, se non ci sono posizioni precedenti
            if (recoveryCount == 0)
            {
                Print($"• Prima posizione recovery - uso VolumeInLots: {VolumeInLots:F2} lots come base");
                return NormalizeLots(VolumeInLots * multiplier);
            }

            // Calcola il volume totale di tutte le posizioni esistenti
            double totalExistingVolume = 0;
            var existingPositions = Positions.Where(p => p.SymbolName == SymbolName).ToList();

            foreach (var pos in existingPositions)
            {
                // Utilizza il metodo corretto per convertire le unità in lotti per questo specifico simbolo
                double posVolume = Symbol.VolumeInUnitsToQuantity(pos.VolumeInUnits);
                totalExistingVolume += posVolume;
                Print($"• Posizione {pos.Id}: {posVolume:F4} lots");
            }

            Print($"• Volume totale posizioni esistenti: {totalExistingVolume:F4} lots");

            // Protezione contro volumi troppo piccoli
            if (totalExistingVolume < 0.001)
            {
                Print($"⚠️ Volume totale troppo piccolo: {totalExistingVolume:F6}, uso VolumeInLots: {VolumeInLots:F2} come base");
                totalExistingVolume = VolumeInLots;
            }

            // Calcolo nuovo volume in base alla modalità
            double newLots = totalExistingVolume;

            switch (SelectedRecoveryMode)
            {
                case RecoveryMode.Standard:
                    newLots = totalExistingVolume * multiplier;
                    break;

                case RecoveryMode.Bilanciato:
                    newLots = totalExistingVolume * Math.Max(1.5, multiplier * 0.8);
                    break;

                case RecoveryMode.Aggressivo:
                    newLots = totalExistingVolume * Math.Min(3.0, multiplier * 1.5);
                    break;
            }

            Print($"• Calcolo: {totalExistingVolume:F4} × {multiplier:F2} = {newLots:F4} lots");

            // Normalizza i lotti calcolati
            newLots = NormalizeLots(newLots);

            // Applica limite massimo
            if (newLots > MaxAllowedLots)
            {
                newLots = Math.Floor(MaxAllowedLots * 100) / 100.0;
                Print($"• Volume limitato a MaxAllowedLots: {newLots:F2} lots");
            }

            // SafeMode - riduzione volume se FreeMargin basso
            if (Account.FreeMargin < SafeModeRecoveryFreeMargin)
            {
                newLots = NormalizeLots(newLots * 0.5);
                Print($"⚠️ SafeMode: volume ridotto a {newLots:F2} lots");
            }

            return newLots;
        }

        private double ApplySafeModeFreeMarginReduction(double calculatedLots)
        {
            // Se il Free Margin è abbondante, nessuna riduzione
            if (Account.FreeMargin >= SafeModeRecoveryFreeMargin * 2)
                return calculatedLots;

            // Definisci soglia critica e soglia superiore per la riduzione graduale
            double criticalThreshold = SafeModeRecoveryFreeMargin;
            double upperThreshold = SafeModeRecoveryFreeMargin * 2;

            // Calcola la percentuale di riduzione in base alla posizione del Free Margin tra le due soglie
            double reductionFactor;

            if (Account.FreeMargin <= criticalThreshold)
            {
                // Sotto la soglia critica: riduzione massima (50%)
                reductionFactor = 0.5;
                Print($"⚠️ SafeMode CRITICO: Free Margin ({Account.FreeMargin:F2} €) sotto la soglia critica ({criticalThreshold:F2} €)");
            }
            else
            {
                // Riduzione graduale tra 0% e 50% in base alla posizione relativa
                // Formula: 0.5 + 0.5 * (freeMargin - critical) / (upper - critical)
                double relativePosition = (Account.FreeMargin - criticalThreshold) / (upperThreshold - criticalThreshold);
                reductionFactor = 0.5 + (0.5 * relativePosition);
                Print($"⚠️ SafeMode ATTIVO: Free Margin ({Account.FreeMargin:F2} €) tra soglia critica ({criticalThreshold:F2} €) e soglia superiore ({upperThreshold:F2} €)");
            }

            // Applica il fattore di riduzione
            double reducedLots = calculatedLots * reductionFactor;

            // Normalizza il risultato
            double normalizedLots = NormalizeLots(reducedLots);

            // Log dettagliato
            Print($"📉 SafeMode: volume originale {calculatedLots:F2} lots → ridotto a {normalizedLots:F2} lots (fattore: {reductionFactor:P0})");

            return normalizedLots;
        }

        //==========================================================================
        // ⚙️ CALCULATE ADAPTIVE RECOVERY LOTS
        //==========================================================================
        // Metodo per calcolare volumi recovery adattivi
        // Metodo per calcolare volumi recovery adattivi
        private double CalculateAdaptiveRecoveryLots(Position lastPosition, double baseMultiplier)
        {
            if (lastPosition == null)
            {
                Print($"⚠️ Posizione precedente nulla, uso volume iniziale: {VolumeInLots:F2} lots come base");
                return NormalizeLots(VolumeInLots * baseMultiplier);
            }

            // Recupero volume precedente usando la conversione corretta del broker
            double previousLots = Symbol.VolumeInUnitsToQuantity(lastPosition.VolumeInUnits);
            Print($"• Volume precedente: {previousLots:F4} lots (convertito da {lastPosition.VolumeInUnits} units)");

            // Se il recovery adattivo è disabilitato, usa la formula standard
            if (!EnableAdaptiveRecovery)
                return NormalizeLots(Math.Min(previousLots * baseMultiplier, MaxAllowedLots));

            // Calcolo volatilità recente (ultimi 20 periodi)
            double volatility = CalculateVolatilityIndex(20);

            // Normalizzazione volatilità (0.5-2.0)
            double volatilityFactor = Math.Min(2.0, Math.Max(0.5, volatility));

            // Invertiamo la relazione: maggiore volatilità = moltiplicatore più basso
            double adjustedMultiplier = baseMultiplier / volatilityFactor;

            // Calcolo con formula progressiva smorzata - volumi crescono più lentamente ai livelli alti
            double recoveryMultiplier = adjustedMultiplier;
            if (recoveryCount > 2)
            {
                // Formula con logaritmo - crescita più lenta ai livelli alti
                recoveryMultiplier = baseMultiplier / (1 + Math.Log10(recoveryCount) * ProgressionDampeningFactor);
            }

            // Applicazione della protezione di mercato basata sul volume attuale market
            double marketDepthFactor = GetMarketDepthFactor();
            double maxSafeLots = previousLots * recoveryMultiplier * marketDepthFactor;

            // Log dettagliato
            Print($"• Calcolo volumi adattivo:");
            Print($"  ➤ Volatilità: {volatility:F2}, Fattore: {volatilityFactor:F2}");
            Print($"  ➤ Moltiplicatore base: {baseMultiplier:F2} → Adattato: {recoveryMultiplier:F2}");
            Print($"  ➤ Volume precedente: {previousLots:F4} × {recoveryMultiplier:F2} × {marketDepthFactor:F2} = {maxSafeLots:F4}");

            // Calcolo finale con normalizzazione
            double normalizedLots = NormalizeLots(Math.Min(maxSafeLots, MaxAllowedLots));

            // Protezione contro volumi troppo piccoli
            double minLots = GetMinimumAllowedLots();
            if (normalizedLots < minLots)
            {
                normalizedLots = minLots;
                Print($"⚠️ Volume calcolato troppo piccolo, corretto al minimo: {minLots:F2} lots");
            }

            return normalizedLots;
        }

        //==========================================================================
        // ⚙️ CALCULATE VOLATILITY ADJUSTED DD
        //==========================================================================
        // Nuovo metodo per calcolare DD in base alla volatilità
        private double CalculateVolatilityAdjustedDD(double baseDD)
        {
            if (!EnableAdaptiveRecovery)
                return baseDD;

            // Parametri
            double sensitivity = VolatilitySensitivityPercent / 100.0;
            double defaultATR = 10.0; // ATR di riferimento (pips)

            // Calcolo ATR attuale (20 periodi)
            double currentATR = 0;
            int periods = 20;

            for (int i = 1; i <= periods; i++)
            {
                if (i >= Bars.Count) break;

                double trueRange = Math.Max(
                    Bars.HighPrices[Bars.Count - i] - Bars.LowPrices[Bars.Count - i],
                    Math.Max(
                        Math.Abs(Bars.HighPrices[Bars.Count - i] - Bars.ClosePrices[Bars.Count - i - 1]),
                        Math.Abs(Bars.LowPrices[Bars.Count - i] - Bars.ClosePrices[Bars.Count - i - 1])
                    )
                ) / Symbol.PipSize;

                currentATR += trueRange;
            }

            currentATR /= periods;

            // Rapporto ATR attuale / ATR default
            double atrRatio = currentATR / defaultATR;

            // Calcolo DD adattato: più alto è l'ATR, più alto è il DD richiesto
            double adjustedDD = baseDD * (1.0 + ((atrRatio - 1.0) * sensitivity));

            // Limiti di sicurezza: il DD non può scendere sotto il 50% del base
            double minDD = baseDD * 0.5;

            // Log debug
            DebugLog($"[DD Volatilità] Base DD: {baseDD:F2}% | ATR ratio: {atrRatio:F2}x | Adjusted: {adjustedDD:F2}%");

            return Math.Max(minDD, adjustedDD);
        }

        //==========================================================================
        // ⚙️ GENERATE RECOVERY LABEL & COMMENT
        //==========================================================================
        // Genera label univoca per il recovery trade
        private string GenerateRecoveryLabel()
        {
            string baseLabel = string.IsNullOrWhiteSpace(CustomLabel) ?
                $"{SymbolName.Replace("★", "").Trim()}_RECOVERY" :
                $"{CustomLabel}_RECOVERY";

            return $"{baseLabel}_{recoveryCount + 1}";
        }

        // Genera commento per il recovery trade
        private string GenerateRecoveryComment(int recoveryNumber, TradeType tradeType)
        {
            string baseLabel = string.IsNullOrWhiteSpace(CustomLabel) ?
                $"{SymbolName.Replace("★", "").Trim()}_RECOVERY" :
                $"{CustomLabel}_RECOVERY";

            return $"{baseLabel}_{recoveryNumber}";
        }

        //==========================================================================
        // ⚙️ GET RECOVERY REFERENCE VALUE
        //==========================================================================
        // Valore di riferimento per il Recovery (Balance, Equity, FreeMargin)
        private double GetRecoveryReferenceValue() => RecoveryReference switch
        {
            RecoveryReferenceType.Balance => Account.Balance,
            RecoveryReferenceType.Equity => Account.Equity,
            RecoveryReferenceType.FreeMargin => Account.FreeMargin,
            _ => Account.Balance
        };

        //==========================================================================
        // 🔧 GET BREAKEVEN PRICE
        //==========================================================================
        /// <summary>
        /// Calcola il prezzo di break-even per una lista di posizioni.
        /// </summary>
        /// <param name="positions">Le posizioni aperte.</param>
        /// <returns>Il prezzo di break-even.</returns>
        private double GetBreakEvenPrice(List<Position> positions)
        {
            double totalCost = positions.Sum(p => p.EntryPrice * p.Quantity);
            double totalVolume = positions.Sum(p => p.Quantity);
            if (totalVolume == 0)
                return Symbol.Bid;
            return Math.Round(totalCost / totalVolume, Symbol.Digits);
        }

        //==========================================================================
        // 🔧 CHECK RSI VALID
        //==========================================================================
        // Filtro RSI attivo — Validazione LONG / SHORT in base ai livelli configurati
        private bool CheckRSIValid(Position p)
        {
            // Se il filtro RSI non è attivo, ritorna sempre true
            if (!EnableRSIFilter)
                return true;

            // Controlla RSI solo se il filtro è attivo
            if (double.IsNaN(rsi.Result.LastValue))
                return true; // Se RSI non è calcolato ancora, non bloccare

            return (p.TradeType == TradeType.Buy && rsi.Result.LastValue <= RSIMinBuy) ||
                   (p.TradeType == TradeType.Sell && rsi.Result.LastValue >= RSIMaxSell);
        }

        //==========================================================================
        // 🔧 CHECK MIN DISTANCE VALID
        //==========================================================================
        // Filtro distanza minima tra prezzo attuale e ultima posizione
        private bool CheckMinDistanceValid(Position p)
        {
            // Se il filtro distanza non è attivo, ritorna sempre true
            if (!EnableDistanceFilter)
                return true;

            double calculatedLots = EnableAdaptiveRecovery
                ? CalculateAdaptiveRecoveryLots(p, RecoveryMultiplier)
                : CalculateRecoveryLots(p, RecoveryMultiplier);

            // Calcola distanza dinamica basata sui volumi e modalità
            double dynamicMinDistancePips = CalculateDynamicDistanceFilter(MinDistancePips, p, calculatedLots);

            // Calcola la distanza effettiva
            double actualDistance = Math.Abs(Symbol.Bid - p.EntryPrice) / Symbol.PipSize;

            Print($"• Verifica distanza minima: attuale {actualDistance:F1} pips, richiesta {dynamicMinDistancePips:F1} pips");

            // Controlla la distanza minima usando il valore dinamico
            return actualDistance >= dynamicMinDistancePips;
        }

        //==========================================================================
        // 🔧 TROVA SWING ATTUALE
        //==========================================================================
        // Trova lo swing attuale (HIGH o LOW locale) analizzando le ultime N barre
        private TradeType? TrovaSwingAttuale()
        {
            if (Bars.Count < SwingDepthBars + 2)
                return null; // Non abbastanza dati

            int centro = Bars.Count - 2; // Ultima barra chiusa (NON il tick corrente)

            double highCentro = Bars.HighPrices[centro];
            double lowCentro = Bars.LowPrices[centro];

            bool isHigh = true;
            bool isLow = true;

            for (int i = centro - SwingDepthBars; i <= centro + SwingDepthBars; i++)
            {
                if (i < 0 || i >= Bars.Count)
                    continue;

                if (Bars.HighPrices[i] > highCentro)
                    isHigh = false;

                if (Bars.LowPrices[i] < lowCentro)
                    isLow = false;
            }

            if (isHigh)
                return TradeType.Sell; // Swing High ➔ preferire SELL
            else if (isLow)
                return TradeType.Buy;  // Swing Low ➔ preferire BUY
            else
                return null; // Nessun swing forte rilevato
        }

        //==========================================================================
        // 🔒 SAFE EXECUTION MARKET ORDER
        //==========================================================================
        private void SafeExecuteMarketOrder(TradeType tradeType, string symbolName, double lots, string label, double? sl = null, double? tp = null, string comment = "")
        {
            try
            {
                Print($"\n=== ESECUZIONE ORDINE ===");
                Print($"Volume richiesto: {lots:F2} lots");

                // 1. Normalizza il volume
                double normalizedLots = NormalizeLots(lots);
                Print($"Volume normalizzato: {normalizedLots:F2} lots");

                // 2. Converti in unità
                // long volume = (long)Symbol.QuantityToVolumeInUnits(normalizedLots);
                long volume = (long)Symbol.VolumeInUnitsToQuantity(normalizedLots);
                Print($"Volume finale: {volume} unità");

                // 3. Verifica validità
                if (volume <= 0)
                {
                    Print($"❌ Volume non valido: {volume} unità");
                    return;
                }

                // 4. Esegui ordine
                var result = ExecuteMarketOrder(tradeType, symbolName, volume, label, sl, tp, comment);

                if (result.IsSuccessful)
                    Print($"✅ Ordine eseguito: {tradeType}, {normalizedLots:F2} lots");
                else
                    Print($"❌ Errore esecuzione: {result.Error}");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in SafeExecuteMarketOrder: {ex.Message}");
            }
        }

        //==========================================================================
        // 🔧 SAFE PLACE LIMIT ORDER
        //==========================================================================
        // Esegue un ordine limite con protezione
        private void SafePlaceLimitOrder(TradeType tradeType, string symbolName, double lots, double targetPrice, string label = "", double? sl = null, double? tp = null)
        {
            try
            {
                // Usa il metodo corretto senza il parametro obsoleto
                SafePlaceLimitOrder(tradeType, symbolName, lots, targetPrice, label, sl, tp);
                Print($"✅ Ordine limit piazzato: {tradeType}, {lots} lots a {targetPrice}");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore nel piazzare ordine limit: {ex.Message}");
            }
        }

        //==========================================================================
        // 🔧 SAFE PLACE STOP ORDER
        //==========================================================================
        // Esegue un ordine stop con protezione
        private void SafePlaceStopOrder(TradeType tradeType, string symbolName, double lots, double targetPrice, string label = "", double? sl = null, double? tp = null)
        {
            try
            {
                // Usa il metodo corretto per piazzare un ordine stop
                SafePlaceStopOrder(tradeType, symbolName, lots, targetPrice, label, sl, tp);
                Print($"✅ Ordine stop piazzato: {tradeType}, {lots} lots a {targetPrice}");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore nel piazzare ordine stop: {ex.Message}");
            }
        }

        //==========================================================================
        // 🔧 SAFE CLOSE POSITION
        //==========================================================================
        // Chiusura posizione con protezione
        private void SafeClosePosition(Position position)
        {
            if (position == null || position.VolumeInUnits == 0)
                return;

            // Verifica spread prima della chiusura
            if (!IsSpreadSafeForClosing())
                return;

            var result = position.Close();
            if (result.IsSuccessful)
            {
                Print($"✅ Posizione chiusa: {position.TradeType}, Profitto: {position.NetProfit:F2} €");
            }
            else
            {
                Print($"⛔ Errore nella chiusura posizione: {result.Error}");
            }
            Chart.RemoveAllObjects();
        }

        //==========================================================================
        // 🔧 SUGGERISCI DIREZIONE SWING
        //==========================================================================
        // Analizza le ultime N barre per suggerire direzione
        private TradeDirection SuggerisciDirezioneSwing()
        {
            if (Bars.Count < BarreAnalisiSuggerimento + 2)
                return TradeDirection.Nessuna;

            int highCount = 0;
            int lowCount = 0;

            for (int i = Bars.Count - BarreAnalisiSuggerimento - 2; i < Bars.Count - 2; i++)
            {
                double centroHigh = Bars.HighPrices[i];
                double centroLow = Bars.LowPrices[i];

                bool isHigh = true;
                bool isLow = true;

                for (int j = i - 2; j <= i + 2; j++)
                {
                    if (j < 0 || j >= Bars.Count)
                        continue;

                    if (Bars.HighPrices[j] > centroHigh)
                        isHigh = false;

                    if (Bars.LowPrices[j] < centroLow)
                        isLow = false;
                }

                if (isHigh)
                    highCount++;

                if (isLow)
                    lowCount++;
            }

            if (highCount > lowCount * 1.2) // Se prevalgono HIGH ➔ suggerisci SHORT
                return TradeDirection.Short;
            else if (lowCount > highCount * 1.2) // Se prevalgono LOW ➔ suggerisci LONG
                return TradeDirection.Long;
            else
                return TradeDirection.Nessuna;
        }

        //==========================================================================
        // 🔧 DIAGNOSTICA MULTI SIMBOLO HUD
        //==========================================================================
        private void DiagnosticaMultiSimboloHUD()
        {
            if (!MostraDiagnosticaSimboli)
                return;

            var posizioni = Positions.ToList();
            var posizioniProprie = posizioni.Where(p => p.SymbolName == SymbolName).ToList();
            var altriSimboli = posizioni.Where(p => p.SymbolName != SymbolName)
                                        .GroupBy(p => p.SymbolName)
                                        .Select(g => new { Simbolo = g.Key, Numero = g.Count() })
                                        .ToList();

            var sb = new StringBuilder();

            sb.AppendLine($"📈 Simbolo attivo: {SymbolName}");
            sb.AppendLine($"• Posizioni proprie: {posizioniProprie.Count}");

            Color coloreHUD = Color.LimeGreen; // 🟢 Verde = tutto ok di default

            int anomalieRilevate = altriSimboli.Sum(x => x.Numero);

            if (anomalieRilevate > 0)
            {
                sb.AppendLine($"⚠️ Posizioni di altri simboli:");
                foreach (var altro in altriSimboli)
                    sb.AppendLine($"➔ {altro.Simbolo}: {altro.Numero} posizioni");

                if (anomalieRilevate == 1)
                    coloreHUD = Color.Orange; // 🟠
                else
                    coloreHUD = (Server.Time.Second % 2 == 0) ? Color.Red : Color.OrangeRed; // 🔴 lampeggio
            }
            else
            {
                sb.AppendLine("✅ Nessuna posizione anomala");
            }

            // Disegna HUD diagnostico
            try
            {
                Chart.DrawStaticText("DiagnosticaSimboli", sb.ToString(),
                    VerticalAlignment.Bottom, HorizontalAlignment.Right, coloreHUD);
            }
            catch (Exception ex)
            {
                Print($"⚠️ Errore DiagnosticaSimboli HUD: {ex.Message}");
            }

            // === LOG su console ogni 10s o se cambia il numero di anomalie
            if (anomalieRilevate != ultimoNumeroAnomalie || (Server.Time - ultimoLogDiagnostica).TotalSeconds > 10)
            {
                if (anomalieRilevate > 0)
                {
                    Print($"⚠️ [DIAGNOSTICA] {anomalieRilevate} posizione/i anomala/e rilevata/e su simboli diversi da {SymbolName}");
                }

                ultimoLogDiagnostica = Server.Time;
                ultimoNumeroAnomalie = anomalieRilevate;
            }
        }

        // ======================================================================
        // BLOCCO CORRETTO - CALCULATE DYNAMIC TP THRESHOLD
        // ======================================================================
        private (double minProfitToClose, string statusMessage, Color statusColor, double progress) CalculateDynamicTPThreshold(List<Position> positions)
        {
            if (!EnableTrailingTP || !positions.Any())
                return (0, "❌ TP Dinamico: DISATTIVATO", Color.Gray, -1);

            double currentProfit = positions.Sum(p => p.NetProfit);

            // Calcolo dinamico del TPStart se percentuale è impostata
            double dynamicTPStart = TPStart;
            if (TPStartPercent > 0)
            {
                double referenceValue = TPStartReference switch
                {
                    RecoveryReferenceType.Balance => Account.Balance,
                    RecoveryReferenceType.Equity => Account.Equity,
                    RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                    _ => Account.Equity
                };
                dynamicTPStart = Math.Max(TPStartMinimo, referenceValue * TPStartPercent / 100.0);
            }

            // Se non abbiamo ancora raggiunto il TPStart, ritorniamo ma mantenendo il calcolo del minProfit
            double minDynamicTP = dynamicTPStart * (1 - TPDrawdown / 100.0);
            if (currentProfit < dynamicTPStart)
            {
                // double minDynamicTP = dynamicTPStart * (1 - TPDrawdown / 100.0);
                double minProfitToClose = EnableMinProfitCheck
                    ? Math.Max(minDynamicTP, CalculateRequiredMinProfit(positions))
                    : minDynamicTP;

                return (minProfitToClose, "🕒 In attesa trigger", Color.Gray, -1);
            }

            // Calcolo margine usato con fallback
            double marginUsed;
            try
            {
                marginUsed = positions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits));
                if (marginUsed <= 0) throw new Exception("Invalid margin");
            }
            catch
            {
                marginUsed = positions.Sum(p => (p.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue);
            }

            // Calcolo soglie
            // double minDynamicTP = dynamicTPStart * (1 - TPDrawdown / 100.0);
            double minProfitRequired = EnableMinProfitCheck
                ? Math.Round(Math.Max(minDynamicTP, marginUsed * (1 + MinProfitOverMarginPercent / 100.0)), 2)
                : minDynamicTP;

            // Calcolo progresso (0-100% fino a TPStart, poi extra % oltre)
            double progress;
            string status;
            Color color;

            if (currentProfit >= dynamicTPStart)
            {
                // Extra profit oltre il target
                progress = 100 + ((currentProfit - dynamicTPStart) / (dynamicTPStart * 0.25)) * 100;
                status = $"🚀 Volo Libero {currentProfit:F2} €";
                color = Color.LimeGreen;
            }
            else if (currentProfit >= minDynamicTP)
            {
                // Avvicinamento al target
                progress = (currentProfit - minDynamicTP) / (dynamicTPStart - minDynamicTP) * 100;
                status = $"🏹 Avvicinamento {currentProfit:F2} €";
                color = Color.Orange;
            }
            else
            {
                // Sotto la soglia minima
                progress = 0;
                status = $"🔴 Sotto soglia {currentProfit:F2} €";
                color = Color.OrangeRed;
            }

            return (minProfitRequired, $"🎯 TP Dinamico: {status}", color, progress);
        }

        // ==================================================================
        // 🎨 Funzione per generare un colore graduale tra due estremi
        //    Esempio uso: SmoothGradientColor(Color.Red, Color.Green, 0.5)
        // ==================================================================
        private Color SmoothGradientColor(Color startColor, Color endColor, double t)
        {
            t = Math.Max(0.0, Math.Min(1.0, t)); // Clamp tra 0 e 1

            int r = (int)(startColor.R + (endColor.R - startColor.R) * t);
            int g = (int)(startColor.G + (endColor.G - startColor.G) * t);
            int b = (int)(startColor.B + (endColor.B - startColor.B) * t);
            int a = (int)(startColor.A + (endColor.A - startColor.A) * t);

            return Color.FromArgb(a, r, g, b);
        }

        private Color GetColorFromProfitPercent(double percent)
        {
            double scale = HUDColorMultiplier > 0 ? HUDColorMultiplier : 1.0;
            double scaledPercent = percent / scale;

            if (scaledPercent < -2)
                return HUDColorLossHard;
            else if (scaledPercent < -1)
                return HUDColorLossMed;
            else if (scaledPercent < -0.3)
                return HUDColorLossLight;
            else if (scaledPercent < 0)
                return HUDColorZero;
            else if (scaledPercent < 0.3)
                return HUDColorGainLight;
            else if (scaledPercent < 0.7)
                return HUDColorGainMed;
            else if (scaledPercent < 1.5)
                return HUDColorGainGood;
            else
                return HUDColorGainHigh;
        }

        private string GetEmojiFromColor(Color c)
        {
            if (c.R > 230 && c.G < 100) return "🔴";
            if (c.G > 230 && c.R < 100) return "🟢";
            return "⚪";
        }

        private string GeneraSliderColorato(double valorePercentuale, int blocchi = 12)
        {
            int filled = (int)(Math.Clamp(valorePercentuale, 0, 100) / (100.0 / blocchi));
            int empty = blocchi - filled;

            string barFilled = new string('■', filled);
            string barEmpty = new string('░', empty);
            string bar = $"[{barFilled}{barEmpty}]";

            Color color = GetColorFromProfitPercent(valorePercentuale);
            string emoji = GetEmojiFromColor(color);

            return $"{emoji} {bar} {valorePercentuale:F0}%";
        }

        //==========================================================================
        // 🔧 DRAW BREAKEVEN LINE SAFE
        //==========================================================================
        // 🔄 Disegna (o aggiorna) la linea del Breakeven Trigger con etichetta
        private void DrawBreakEvenLineSafe(Position reference, double targetProfit)
        {
            try
            {
                Print($"🧪 [DrawBreakEvenLineSafe] Chiamata con TP={targetProfit:F2}, Entry={reference?.EntryPrice}, Vol={reference?.VolumeInUnits}");

                if (reference == null)
                {
                    Print("⚠️ [BE] Riferimento posizione nullo, non disegno");
                    return;
                }

                // Modifica principale: disegna l'etichetta SOLO quando il triggerBreakeven è attivo
                bool shouldDraw = EnableBE && triggerBreakevenAttivo && fixedBreakEvenProfitThreshold > 0;

                if (!shouldDraw)
                {
                    Print("⚠️ [BE] BreakEven non attivo o trigger non raggiunto, rimozione oggetti");
                    Chart.RemoveObject("BreakEvenTriggerLine");
                    Chart.RemoveObject("BreakEvenTriggerLabel");
                    return;
                }

                double breakEvenTargetPrice = GetBreakEvenTargetPrice(reference);

                if (breakEvenTargetPrice <= 0 || double.IsNaN(breakEvenTargetPrice) || double.IsInfinity(breakEvenTargetPrice))
                {
                    Print($"⚠️ [BE] Target BE non valido: {breakEvenTargetPrice}, non disegno la linea");
                    return;
                }

                Print($"✅ BE Fixato: Entry={reference.EntryPrice:F5} ➜ Target={breakEvenTargetPrice:F5}");

                Chart.RemoveObject("BreakEvenTriggerLine");
                Chart.RemoveObject("BreakEvenTriggerLabel");

                // Disegna la linea orizzontale esattamente al prezzo target
                Chart.DrawHorizontalLine("BreakEvenTriggerLine", breakEvenTargetPrice, Color.Orange, 2, LineStyle.Dots);

                // Calcola informazioni aggiuntive per un'etichetta più completa
                double currentDistance = Math.Abs(Symbol.Bid - breakEvenTargetPrice) / Symbol.PipSize;
                string direction = reference.TradeType == TradeType.Buy ? "LONG" : "SHORT";
                double entryDistance = Math.Abs(reference.EntryPrice - breakEvenTargetPrice) / Symbol.PipSize;

                // Crea un'etichetta più informativa e strutturata
                string labelText = $"📍 BREAKEVEN TARGET\n" +
                                  /*$"• Prezzo: {breakEvenTargetPrice:F5}\n" +*/
                                  $"• Prezzo: {breakEvenTargetPrice}" +
                                  $" • Profitto target: {targetProfit:F2} €\n" +
                                  $"• Distanza attuale: {currentDistance:F1} pips" +
                                  $" • Direzione: {direction}";

                var label = Chart.DrawText(
                    "BreakEvenTriggerLabel",
                    labelText,
                    Server.Time,
                    breakEvenTargetPrice,
                    Color.Orange
                );

                // Imposta proprietà dell'etichetta
                label.FontSize = 10;
                label.IsBold = false;

                Print($"✅ [BE] Linea e etichetta BreakEven disegnate a {breakEvenTargetPrice:F5}");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore disegno BreakEven: {ex.Message}");
                Print($"Stack: {ex.StackTrace}");
            }
        }

        //==========================================================================
        // 🔧 CLOSE AND LOG
        //==========================================================================
        private void CloseAndLog(List<Position> positions, double livello, string motivazione)
        {
            foreach (var p in positions.Where(p => p.SymbolName == SymbolName))
            {
                SafeClosePosition(p);
            }
            Print($"✅ {motivazione}: Chiusura a {livello:F2} €");
            Reset();
        }

        //==========================================================================
        // 🔧 GENERATE DYNAMIC TP MESSAGE
        //==========================================================================
        private string GenerateDynamicTPMessage(double currentProfit, List<Position> positions)
        {
            // Calcolo valori base
            double dynamicTPStart = TPStart;
            if (TPStartPercent > 0)
            {
                double referenceValue = TPStartReference switch
                {
                    RecoveryReferenceType.Balance => Account.Balance,
                    RecoveryReferenceType.Equity => Account.Equity,
                    RecoveryReferenceType.FreeMargin => Account.FreeMargin,
                    _ => Account.Equity
                };
                dynamicTPStart = Math.Max(TPStartMinimo, referenceValue * TPStartPercent / 100.0);
            }

            // Calcolo margine usato con fallback
            double marginUsed = 0;
            try
            {
                marginUsed = positions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits));
                if (marginUsed <= 0) throw new Exception("Margin calculation failed");
            }
            catch
            {
                // Fallback manuale se GetEstimatedMargin fallisce
                marginUsed = positions.Sum(p => (p.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue);
            }

            // Calcolo soglia completa
            double minProfitFromTP = dynamicTPStart / (1 - TPDrawdown / 100.0);
            double minProfitFromMargin = EnableMinProfitCheck ? marginUsed * (MinProfitOverMarginPercent / 100.0) : 0;
            double minProfitToClose = minProfitFromTP + minProfitFromMargin;

            // Preparazione messaggio
            var sb = new StringBuilder();

            sb.AppendLine("🔢 CALCOLO SOGLIA TP DINAMICO");
            sb.AppendLine("══════════════════════════════════");
            sb.AppendLine($"▸ TPStart: {dynamicTPStart:F2} €");
            sb.AppendLine($"▸ Drawdown max: {TPDrawdown}% (→ soglia {dynamicTPStart * (1 - TPDrawdown / 100.0):F2} €)");
            sb.AppendLine($"▸ Margine usato: {marginUsed:F2} €");
            sb.AppendLine($"▸ MinProfit%: {MinProfitOverMarginPercent}%");

            sb.AppendLine("\n📊 Formula applicata:");
            sb.AppendLine("");
            sb.AppendLine(EnableMinProfitCheck
                ? $"MinProfitToClose = (TPStart / (1 - TPDrawdown%)) + (Margine × MinProfit%)"
                : $"MinProfitToClose = (TPStart / (1 - TPDrawdown%))");

            sb.AppendLine($"                = ({dynamicTPStart:F2} € / {1 - TPDrawdown / 100.0:F2})");

            if (EnableMinProfitCheck)
            {
                sb.AppendLine($"                + ({marginUsed:F2} € × {MinProfitOverMarginPercent / 100.0:F2})");
            }

            sb.AppendLine($"                = {minProfitFromTP:F2} €");

            if (EnableMinProfitCheck)
            {
                sb.AppendLine($"                + {minProfitFromMargin:F2} € = {minProfitToClose:F2} €");
            }
            sb.AppendLine("");

            // Stato attuale
            double progressPercent = SafeDivide(currentProfit, minProfitToClose) * 100;
            int progressBars = (int)Math.Min(10, progressPercent / 10);

            sb.AppendLine("\n🔄 Stato attuale:");
            sb.AppendLine($"[{new string('■', progressBars)}{new string('░', 10 - progressBars)}] " +
                          $"{currentProfit:F2} € ({progressPercent:F1}% della soglia)");

            sb.AppendLine(currentProfit >= minProfitToClose
                ? "✅ Autorizzata chiusura automatica"
                : "⏳ In attesa del raggiungimento soglia");

            // Note tecniche
            if (EnableMinProfitCheck)
            {
                sb.AppendLine("\n⚠️ Vincoli attivi:");
                sb.AppendLine($"1. Superamento TPStart ({dynamicTPStart:F2} €)");
                sb.AppendLine($"2. Rispetto vincolo margine ({marginUsed:F2} € × {MinProfitOverMarginPercent}%)");
                sb.AppendLine($"3. Drawdown ≤{TPDrawdown}% dalla cima");
            }
            else
            {
                sb.AppendLine("\nℹ️ MinProfitCheck disattivato - Solo controllo TP dinamico");
            }

            return sb.ToString();
        }

        //======================================       
        //  GET NET PROFIT SYMBOL
        //======================================
        /// <summary>
        /// Calcola il profitto netto totale di tutte le posizioni aperte sul simbolo corrente.
        /// </summary>
        private double GetNetProfitSymbol()
        {
            return Positions.Where(p => p.SymbolName == SymbolName).Sum(p => p.NetProfit);
        }

        private double GetSymbolMargin(string symbolName)
        {
            // Filtra solo le posizioni del simbolo specificato
            var symbolPositions = Positions.Where(p => p.SymbolName == symbolName).ToList();

            // Calcola il margine totale per queste posizioni
            double marginUsed = 0;
            foreach (var pos in symbolPositions)
            {
                try
                {
                    double posMargin = Symbol.GetEstimatedMargin(pos.TradeType, pos.VolumeInUnits);
                    marginUsed += posMargin;
                }
                catch
                {
                    // Fallback se GetEstimatedMargin fallisce
                    marginUsed += (pos.VolumeInUnits / Account.PreciseLeverage) * Symbol.TickSize * Symbol.TickValue;
                }
            }

            return marginUsed;
        }

        //======================================       
        //  CHECK MIN PROFIT
        //======================================
        // Verifica MinProfit con tolleranze
        private bool CheckMinProfit(List<Position> positions)
        {
            if (!EnableMinProfitCheck)
                return true;

            // MODIFICA: Assicuriamo che vengano considerate solo le posizioni del simbolo corrente
            var symbolPositions = positions.Where(p => p.SymbolName == SymbolName).ToList();

            double requiredProfit = CalculateRequiredMinProfit(symbolPositions);
            double currentProfit = symbolPositions.Sum(p => p.NetProfit);

            // Aggiustamento per spread elevato
            double spreadInPips = Symbol.Spread;
            if (spreadInPips > SpreadCriticoPips)
            {
                double spreadPenalty = Symbol.PipValue * 3;
                requiredProfit += spreadPenalty;
                DebugLog($"[SpreadAlert] Spread elevato: {spreadInPips} pips -> Soglia aumentata di {spreadPenalty:F2} €");
            }

            // Tolleranza 95%
            double flessibileThreshold = requiredProfit * 0.95;

            // MODIFICA: Verifichiamo il margine solo per il simbolo corrente invece che Account.Margin
            double symbolMargin = symbolPositions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.VolumeInUnits));
            if (symbolMargin <= 0)
            {
                DebugLog("ℹ️ Nessun margine attivo per il simbolo: controllo MinProfit non applicabile.");
                return true;
            }

            // Avviso per configurazione rischiosa
            if (MinProfitOverMarginPercent < 5)
            {
                DebugLog($"⚠️ Avviso: MinProfitOverMarginPercent molto basso ({MinProfitOverMarginPercent}%). Potrebbe non coprire rischi/margine.");
            }

            bool result = currentProfit >= flessibileThreshold;

            DebugLog($"[MinProfitCheck] Richiesto: {requiredProfit:F2} € (Tolleranza 95%: {flessibileThreshold:F2} €) | " +
                     $"Attuale: {currentProfit:F2} € | " +
                     $"Esito: {(result ? "🟢 OK" : "🔴 NON OK")}");

            return result;
        }

        //==========================================================================
        // 🔧 CHECK MIN PROFIT SOFT
        //==========================================================================
        // Verifica soft del MinProfit per tolleranza addizionale
        private bool CheckMinProfitSoft(List<Position> positions)
        {
            if (!EnableMinProfitCheck)
                return true;

            // MODIFICA: Assicuriamo che vengano considerate solo le posizioni del simbolo corrente
            var symbolPositions = positions.Where(p => p.SymbolName == SymbolName).ToList();

            double margin = symbolPositions.Sum(p => Symbol.GetEstimatedMargin(p.TradeType, p.Quantity));

            if (margin <= 0)
            {
                DebugLog($"[BE] ⚠️ CheckMinProfitSoft: margine nullo ➜ ritorna TRUE (tolleranza attiva)");
                return true;
            }

            double profit = symbolPositions.Sum(p => p.NetProfit);
            double requiredProfit = margin * 1.0001; // Tolleranza minima dello 0.01%

            DebugLog($"[BE] 🟡 MinProfitSoft: profitto attuale = {profit:F2}, richiesto = {requiredProfit:F2}");

            return profit >= requiredProfit;
        }

        //==========================================================================
        // 🔧 CALCULATE REQUIRED MIN PROFIT
        //==========================================================================
        // === 🔧 METODO CALCOLO MINPROFIT RICHIESTO ===
        private double CalculateRequiredMinProfit(List<Position> positions)
        {
            if (!EnableMinProfitCheck || !positions.Any())
                return 0;

            try
            {
                // MODIFICA: Assicuriamo che vengano considerate solo le posizioni del simbolo corrente
                var symbolPositions = positions.Where(p => p.SymbolName == SymbolName).ToList();
                if (!symbolPositions.Any())
                    return 0;

                // Calcolo margine con log dettagliato
                double marginUsed = 0;
                foreach (var pos in symbolPositions)
                {
                    double posMargin = Symbol.GetEstimatedMargin(pos.TradeType, pos.VolumeInUnits);
                    Print($"Margine posizione {pos.Id}: {posMargin:F2} €");
                    marginUsed += posMargin;
                }
                Print($"Margine totale del simbolo {SymbolName}: {marginUsed:F2} €");

                // Calcolo profitto minimo richiesto
                double multiplier = 1 + (MinProfitOverMarginPercent / 100.0);
                double minProfit = marginUsed * multiplier;

                Print($"Calcolo MinProfit: {marginUsed:F2} € × {multiplier:F4} = {minProfit:F2} €");

                // Verifica e correzione
                if (minProfit < 0)
                {
                    Print($"⚠️ Rilevato MinProfit negativo: {minProfit:F2} € - Corretto a 0");
                    minProfit = 0;
                }

                return minProfit;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore calcolo MinProfit: {ex.Message}");
                return 0;
            }
        }

        //==========================================================================
        // 🔧 GET DYNAMIC TP STATUS
        //==========================================================================
        private (string emoji, string label) GetDynamicTPStatus(double progressPercent)
        {
            if (progressPercent < 0) return ("", "");

            progressPercent = Math.Max(0, progressPercent);
            return progressPercent switch
            {
                >= 0 and < 25 => ("🌱", "Base Sicura"),
                >= 25 and < 50 => ("📈", "Crescita Stabile"),
                >= 50 and < 75 => ("🚦", "Via Libera"),
                >= 75 and < 90 => ("🏹", "Mira al Massimo"),
                >= 90 and < 100 => ("🎯", "Target a Portata"),
                >= 100 and < 110 => ("🚀", "Volo Libero"),
                >= 110 and < 125 => ("🌈", "Performance Brillante"),
                _ => ("💰", "Extra Profit")
            };
        }

        //==========================================================================
        // 🔧 GENERA SLIDER COLORATO
        //==========================================================================
        private string GeneraSliderColorato(double percentuale)
        {
            if (percentuale < 0) return string.Empty; // Non mostrare nulla se non attivo
            var (emoji, label) = GetDynamicTPStatus(percentuale);
            int blocchiTotali = 12;
            int blocchiPieni = (int)Math.Min(blocchiTotali, Math.Max(0, percentuale) / 10.0);

            string barra = new string('■', blocchiPieni) +
                          new string('░', blocchiTotali - blocchiPieni);

            return $"{emoji} {label} [{barra}] {Math.Max(0, percentuale):F1}%";
        }

        //==========================================================================
        // 🔧 GENERA SLIDER COLORATO COMPATTO
        //==========================================================================
        private string GeneraSliderColoratoCompatto(double percentuale)
        {
            if (percentuale < 0) return "OFF";
            var (emoji, _) = GetDynamicTPStatus(percentuale);
            int blocchiTotali = 8;
            int blocchiPieni = (int)Math.Min(blocchiTotali, Math.Max(0, percentuale) / 20.0);

            string barra = new string('■', blocchiPieni) +
                          new string('□', blocchiTotali - blocchiPieni);

            return $"{emoji} {Math.Max(0, percentuale):F0}% {barra}";
        }

        // ======================================================================
        // GET DYNAMIC DISPLAY TP DISPLAY
        // ======================================================================
        private string GetDynamicTPDisplay(double currentProfit, double minProfitToClose, double progress)
        {
            if (progress < 0)
                return $"\n🎯 TP Dinamico: 🕒 In attesa trigger ({currentProfit:F2}/{TPStart:F2} €)";

            var (emoji, label) = progress switch
            {
                >= 0 and < 25 => ("🌱", "Base Sicura"),
                >= 25 and < 50 => ("📈", "Crescita Stabile"),
                >= 50 and < 75 => ("🚦", "Via Libera"),
                >= 75 and < 90 => ("🏹", "Mira al Massimo"),
                >= 90 and < 100 => ("🎯", "Target a Portata"),
                >= 100 and < 110 => ("🚀", "Volo Libero"),
                >= 110 and < 125 => ("🌈", "Performance Brillante"),
                _ => ("💰", "Extra Profit")
            };

            int blocks = (int)Math.Min(12, progress / 11);
            string slider = $"[{new string('■', blocks)}{new string('░', 12 - blocks)}]";

            return $"🎯 TP Dinamico: {emoji} {label} {slider} {progress:F1}%";
        }

        //==========================================================================
        // 🔧 GET BREAKEVEN TARGET PRICE
        //==========================================================================
        // ✅ Calcolo preciso del prezzo target BreakEven in base al profitto fissato
        // Calcola il prezzo effettivo di uscita per la chiusura BreakEven, basato su fixedBreakEvenProfitThreshold
        // ✅ Calcolo corretto del prezzo target di uscita per il BreakEven
        private double GetBreakEvenTargetPrice(Position reference)
        {
            if (reference == null || fixedBreakEvenProfitThreshold <= 0 || reference.VolumeInUnits <= 0)
            {
                Print($"⚠️ [BE] Parametri invalidi ➜ Entry={reference?.EntryPrice}, Vol={reference?.VolumeInUnits}, TP={fixedBreakEvenProfitThreshold}");
                return 0.0;
            }

            double euroPerPip = reference.VolumeInUnits * Symbol.PipValue;
            if (euroPerPip <= 0 || double.IsNaN(euroPerPip))
            {
                Print($"❌ [BE] euroPerPip non valido ➜ euroPerPip={euroPerPip}");
                return reference.EntryPrice; // fallback
            }

            double pips = fixedBreakEvenProfitThreshold / euroPerPip;
            double offset = pips * Symbol.PipSize;

            double target = reference.TradeType == TradeType.Buy
                ? reference.EntryPrice + offset
                : reference.EntryPrice - offset;

            Print($"📌 [BE] Calcolato Target={target} (pips={pips}, offset={offset})");

            return target;
        }

        //==========================================================================
        // 🔧 IS BREAKEVEN PRICE VALID
        //==========================================================================
        // Verifica se il prezzo di BreakEven è valido e non corrotto
        private bool IsBreakEvenPriceValid(double price)
        {
            return price > 0 && price < 1000 && !double.IsNaN(price) && !double.IsInfinity(price);
        }

        private Color ParseColor(string hexOrName)
        {
            try { return Color.FromName(hexOrName); }
            catch
            {
                try { return Color.FromHex(hexOrName); }
                catch { return Color.White; } // fallback sicuro
            }
        }

        /// <summary>
        /// Disegna un segnale di trading sul grafico solo se non ci sono posizioni aperte
        /// </summary>
        private void DrawSegnaleGraficoRSI(bool isBuy, DateTime time, double prezzo)
        {
            try
            {
                bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

                // In TrendFollowing, l'etichetta grafica è invertita rispetto alla direzione dell'ordine
                string labelPrefix = isTrendFollowing ?
                    (isBuy ? "SELL" : "BUY") :   // Etichetta opposta in TrendFollowing 
                    (isBuy ? "BUY" : "SELL");    // Etichetta normale in Contrarian

                string labelId = $"RSI_{labelPrefix}_{DateTime.Now.Ticks}";

                // Aggiungi alla lista per pulizia automatica
                rsiLabels.Add(new RSILabel
                {
                    Tag = labelId,
                    CreationTime = time,
                    CreationBarIndex = Bars.ClosePrices.Count - 1
                });

                // La direzione dell'icona è basata sulla direzione effettiva dell'ordine
                bool finalDirection = isBuy;

                // Disegna l'icona appropriata
                if (finalDirection) // LONG/BUY
                {
                    Chart.DrawIcon(labelId, ChartIconType.UpTriangle, time, prezzo - 15 * Symbol.PipSize, Color.LimeGreen);
                }
                else // SHORT/SELL
                {
                    Chart.DrawIcon(labelId, ChartIconType.DownTriangle, time, prezzo + 15 * Symbol.PipSize, Color.Red);
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in DrawSegnaleGraficoRSI: {ex.Message}");
            }
        }

        /// <summary>
        /// Gestisce l'evento di apertura di una nuova posizione
        /// </summary>
        // Modifica la firma del metodo per corrispondere alla classe base Robot
        [Obsolete]
        protected override void OnPositionOpened(Position openedPosition)
        {
            try
            {
                // NUOVO CODICE: Reset del flag per sicurezza aggiuntiva e aggiornamento del timestamp
                _pendingPositionExecution = false;
                _lastPositionOpenTime = DateTime.Now;

                // Aggiorna il contatore di posizioni aperte nell'HUD
                lastPosizioniAperteHUD = Positions.Count;

                // Pulisci tutte le etichette RSI dal grafico quando si apre una posizione
                RemoveAllRSILabels();

                // Log dell'operazione
                if (EnableDebugLogs)
                {
                    Print($"✅ Posizione aperta: {openedPosition.Label}, Volume: {Symbol.VolumeInUnitsToQuantity(openedPosition.VolumeInUnits):F2} lots, {openedPosition.TradeType}");
                }

                // Se è una posizione di recovery, aggiorna il conteggio
                if (openedPosition.Label?.Contains("Recovery") == true || openedPosition.Comment?.Contains("Recovery") == true)
                {
                    if (openedPosition.TradeType == TradeType.Buy)
                    {
                        lastSignalLongTime = DateTime.Now;
                    }
                    else
                    {
                        lastSignalShortTime = DateTime.Now;
                    }
                }

                // Aggiorna il display HUD
                if (ShowHUD)
                {
                    double profit = Positions.Sum(p => p.NetProfit);
                    double pips = GetDistanceFromEntry();
                    double be = GetBreakEvenPrice(Positions.ToList());
                    DrawHUD(profit, maxTP, actualDDpercent, pips, be, openedPosition);
                    DrawHUD_RSI();
                }

                // Aggiungi messaggio HUD temporaneo
                MostraMessaggioOrdineHUD($"Aperto {openedPosition.TradeType}: {Symbol.VolumeInUnitsToQuantity(openedPosition.VolumeInUnits):F2} lots",
                    openedPosition.TradeType == TradeType.Buy ? Color.LimeGreen : Color.HotPink);
            }
            catch (Exception ex)
            {
                Print($"❌ ERRORE in OnPositionOpened: {ex.Message}");

                // NUOVO CODICE: Assicuriamoci che il flag venga resettato anche in caso di errore
                _pendingPositionExecution = false;
            }
        }

        /// <summary>
        /// Rimuove tutte le etichette RSI dal grafico
        /// </summary>
        private void RemoveAllRSILabels()
        {
            try
            {
                if (Chart == null || rsiLabels == null || rsiLabels.Count == 0)
                    return;

                foreach (var label in rsiLabels)
                {
                    if (!string.IsNullOrEmpty(label.Tag))
                    {
                        Chart.RemoveObject(label.Tag);

                        // Rimuovi anche l'icona associata
                        Chart.RemoveObject(label.Tag + "_icon");
                    }
                }

                // Svuota la lista dopo aver rimosso tutte le etichette
                rsiLabels.Clear();

                if (EnableDebugLogs)
                    Print($"🧹 Rimosse tutte le etichette RSI dal grafico dopo apertura posizione");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore nella rimozione delle etichette RSI: {ex.Message}");
            }
        }

        //==========================================================================
        // 🔧 ESEGUI ORDINE
        //==========================================================================
        private void EseguiOrdine(bool isLong, double prezzo)
        {
            var volume = Symbol.QuantityToVolumeInUnits(SignalLotSize);

            var slPips = SignalStopLossPips > 0 ? SignalStopLossPips : (double?)null;
            var tpPips = SignalTakeProfitPips > 0 ? SignalTakeProfitPips : (double?)null;

            var tipoOrdine = isLong ? TradeType.Buy : TradeType.Sell;

            var label = string.IsNullOrWhiteSpace(CustomLabel) ? SymbolName : CustomLabel;

            // var result = ExecuteMarketOrder(tipoOrdine, SymbolName, volume, label, stopLossPips: slPips, takeProfitPips: tpPips, comment: CustomComment);
            var result = ExecuteMarketOrder(tipoOrdine, SymbolName, volume, label, slPips, tpPips, comment: CustomComment);

            if (result.IsSuccessful)
            {
                Print($"✅ Ordine {(isLong ? "LONG" : "SHORT")} eseguito con successo | SL: {(slPips.HasValue ? $"{slPips:F1} pips" : "Nessuno")}, TP: {(tpPips.HasValue ? $"{tpPips:F1} pips" : "Nessuno")}");
            }
            else
            {
                Print($"❌ Errore esecuzione ordine {(isLong ? "LONG" : "SHORT")}: {result.Error}");
            }
        }

        //==========================================================================
        // 🔧 DRAW MULTI LINE TEXT
        //==========================================================================
        private void DrawMultiLineText(string label, List<string> lines, DateTime time, double y, Color color, int textSize = 10)
        {
            string text = string.Join("\n", lines);

            // Rimuove oggetto esistente se già presente
            if (Chart.Objects.Any(o => o.Name == label))
                Chart.RemoveObject(label);

            // Disegna il testo sulla chart all'orario e livello Y specificati
            var textObj = Chart.DrawText(label, text, time, y, color);
            textObj.FontSize = textSize;
            textObj.IsBold = true;
        }

        //==========================================================================
        // 🔧 GENERA SLIDER TECNICO
        //==========================================================================
        private string GeneraSliderTecnico(double valore, double min, double max, double soglia, int blocchi = 12)
        {
            double percentuale = SafeDivide(valore - min, max - min) * 100.0;
            percentuale = Math.Max(0, Math.Min(100, percentuale));

            int filled = (int)(percentuale / (100.0 / blocchi));
            int empty = blocchi - filled;

            string barra = new string('■', filled) + new string('·', empty);
            string stato = valore >= soglia ? "Δ OK" : "LOW";

            return $"[{barra}] {valore:N2} ({stato})";
        }

        //==========================================================================
        // 🔧 IS IN RECOVERY MODE
        //==========================================================================
        private bool IsInRecoveryMode()
        {
            // Verifica se il recovery è abilitato e ci sono posizioni di recovery attive
            return EnableRecovery && HasActiveRecoveryPositions();
        }

        //==========================================================================
        // 🔧 HAS ACTIVE RECOVERY POSITIONS
        //==========================================================================
        private bool HasActiveRecoveryPositions()
        {
            // Cerca posizioni con commento che inizia con "RECOVERY_"
            var recoveryPositions = Positions.Where(p =>
                p.SymbolName == SymbolName &&
                p.Comment != null &&
                p.Comment.StartsWith("RECOVERY_"));

            // Verifica anche il contatore di recovery
            bool hasRecoveryCount = recoveryCount > 0;

            // Log di debug
            if (EnableDebugLogs)
            {
                Print($"[Recovery Check] Posizioni recovery: {recoveryPositions.Count()}, Recovery count: {recoveryCount}");
            }

            // Ritorna true se ci sono posizioni di recovery o il contatore è > 0
            return recoveryPositions.Any() || hasRecoveryCount;
        }

        //==========================================================================
        // 🔧 DISEGNA SEGNALE RSI
        //==========================================================================
        private void DebugSegnaleRSI(bool isLong, double rsiBase, double rsiFiltro, double prezzo)
        {
            string tipo = isLong ? "LONG" : "SHORT";
            double delta = Math.Abs(rsiBase - rsiFiltro);
            double soglia = MinRsiDelta;
            double oversold = RsiHigherOversold;
            double overbought = RsiHigherOverbought;

            bool condizioneSegnale = isLong
                ? (rsiBase < oversold && (rsiFiltro - rsiBase) >= soglia)
                : (rsiBase > overbought && (rsiBase - rsiFiltro) >= soglia);

            double cooldownTrascorso = Time.Subtract(isLong ? lastSignalTimeLong : lastSignalTimeShort).TotalMinutes;
            bool inCooldown = cooldownTrascorso < SignalCooldownMinutes;

            double slPips = SignalStopLossPips;
            double tpPips = SignalTakeProfitPips;
            double lots = SignalLotSize;
            long volume = (long)Symbol.QuantityToVolumeInUnits(SignalLotSize);

            Print($"═════════════════════════════════════════════════");
            Print($"🧪 DEBUG SEGNALI RSI {tipo}");
            Print($"► RSI Base:    {rsiBase:F2}");
            Print($"► RSI Filtro:  {rsiFiltro:F2}");
            Print($"► Delta RSI:   {delta:F2} / Min: {soglia:F2}");
            Print($"► Condizione:  {(condizioneSegnale ? "✔️ VALIDA" : "❌ NON valida")}");
            Print($"► Cooldown:    {cooldownTrascorso:F1} min (Richiesto: {SignalCooldownMinutes} min) → {(inCooldown ? "⏳ Bloccato" : "✅ OK")}");
            Print($"► Prezzo:      {prezzo:F5}");
            Print($"═════════════════════════════════════════════════");
        }

        //==========================================================================
        // 🔧 MOSTRA MESSAGGIO ORDINE HUD
        //==========================================================================
        private void MostraMessaggioOrdineHUD(string messaggio, Color colore)
        {
            string label = "ORDER_MSG_" + Time.Ticks;
            double y = Bars.HighPrices.Last(1) + Symbol.PipSize * 20;

            var testo = Chart.DrawText(label, messaggio, Time, y, colore);
            testo.FontSize = 12;
            testo.IsBold = true;

            Print("DEBUG: Messaggio visivo stampato → " + messaggio);
        }

        //==========================================================================
        // 🔧 IS TRADE ALLOWED
        //==========================================================================
        private bool IsTradeAllowed()
        {
            // Se siamo in fase di chiusura forzata
            if (isClosing)
                return false;

            // Se siamo ancora in cooldown dopo una chiusura massiva
            if ((Server.Time - lastForcedCloseTime).TotalSeconds < cooldownAfterCloseSeconds)
            {
                DebugLog($"⏸ Attesa cooldown post-chiusura: {cooldownAfterCloseSeconds}s");
                return false;
            }

            return true;
        }

        //==========================================================================
        // 🔧 GET TRAILING TP THRESHOLD
        //==========================================================================
        private double GetTrailingTPThreshold(double maxProfit)
        {
            if (maxProfit <= 0) return 0;

            double threshold = TPMode switch
            {
                TPMode.Standard => maxProfit * (1 - TPDrawdown / 100.0),
                TPMode.Hybrid => maxProfit * (1 - TPDrawdown / 80.0) + Symbol.PipValue * 5,
                TPMode.Aggressive => maxProfit * (1 - (TPDrawdown / 1.5) / 100.0),
                _ => throw new ArgumentOutOfRangeException(nameof(TPMode), TPMode, "Modalità TP non supportata")
            };

            DebugLog($"[TPD] Calcolo soglia - Modo: {TPMode}");
            DebugLog($"MaxTP: {maxProfit:F2} €");
            DebugLog($"Drawdown: {TPDrawdown}%");
            DebugLog($"Soglia: {threshold:F2} €");

            return Math.Max(0, threshold);
        }

        //==========================================================================
        // 🔧 GENERA SLIDER TP
        //==========================================================================
        private string GeneraSliderTP(double valore, double soglia, int blocchi = 12)
        {
            if (soglia <= 0) return "[N/A]";

            double percentuale = Math.Min(100.0, Math.Max(0.0, (valore / soglia) * 100.0));
            int pieni = (int)(percentuale / (100.0 / blocchi));
            int vuoti = blocchi - pieni;

            string barra = new string('■', pieni) + new string('·', vuoti);
            string stato = percentuale >= 100 ? "✅ Raggiunto" : $"{percentuale:F1}%";

            return $"→ Stato soglia: [{barra}] {stato}";
        }

        //==========================================================================
        // 🔧 VALIDA SEGNALE RSI CON QUALITA'
        //==========================================================================
        private RsiQualitaDiagnostica ValidaSegnaleRSIConQualita(bool isLong)
        {
            var diagnosi = new RsiQualitaDiagnostica();

            try
            {
                // 1. Analisi del segnale di base
                AnalizzaSegnaleBase(isLong, ref diagnosi);

                // Se il segnale base non è valido, uscita anticipata
                if (!diagnosi.SegnaleBaseValido)
                {
                    diagnosi.FiltroPersistenzaSuperato = false;
                    diagnosi.FiltroDeltaCrescenteSuperato = false;
                    diagnosi.FiltroCurvaturaSuperato = false;
                    diagnosi.FiltroEmaSuperato = false;
                    diagnosi.SegnaleFinale = false;
                    return diagnosi;
                }

                // 2. Inizializzazione conteggio filtri per approccio flessibile
                int filtriAttivi = 0;
                int filtriSuperati = 0;

                // 3. Applicazione filtri specifici
                ApplicaFiltroDeltaCrescente(isLong, ref diagnosi, ref filtriAttivi, ref filtriSuperati);
                ApplicaFiltroCurvatura(isLong, ref diagnosi, ref filtriAttivi, ref filtriSuperati);
                ApplicaFiltroEMA(isLong, ref diagnosi, ref filtriAttivi, ref filtriSuperati);
                ApplicaFiltroPersistenza(isLong, ref diagnosi, ref filtriAttivi, ref filtriSuperati);
                ApplicaFiltroBarreConferma(isLong, ref filtriAttivi, ref filtriSuperati, out bool barreConfermaSuperato);

                // 4. Log dettagliati sui filtri applicati
                LogDettagliApplicazioneFiltri(isLong, diagnosi, barreConfermaSuperato, filtriAttivi, filtriSuperati);

                // 5. Determinazione esito finale
                bool filtriQualitaOk = DeterminaRisultatoFiltriQualita(filtriAttivi, filtriSuperati);
                diagnosi.SegnaleFinale = diagnosi.SegnaleBaseValido && filtriQualitaOk &&
                                        (!EnableEmaFilter || diagnosi.FiltroEmaSuperato || !ForceEmaCheck);

                return diagnosi;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in ValidaSegnaleRSIConQualita: {ex.Message}");
                return diagnosi;
            }
        }

        // Metodo 1: Analisi segnale base (calcolo delta e verifica valori RSI)
        private void AnalizzaSegnaleBase(bool isLong, ref RsiQualitaDiagnostica diagnosi)
        {
            double rsiBase = isLong ? rsiBaseValueLong : rsiBaseValueShort;
            double rsiSup = isLong ? rsiSuperiorValueLong : rsiSuperiorValueShort;

            // IMPORTANTE: Calcolo delta sempre nello stesso modo indipendentemente dalla modalità
            double delta;
            if (isLong)
            {
                delta = rsiSuperiorValueLong - rsiBaseValueLong;
            }
            else
            {
                delta = rsiBaseValueShort - rsiSuperiorValueShort;
            }

            diagnosi.Delta = delta;

            bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

            // Logica di validazione diversa in base alla modalità operativa
            if (!isTrendFollowing) // Modalità Contrarian
            {
                // Modalità Contrarian: LONG in ipervenduto (<45), SHORT in ipercomprato (>55)
                if (isLong)
                {
                    // Validità segnale LONG basata sui valori RSI (ipervenduto)
                    diagnosi.SegnaleBaseValido = (rsiBase < RsiBaseOversold) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                }
                else
                {
                    // Validità segnale SHORT basata sui valori RSI (ipercomprato)
                    diagnosi.SegnaleBaseValido = (rsiBase > RsiBaseOverbought) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                }
            }
            else // TrendFollowing
            {
                // Modalità TrendFollowing: LONG in ipercomprato (>55), SHORT in ipervenduto (<45)
                if (isLong)
                {
                    // Validità segnale LONG basata sui valori RSI (ipercomprato)
                    diagnosi.SegnaleBaseValido = (rsiBase > RsiBaseOverbought) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    Print($"🔍 TrendFollowing LONG check: RSI={rsiBase:F2} > {RsiBaseOverbought} (overbought), delta={delta:F2} >= {MinRsiDelta}, valido={diagnosi.SegnaleBaseValido}");
                }
                else
                {
                    // Validità segnale SHORT basata sui valori RSI (ipervenduto)
                    diagnosi.SegnaleBaseValido = (rsiBase < RsiBaseOversold) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    Print($"🔍 TrendFollowing SHORT check: RSI={rsiBase:F2} < {RsiBaseOversold} (oversold), delta={delta:F2} >= {MinRsiDelta}, valido={diagnosi.SegnaleBaseValido}");
                }
            }

            // Se forzatura attiva, bypassa le verifiche
            if (ForzaSegnaleRSI)
            {
                Print($"🧪 [DEBUG] Forzatura RSI attiva per {(isLong ? "LONG" : "SHORT")}");
                diagnosi.SegnaleBaseValido = true;
            }
        }

        // Metodo 2: Applicazione filtro delta crescente
        private void ApplicaFiltroDeltaCrescente(bool isLong, ref RsiQualitaDiagnostica diagnosi, ref int filtriAttivi, ref int filtriSuperati)
        {
            diagnosi.FiltroDeltaCrescenteSuperato = true;
            if (AbilitaFiltroDeltaCrescenteRSI)
            {
                filtriAttivi++;
                var storicoDelta = isLong ? storicoDeltaLong : storicoDeltaShort;
                if (storicoDelta.Count >= 3)
                {
                    var d = storicoDelta.ToList();
                    diagnosi.FiltroDeltaCrescenteSuperato = d[^3] < d[^2] && d[^2] < d[^1];
                }
                if (diagnosi.FiltroDeltaCrescenteSuperato) filtriSuperati++;
            }
        }

        // Metodo 3: Applicazione filtro curvatura RSI
        private void ApplicaFiltroCurvatura(bool isLong, ref RsiQualitaDiagnostica diagnosi, ref int filtriAttivi, ref int filtriSuperati)
        {
            diagnosi.FiltroCurvaturaSuperato = true;
            if (AbilitaFiltroCurvaturaRSIBase)
            {
                filtriAttivi++;
                var storicoRSI = isLong ? storicoRsiBaseLong : storicoRsiBaseShort;
                if (storicoRSI.Count >= 3)
                {
                    var r = storicoRSI.ToList();
                    bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

                    // Adatta il filtro di curvatura in base alla modalità e direzione
                    if (isTrendFollowing)
                    {
                        // In TrendFollowing: per LONG vogliamo RSI in salita, per SHORT in discesa
                        diagnosi.FiltroCurvaturaSuperato = isLong
                            ? r[^3] < r[^2] && r[^2] < r[^1]  // LONG: RSI in salita
                            : r[^3] > r[^2] && r[^2] > r[^1]; // SHORT: RSI in discesa
                    }
                    else
                    {
                        // In Contrarian: per LONG vogliamo RSI in discesa verso ipervenduto, per SHORT in salita verso ipercomprato
                        diagnosi.FiltroCurvaturaSuperato = isLong
                            ? r[^3] > r[^2] && r[^2] > r[^1]  // LONG: RSI in discesa
                            : r[^3] < r[^2] && r[^2] < r[^1]; // SHORT: RSI in salita
                    }
                }
                if (diagnosi.FiltroCurvaturaSuperato) filtriSuperati++;
            }
        }

        // Metodo 4: Applicazione filtro EMA
        private void ApplicaFiltroEMA(bool isLong, ref RsiQualitaDiagnostica diagnosi, ref int filtriAttivi, ref int filtriSuperati)
        {
            diagnosi.FiltroEmaSuperato = true;
            if (EnableEmaFilter)
            {
                filtriAttivi++;
                diagnosi.FiltroEmaSuperato = IsEmaFilterPassed(isLong);
                FiltroEmaSuperato = diagnosi.FiltroEmaSuperato; // Per compatibilità
                if (diagnosi.FiltroEmaSuperato) filtriSuperati++;
            }
        }

        // Metodo 5: Applicazione filtro persistenza
        private void ApplicaFiltroPersistenza(bool isLong, ref RsiQualitaDiagnostica diagnosi, ref int filtriAttivi, ref int filtriSuperati)
        {
            diagnosi.FiltroPersistenzaSuperato = true;
            if (AbilitaFiltroConsistenzaRSI && BarrePersistenzaRichieste > 0)
            {
                filtriAttivi++;
                Queue<bool> storicoValidi = isLong ? storicoSegnaleValidoLong : storicoSegnaleValidoShort;
                int consecutiviValidi = 0;

                foreach (var valido in storicoValidi.Reverse())
                {
                    if (!valido) break;
                    consecutiviValidi++;
                }

                diagnosi.FiltroPersistenzaSuperato = consecutiviValidi >= MinBarrePersistenzaSegnale;
                if (diagnosi.FiltroPersistenzaSuperato) filtriSuperati++;
            }
        }

        // Metodo 6: Applicazione filtro barre conferma
        private void ApplicaFiltroBarreConferma(bool isLong, ref int filtriAttivi, ref int filtriSuperati, out bool barreConfermaSuperato)
        {
            barreConfermaSuperato = true;
            if (AbilitaBarreConfermaSegnale && MinBarreConfermaSegnale > 0)
            {
                filtriAttivi++;
                int confermeConsecutive = isLong ? confermaBarreLong : confermaBarreShort;
                barreConfermaSuperato = confermeConsecutive >= MinBarreConfermaSegnale;
                if (barreConfermaSuperato) filtriSuperati++;
            }
        }

        // Metodo 7: Log dettagliati sui filtri applicati
        private void LogDettagliApplicazioneFiltri(bool isLong, RsiQualitaDiagnostica diagnosi, bool barreConfermaSuperato, int filtriAttivi, int filtriSuperati)
        {
            Print($"📊 Filtri RSI {(isLong ? "LONG" : "SHORT")}: {filtriSuperati}/{filtriAttivi} superati");
            Print($"• Delta Crescente: {(AbilitaFiltroDeltaCrescenteRSI ? (diagnosi.FiltroDeltaCrescenteSuperato ? "✅" : "❌") : "◯")}");
            Print($"• Curvatura RSI: {(AbilitaFiltroCurvaturaRSIBase ? (diagnosi.FiltroCurvaturaSuperato ? "✅" : "❌") : "◯")}");
            Print($"• Filtro EMA: {(EnableEmaFilter ? (diagnosi.FiltroEmaSuperato ? "✅" : "❌") : "◯")}");
            Print($"• Persistenza: {(AbilitaFiltroPersistenzaRSI ? (diagnosi.FiltroPersistenzaSuperato ? "✅" : "❌") : "◯")}");
            Print($"• Barre Conferma: {(AbilitaBarreConfermaSegnale ? (barreConfermaSuperato ? "✅" : "❌") : "◯")}");
        }

        // Metodo 8: Determina il risultato finale dei filtri di qualità
        private bool DeterminaRisultatoFiltriQualita(int filtriAttivi, int filtriSuperati)
        {
            // Nessun filtro attivo = OK
            // Oppure, almeno 50% dei filtri devono essere superati
            return filtriAttivi == 0 || ((double)filtriSuperati / filtriAttivi >= 0.5);
        }

        // Metodo per calcolare la pendenza della tendenza
        private double CalcolaPendenzaTendenza(List<double> valori)
        {
            // Se abbiamo meno di 2 valori, non possiamo calcolare una pendenza
            if (valori.Count < 2)
                return 0;

            // Regressione lineare semplificata
            int n = valori.Count;
            double sumX = 0;
            double sumY = 0;
            double sumXY = 0;
            double sumXX = 0;

            // Utilizziamo indici come X (0, 1, 2, ...) e i valori RSI come Y
            for (int i = 0; i < n; i++)
            {
                double x = i;
                double y = valori[i];

                sumX += x;
                sumY += y;
                sumXY += x * y;
                sumXX += x * x;
            }

            // Calcolo pendenza: m = (n*∑xy - ∑x*∑y) / (n*∑x² - (∑x)²)
            double denominatore = n * sumXX - sumX * sumX;

            // Proteggiamo contro divisione per zero
            if (Math.Abs(denominatore) < 1e-10)
                return 0;

            double pendenza = (n * sumXY - sumX * sumY) / denominatore;
            return pendenza;
        }

        // Classe per rappresentare uno swing point (picco o valle nell'RSI)
        private class SwingPoint
        {
            public double Value { get; set; }       // Valore RSI
            public int Index { get; set; }          // Posizione nella serie
            public bool IsPeak { get; set; }        // true = picco, false = valle
            public DateTime Time { get; set; }      // Timestamp
        }

        // Classe per i risultati dell'analisi swing
        private class SwingAnalisiRisultato
        {
            public bool SwingValido { get; set; }           // Risultato finale del filtro
            public bool DirezioneTrendCorretta { get; set; } // La direzione del trend è coerente con l'operazione?
            public double ForzaTendenza { get; set; }        // Forza del trend (0-5)
            public double RegolaritaSwing { get; set; }      // Quanto sono regolari gli swing (0-1)
            public string DescrizioneTrend { get; set; }     // Descrizione testuale del trend
        }

        // Metodo per rilevare gli swing points significativi nell'RSI
        private List<SwingPoint> RilevaSwingPoints(List<double> valoriRSI)
        {
            List<SwingPoint> swingPoints = new List<SwingPoint>();

            // Parametro di sensibilità: quanto deve essere significativo un pivot per essere considerato
            double sensibilita = 2.0; // Differenza minima in punti RSI per considerare uno swing

            // Finestra di analisi per determinare picchi e valli locali
            int finestra = 2; // Considera X valori prima e dopo per determinare un pivot

            // Inizia da finestra+1 e termina a lunghezza-finestra-1 per avere abbastanza valori intorno
            for (int i = finestra; i < valoriRSI.Count - finestra; i++)
            {
                double valoreCorrente = valoriRSI[i];
                bool isPeak = true;
                bool isValley = true;

                // Verifica se è un picco locale
                for (int j = i - finestra; j <= i + finestra; j++)
                {
                    if (j == i) continue; // Salta il confronto con se stesso

                    if (valoriRSI[j] >= valoreCorrente)
                        isPeak = false;

                    if (valoriRSI[j] <= valoreCorrente)
                        isValley = false;
                }

                // Aggiungi swing point se è un picco o una valle significativa
                if (isPeak || isValley)
                {
                    // Verifica che ci sia una differenza significativa con lo swing precedente
                    bool significativo = true;

                    if (swingPoints.Count > 0)
                    {
                        var ultimoSwing = swingPoints[swingPoints.Count - 1];
                        double differenza = Math.Abs(valoreCorrente - ultimoSwing.Value);

                        // Lo swing deve essere nella direzione opposta e di ampiezza significativa
                        significativo = (isPeak != ultimoSwing.IsPeak) && differenza >= sensibilita;
                    }

                    if (significativo)
                    {
                        swingPoints.Add(new SwingPoint
                        {
                            Value = valoreCorrente,
                            Index = i,
                            IsPeak = isPeak,
                            Time = DateTime.Now // Idealmente qui andrebbe il timestamp reale dalla serie
                        });
                    }
                }
            }

            return swingPoints;
        }

        // Metodo per analizzare gli swing points e determinare la validità del filtro
        private SwingAnalisiRisultato AnalizzaSwingRSI(List<SwingPoint> swingPoints, bool isLong)
        {
            var risultato = new SwingAnalisiRisultato
            {
                SwingValido = false,
                DescrizioneTrend = "Indeterminato"
            };

            // Se non ci sono abbastanza punti, termina subito
            if (swingPoints.Count < 3)
                return risultato;

            // Estrai gli ultimi 4 swing points (o meno se non disponibili)
            var swingRecenti = swingPoints.Skip(Math.Max(0, swingPoints.Count - 4)).ToList();

            // 1. TREND DETECTION: Analizziamo i picchi e le valli
            List<double> picchi = swingRecenti.Where(s => s.IsPeak).Select(s => s.Value).ToList();
            List<double> valli = swingRecenti.Where(s => !s.IsPeak).Select(s => s.Value).ToList();

            // Logica di trend dei picchi/valli
            bool picchiCrescenti = picchi.Count >= 2 && IsCrescente(picchi);
            bool picchiDecrescenti = picchi.Count >= 2 && IsDecrescente(picchi);
            bool valliCrescenti = valli.Count >= 2 && IsCrescente(valli);
            bool valliDecrescenti = valli.Count >= 2 && IsDecrescente(valli);

            // 2. DETERMINAZIONE GENERALE DEL TREND
            bool trendRialzista = (picchiCrescenti && valliCrescenti) ||
                                  (picchiCrescenti && valli.Count < 2) ||
                                  (valliCrescenti && picchi.Count < 2);

            bool trendRibassista = (picchiDecrescenti && valliDecrescenti) ||
                                   (picchiDecrescenti && valli.Count < 2) ||
                                   (valliDecrescenti && picchi.Count < 2);

            // Trend misto - usiamo l'ultimo swing per decidere la direzione
            bool trendMisto = !trendRialzista && !trendRibassista;
            bool ultimoSwingVersoAlto = false;

            if (trendMisto && swingRecenti.Count >= 2)
            {
                var ultimoSwing = swingRecenti[swingRecenti.Count - 1];
                var penultimoSwing = swingRecenti[swingRecenti.Count - 2];
                ultimoSwingVersoAlto = ultimoSwing.Value > penultimoSwing.Value;
            }

            // 3. CALCOLO FORZA TENDENZA
            double forzaTendenza = 0.0;

            // Calcola l'ampiezza media degli swing
            double ampMedia = 0.0;
            if (swingRecenti.Count >= 2)
            {
                double sommaAmp = 0.0;
                for (int i = 1; i < swingRecenti.Count; i++)
                {
                    sommaAmp += Math.Abs(swingRecenti[i].Value - swingRecenti[i - 1].Value);
                }
                ampMedia = sommaAmp / (swingRecenti.Count - 1);

                // Normalizza in una scala 0-5
                forzaTendenza = Math.Min(5.0, ampMedia / 3.0);
            }

            // 4. CALCOLO REGOLARITÀ DEGLI SWING
            double regolaritaSwing = 1.0; // Valore predefinito di alta regolarità

            if (swingRecenti.Count >= 3)
            {
                List<double> ampiezze = new List<double>();
                for (int i = 1; i < swingRecenti.Count; i++)
                {
                    ampiezze.Add(Math.Abs(swingRecenti[i].Value - swingRecenti[i - 1].Value));
                }

                // Calcoliamo la deviazione standard delle ampiezze
                double media = ampiezze.Average();
                double varianza = ampiezze.Select(a => Math.Pow(a - media, 2)).Average();
                double devStd = Math.Sqrt(varianza);

                // Coefficiente di variazione (normalizzato tra 0-1, dove 1 è perfetta regolarità)
                regolaritaSwing = Math.Max(0.0, 1.0 - (devStd / media));
            }

            // 5. DETERMINAZIONE RISULTATO FINALE
            bool direzioneTrendCorretta = false;
            string descrizioneTrend = "Laterale";

            if (trendRialzista)
            {
                descrizioneTrend = "Rialzista ↗";
                direzioneTrendCorretta = isLong; // Per LONG vogliamo un trend rialzista
            }
            else if (trendRibassista)
            {
                descrizioneTrend = "Ribassista ↘";
                direzioneTrendCorretta = !isLong; // Per SHORT vogliamo un trend ribassista
            }
            else if (trendMisto)
            {
                descrizioneTrend = ultimoSwingVersoAlto ? "Misto (ultimo ↗)" : "Misto (ultimo ↘)";
                direzioneTrendCorretta = ultimoSwingVersoAlto == isLong;
            }

            // Forza tendenza minima richiesta (personalizzabile)
            double sogliaTendenzaMinima = 1.0;

            // Soglia di regolarità minima (personalizzabile)
            double sogliaRegolaritaMinima = 0.3;

            // Criterio di validità finale
            bool swingValido = direzioneTrendCorretta &&
                              forzaTendenza >= sogliaTendenzaMinima &&
                              regolaritaSwing >= sogliaRegolaritaMinima;

            // Popola e restituisci il risultato
            risultato.SwingValido = swingValido;
            risultato.DirezioneTrendCorretta = direzioneTrendCorretta;
            risultato.ForzaTendenza = forzaTendenza;
            risultato.RegolaritaSwing = regolaritaSwing;
            risultato.DescrizioneTrend = descrizioneTrend;

            return risultato;
        }

        // Metodi helper per verificare se una sequenza è crescente o decrescente
        private bool IsCrescente(List<double> valori)
        {
            if (valori.Count <= 1) return false;

            for (int i = 1; i < valori.Count; i++)
            {
                if (valori[i] < valori[i - 1]) return false;
            }

            // Verifica che ci sia un incremento significativo
            return (valori[valori.Count - 1] - valori[0]) > 2.0;
        }

        private bool IsDecrescente(List<double> valori)
        {
            if (valori.Count <= 1) return false;

            for (int i = 1; i < valori.Count; i++)
            {
                if (valori[i] > valori[i - 1]) return false;
            }

            // Verifica che ci sia un decremento significativo
            return (valori[0] - valori[valori.Count - 1]) > 2.0;
        }

        //==========================================================================
        // 🔧 VALIDA SEGNALE RSI CON QUALITA' - READ ONLY
        //==========================================================================
        private RsiQualitaDiagnostica ValidaSegnaleRSIConQualita_ReadOnly(bool isLong)
        {
            var diagnosi = new RsiQualitaDiagnostica();

            try
            {
                double rsiBase = isLong ? rsiBaseValueLong : rsiBaseValueShort;
                double rsiSup = isLong ? rsiSuperiorValueLong : rsiSuperiorValueShort;
                double delta;

                // IMPORTANTE: Calcolo delta sempre nello stesso modo indipendentemente dalla modalità
                if (isLong)
                {
                    delta = rsiSuperiorValueLong - rsiBaseValueLong;
                }
                else
                {
                    delta = rsiBaseValueShort - rsiSuperiorValueShort;
                }

                diagnosi.Delta = delta;

                // Logica di validazione diversa in base alla modalità operativa
                bool isTrendFollowing = ModalitaRSI == ModalitaOperativaRSI.TrendFollowing;

                if (!isTrendFollowing) // Modalità Contrarian
                {
                    // Modalità Contrarian: LONG in ipervenduto (<45), SHORT in ipercomprato (>55)
                    if (isLong)
                    {
                        diagnosi.SegnaleBaseValido = (rsiBase < RsiBaseOversold) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    }
                    else
                    {
                        diagnosi.SegnaleBaseValido = (rsiBase > RsiBaseOverbought) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    }
                }
                else // TrendFollowing
                {
                    // Modalità TrendFollowing: LONG in ipercomprato (>55), SHORT in ipervenduto (<45)
                    if (isLong)
                    {
                        diagnosi.SegnaleBaseValido = (rsiBase > RsiBaseOverbought) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    }
                    else
                    {
                        diagnosi.SegnaleBaseValido = (rsiBase < RsiBaseOversold) && (AbilitaFiltroMinDeltaRSI ? delta >= MinRsiDelta : true);
                    }
                }

                // Il resto rimane invariato rispetto alla versione originale...
                diagnosi.FiltroCurvaturaSuperato = true;
                diagnosi.FiltroDeltaCrescenteSuperato = true;
                diagnosi.FiltroPersistenzaSuperato = true;
                diagnosi.FiltroEmaSuperato = true;

                // Impostare il segnale finale in base al segnale base
                diagnosi.SegnaleFinale = diagnosi.SegnaleBaseValido;

                return diagnosi;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore in ValidaSegnaleRSIConQualita_ReadOnly: {ex.Message}");
                return diagnosi;
            }
        }

        //==========================================================================
        // 🔧 GENERA STATO FILTRI RSI
        //==========================================================================
        private string GeneraStatoFiltriRSI(RsiQualitaDiagnostica d, bool isLong)
        {
            var sb = new StringBuilder();

            if (AbilitaFiltroPersistenzaRSI)
            {
                int count = isLong ? consecutiveValidLong : consecutiveValidShort;
                sb.Append($"Persistenza: {(d.FiltroPersistenzaSuperato ? "✔" : "✖")} ({count}/{MinBarrePersistenzaSegnale}), ");
            }

            if (AbilitaFiltroDeltaCrescenteRSI)
                sb.Append($"Delta crescente: {(d.FiltroDeltaCrescenteSuperato ? "✔" : "✖")}, ");

            if (AbilitaFiltroCurvaturaRSIBase)
                sb.Append($"Curvatura: {(d.FiltroCurvaturaSuperato ? "✔" : "✖")}, ");

            if (sb.Length > 0)
                sb.Length -= 2;

            return sb.ToString();
        }

        //==========================================================================
        // 🔧 GENERA STRINGA QUALITA' DEGNALE
        //==========================================================================
        private string GeneraStringaQualitaSegnale(bool isLong, double rsiBase, double rsiSup, double delta, RsiQualitaDiagnostica diagnosi)
        {
            var sb = new StringBuilder();
            sb.AppendLine(isLong ? "📈 Segnale LONG" : "📉 Segnale SHORT");
            sb.AppendLine($"Base: {rsiBase:F2} | Sup: {rsiSup:F2} | Δ: {delta:F2}");
            sb.AppendLine($"Valido: {(diagnosi.SegnaleFinale ? "✔" : "✖")}");

            if (AbilitaFiltroPersistenzaRSI)
                sb.AppendLine($"{(diagnosi.FiltroPersistenzaSuperato ? "✔" : "✖")} Persistenza richiesta: {MinBarrePersistenzaSegnale} barre");

            if (AbilitaFiltroDeltaCrescenteRSI)
                sb.AppendLine($"{(diagnosi.FiltroDeltaCrescenteSuperato ? "✔" : "✖")} Delta crescente richiesto");

            if (AbilitaFiltroCurvaturaRSIBase)
                sb.AppendLine($"{(diagnosi.FiltroCurvaturaSuperato ? "✔" : "✖")} Inversione RSI base richiesta");

            if (EnableEmaFilter)
            {
                var (isPriceAboveEma, recommendation, _) = CheckPriceAgainstEMA();
                sb.AppendLine($"{(diagnosi.FiltroEmaSuperato ? "✔" : "✖")} {recommendation}");
            }

            return sb.ToString();
        }

        //==========================================================================
        // 🔧 GET MINIMUM ALLOWED LOTS
        //==========================================================================
        private double GetMinimumAllowedLots()
        {
            try
            {
                Print($"\n=== ANALISI VOLUME MINIMO SIMBOLO {Symbol.Name} ===");

                // 1. Prima otteniamo i valori dal broker
                var minUnits = Symbol.VolumeInUnitsMin;
                var stepUnits = Symbol.VolumeInUnitsStep;

                Print($"Volume minimo broker (unità): {minUnits}");
                Print($"Step volume broker (unità): {stepUnits}");

                // 2. Array dei lotti standard del broker
                double[] standardLots = { 0.01, 0.1, 1.0, 10.0, 50.0 };

                // 3. Conversione sicura in lotti usando VolumeToQuantity
                double minLots = Symbol.VolumeInUnitsToQuantity(minUnits > 0 ? minUnits : stepUnits);

                Print($"Volume minimo convertito: {minLots:F2} lots");

                // 4. Troviamo il primo valore standard maggiore o uguale
                double adjustedLots = standardLots.FirstOrDefault(x => x >= minLots);

                // Se non troviamo un valore standard, usiamo il minimo convertito
                if (adjustedLots == 0)
                {
                    adjustedLots = minLots > 0 ? minLots : 0.01;
                    Print($"Nessun valore standard trovato, uso minimo convertito: {adjustedLots:F2}");
                }

                Print($"Volume minimo finale: {adjustedLots:F2} lots");

                // 5. Log dettagliato finale
                Print($"\n=== RIEPILOGO VOLUME ===");
                Print($"• Minimo broker (units): {minUnits}");
                Print($"• Step broker (units): {stepUnits}");
                Print($"• Minimo convertito: {minLots:F2} lots");
                Print($"• Volume finale: {adjustedLots:F2} lots");

                return adjustedLots;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore calcolo volume minimo: {ex.Message}");
                return 1.0; // Fallback sicuro - usiamo 1.0 come valore conservativo
            }
        }

        //==========================================================================
        // 🔧 NORMALIZE LOTS
        //==========================================================================
        private double NormalizeLots(double lots)
        {
            try
            {
                Print($"\n=== NORMALIZE LOTS ===");
                Print($"Input lots: {lots}");

                // 1. Ottieni minimo consentito
                double minLots = GetMinimumAllowedLots();

                // 2. Verifica volume minimo
                if (lots < minLots)
                {
                    Print($"Volume {lots:F2} inferiore al minimo {minLots:F2} → normalizzato");
                    return minLots;
                }

                // 3. Normalizza in base allo step
                var stepUnits = Symbol.VolumeInUnitsStep;
                double stepLots = Symbol.VolumeInUnitsToQuantity(stepUnits);

                Print($"Step volume: {stepLots:F2} lots");

                // 4. Arrotonda al multiplo dello step
                double normalized = Math.Floor(lots / stepLots) * stepLots;
                normalized = Math.Max(minLots, normalized);

                Print($"Volume normalizzato: {lots:F2} → {normalized:F2} lots");

                return normalized;
            }
            catch (Exception ex)
            {
                Print($"❌ Errore normalizzazione volume: {ex.Message}");
                return GetMinimumAllowedLots(); // Fallback al minimo sicuro
            }
        }

        //==========================================================================
        // 🔧 GET DISTANCE FROM ENTRY
        //==========================================================================
        private double GetDistanceFromEntry()
        {
            var firstPos = Positions.Where(p => p.SymbolName == SymbolName)
                                  .OrderBy(p => p.EntryTime)
                                  .FirstOrDefault();

            if (firstPos == null) return 0;

            return Math.Abs(Symbol.Bid - firstPos.EntryPrice) / Symbol.PipSize;
        }

        //==========================================================================
        // 🔧 UPDATE TP STATUS HUD
        //==========================================================================
        private void UpdateTPStatusHUD(double netProfit, double effectiveTPStart)
        {
            if (effectiveTPStart <= 0) return;

            StringBuilder sb = new StringBuilder();
            string mode = EnableTrailingTP ? "Dinamico" : "Fisso";
            double progress = (netProfit / effectiveTPStart) * 100;

            if (EnableTrailingTP)
            {
                if (!tpDinamicoAttivato)
                {
                    double distance = GetDistanceFromEntry();
                    sb.AppendLine($"🎯 TP Dinamico: In attesa ({distance:F1}/{MinActivationPips} pips)");
                    sb.AppendLine($"Target: {effectiveTPStart:F2} € | Attuale: {netProfit:F2} € ({progress:F1}%)");
                }
                else
                {
                    double threshold = GetTrailingTPThreshold(maxTP);
                    sb.AppendLine($"✅ TP Dinamico attivo");
                    sb.AppendLine($"Max: {maxTP:F2} € | Soglia: {threshold:F2} €");
                    sb.AppendLine($"Attuale: {netProfit:F2} €");
                }
            }
            trailingTPWarningHUD = sb.ToString();
        }

        //==========================================================================
        // 🔧 UPDATE TP STATUS HUD WITH MIN PROFIT
        //==========================================================================
        // Modifica il metodo UpdateTPStatusHUDWithMinProfit:
        private void UpdateTPStatusHUDWithMinProfit(double currentProfit, double targetTP, double minProfitRequired)
        {
            if (targetTP <= 0) return;

            StringBuilder sb = new StringBuilder();

            // === SEZIONE DISTANZA MINIMA ===
            if (EnableTrailingTP)
            {
                // === AGGIUNGI INFO TSL SE ATTIVO ===
                if (EnableRecoveryTrailingStopLoss && trailingStopLossAttivo)
                {
                    sb.AppendLine($"• TRAILING STOPLOSS PER RECOVERY ({Symbol.Name}):");
                    sb.AppendLine($"  ✅ ATTIVO - Max: {lastTrailingStopLossPrice:F2} €");
                    double slValue = lastTrailingStopLossPrice * (1 - RecoveryTrailingStopLossDistancePercent / 100.0);
                    sb.AppendLine($"  ➤ Stop: {slValue:F2} € | DD: {RecoveryTrailingStopLossDistancePercent}%");
                    sb.AppendLine($"  ➤ Chiusura futura prevista a: {slValue:F2} €");

                    var firstPos = Positions.Where(p => p.SymbolName == SymbolName)
                                          .OrderBy(p => p.EntryTime)
                                          .FirstOrDefault();
                    if (firstPos != null)
                    {
                        double distance = Math.Abs(Symbol.Bid - firstPos.EntryPrice) / Symbol.PipSize;
                        sb.AppendLine($"Distanza minima: {distance:F1} pips / Richiesta {MinActivationPips} pips " +
                                     (distance >= MinActivationPips ? "✅" : "⏳"));
                    }
                }
            }

            // === SEZIONE MINPROFIT ===
            if (EnableMinProfitCheck)
            {
                // Calcoliamo il corretto minProfitRequired basato solo sul margine del simbolo corrente
                double symbolMargin = GetSymbolMargin(SymbolName);
                double correctMinProfitRequired = symbolMargin * (1 + MinProfitOverMarginPercent / 100.0);

                bool minProfitOK = currentProfit >= correctMinProfitRequired;
                string status = minProfitOK ? "✅" : "⏳";
                sb.AppendLine($"Min Profit: {correctMinProfitRequired:F2} € {status} (solo {SymbolName})");
            }

            trailingTPWarningHUD = sb.ToString();
        }

        //==========================================================================
        // 🔧 IS CLOSING ALLOWED
        //==========================================================================
        private bool IsClosingAllowed(double netProfit)
        {
            if (!EnableTrailingTP) return true;
            if (!tpDinamicoAttivato) return false;

            double threshold = GetTrailingTPThreshold(maxTP);
            return netProfit <= threshold && netProfit > 0;
        }

        //==========================================================================
        // 🔧 CLOSE POSITIONS FOR TP DYNAMIC
        //==========================================================================
        private void ClosePositionsForTPDynamic(List<Position> positions, double threshold)
        {
            try
            {
                DebugLog($"🔄 Inizio chiusura TP Dinamico...");

                foreach (var pos in positions)
                {
                    var result = pos.Close();
                    if (result.IsSuccessful)
                        Print($"✅ Chiusa posizione {pos.Id}: {pos.NetProfit:F2} €");
                    else
                        Print($"❌ Errore chiusura {pos.Id}: {result.Error}");
                }

                lastTrailingUpdateTime = Server.Time;
                ResetTPDynamicValues();
                Print($"✅ Chiusura TP Dinamico completata");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore durante chiusura TP Dinamico: {ex.Message}");
            }
        }

        //==========================================================================
        // 🔧 CALCULATE DYNAMIC TP COOLDOWN
        //==========================================================================
        private CooldownInfo CalculateDynamicCooldown(List<Position> positions, double baseDistance)
        {
            var info = new CooldownInfo();

            // Se non ci sono posizioni o il cooldown non è attivo
            if (!positions.Any() || !recoveryCooldownActive)
            {
                info.RequiredPips = baseDistance;
                info.IsActive = false;
                info.Status = "Non attivo";
                return info;
            }

            // Calcola il volume totale in lotti
            double totalVolume = 0;
            foreach (var pos in positions)
            {
                double posVolume = Symbol.VolumeInUnitsToQuantity(pos.VolumeInUnits);
                totalVolume += posVolume;
            }

            // Ottieni l'ultima posizione per il calcolo della distanza dinamica
            var lastPos = positions.OrderByDescending(p => p.EntryTime).FirstOrDefault();
            double nextLots = totalVolume * RecoveryMultiplier;

            // Usa il calcolo dinamico della distanza con lo stesso metodo
            double dynamicDistance = CalculateDynamicDistanceFilter(baseDistance, lastPos, nextLots);
            info.RequiredPips = dynamicDistance;

            // Calcola distanza attuale dall'ultimo recovery
            info.CurrentDistance = Math.Abs(Symbol.Bid - lastRecoveryPrice) / Symbol.PipSize;

            // Determina se il cooldown è ancora attivo
            info.IsActive = info.CurrentDistance < info.RequiredPips;

            // Genera messaggio di stato
            double volumeMultiplier = nextLots / (Symbol.VolumeInUnitsToQuantity(lastPos.VolumeInUnits));
            info.VolumeMultiplier = volumeMultiplier;

            info.Status = info.IsActive
                ? $"⏳ Attivo: {info.CurrentDistance:F1}/{info.RequiredPips:F1} pips (×{volumeMultiplier:F2})"
                : "✅ Completato";

            return info;
        }

        //==========================================================================
        // 🔧 IS COOLDOWN ACTIVE
        //==========================================================================
        private bool IsCooldownActive(List<Position> positions)
        {
            if (!EnableDistanceFilter || !EnableDynamicCooldown)
                return false;

            var cooldown = CalculateDynamicCooldown(positions, RecoveryCooldownPips);
            return cooldown.IsActive;
        }

        //==========================================================================
        // 🔧 GET COOLDOWN STATUS
        //==========================================================================
        private (bool IsActive, string Status, double Progress) GetCooldownStatus()
        {
            if (!EnableDistanceFilter || !EnableDynamicCooldown || !recoveryCooldownActive)
                return (false, "Non attivo", 0);

            var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            var cooldown = CalculateDynamicCooldown(positions, RecoveryCooldownPips);

            double progress = cooldown.IsActive
                ? (cooldown.CurrentDistance / cooldown.RequiredPips) * 100
                : 100;

            return (cooldown.IsActive, cooldown.Status, progress);
        }

        //==========================================================================
        // 🔧 DRAW TP DYNAMIC LINE SAFE
        //==========================================================================
        // Nuovo metodo per disegnare la linea del TP Dinamico
        // Metodo corretto per disegnare la linea del TP Dinamico
        private void DrawTPDynamicLineSafe(List<Position> positions, double targetProfit)
        {
            if (!positions.Any()) return;

            var firstPos = positions.OrderBy(p => p.EntryTime).FirstOrDefault();
            if (firstPos == null) return;

            try
            {
                // Aggiungiamo un controllo esplicito sul TP dinamico attivato
                bool shouldDraw = tpDinamicoAttivato || (maxTP >= CalculateEffectiveTPStart());
                if (!shouldDraw)
                {
                    Print("🎯 [TPD] TP Dinamico non ancora attivato o target non raggiunto, rimozione oggetti");
                    Chart.RemoveObject(TP_DYNAMIC_LINE);
                    Chart.RemoveObject(TP_DYNAMIC_LABEL);
                    return;
                }

                // CALCOLO CORRETTO: utilizzo dei prezzi reali delle posizioni
                double totalVolume = positions.Sum(p => p.Quantity);
                double weightedPrice = 0;

                // Calcoliamo un prezzo medio ponderato per posizione
                foreach (var pos in positions)
                {
                    weightedPrice += (pos.EntryPrice * pos.Quantity) / totalVolume;
                }

                // Determinazione della direzione predominante
                bool isBuyPredominant = positions.Where(p => p.TradeType == TradeType.Buy)
                                                .Sum(p => p.Quantity) >=
                                       positions.Where(p => p.TradeType == TradeType.Sell)
                                                .Sum(p => p.Quantity);

                // Calcolo del target price basato sulla direzione e profitto
                double tpPrice;

                // Per il calcolo del prezzo target utilizziamo un offset basato sulla percentuale DD
                // Prezzo medio + offset nella direzione corretta
                if (isBuyPredominant)
                {
                    // Per posizioni long, aggiungiamo l'offset al prezzo medio
                    tpPrice = weightedPrice + (targetProfit / (totalVolume * Symbol.PipValue)) * Symbol.PipSize;
                }
                else
                {
                    // Per posizioni short, sottraiamo l'offset dal prezzo medio
                    tpPrice = weightedPrice - (targetProfit / (totalVolume * Symbol.PipValue)) * Symbol.PipSize;
                }

                // CORREZIONE IMPORTANTE: formattazione con il numero corretto di decimali dal broker
                int symbolDigits = Symbol.Digits;
                tpPrice = Math.Round(tpPrice, symbolDigits);

                Print($"🎯 [TPD] Calcolo TP Dinamico COMPLETO:");
                Print($"• Prezzo medio ponderato: {weightedPrice.ToString($"F{symbolDigits}")}");
                Print($"• Direzione prevalente: {(isBuyPredominant ? "BUY" : "SELL")}");
                Print($"• Target VISIVO: {tpPrice.ToString($"F{symbolDigits}")} | Profit: {targetProfit:F2} €");
                Print($"• Attivo: {tpDinamicoAttivato} | MaxTP: {maxTP:F2} €");
                Print($"• Decimali simbolo: {symbolDigits}");

                // Rimuovi oggetti esistenti
                Chart.RemoveObject(TP_DYNAMIC_LINE);
                Chart.RemoveObject(TP_DYNAMIC_LABEL);

                // Disegna linea orizzontale specificando il prezzo esatto
                Chart.DrawHorizontalLine(TP_DYNAMIC_LINE, tpPrice, Color.DodgerBlue, 2, LineStyle.Dots);

                // Calcola distanza attuale dal prezzo target in pips
                double currentDistance = Math.Abs(Symbol.Bid - tpPrice) / Symbol.PipSize;

                // Prepara testo dell'etichetta con informazioni complete
                string labelText = $"🎯 TP DINAMICO\n" +
                                  $"• Prezzo: {tpPrice.ToString($"F{symbolDigits}")}" +
                                  $" • Target: {targetProfit:F2} €\n" +
                                  $"• Distanza attuale: {currentDistance:F1} pips" +
                                  $" • DD Max: {TPDrawdown}%";

                // PUNTO CRITICO: posizionamento etichetta ESATTAMENTE alla coordinata Y del prezzo
                var label = Chart.DrawText(
                    TP_DYNAMIC_LABEL,
                    labelText,
                    Server.Time,
                    tpPrice,  // Coordinata Y identica alla linea
                    Color.DodgerBlue
                );

                // Imposta proprietà dell'etichetta
                label.FontSize = 10;
                label.IsBold = false;

                Print($"✅ [TPD] Linea e etichetta TP Dinamico disegnate a {tpPrice.ToString($"F{symbolDigits}")}");
            }
            catch (Exception ex)
            {
                Print($"❌ Errore disegno TP Dinamico: {ex.Message}");
                Print($"Stack: {ex.StackTrace}");
            }
        }

        private double CalculateDynamicDistanceFilter(double baseDistance, Position lastPosition, double nextLots)
        {
            // Per la prima posizione di recovery, usa il valore base
            if (recoveryCount == 0 || lastPosition == null || baseDistance <= 0)
            {
                Print($"• Prima posizione recovery o parametri non validi → uso distanza base: {baseDistance:F1} pips");
                return baseDistance;
            }

            // Calcola il volume totale delle posizioni aperte
            var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            double totalOpenLots = positions.Sum(p => Symbol.VolumeInUnitsToQuantity(p.VolumeInUnits));

            Print($"• Volume totale posizioni aperte: {totalOpenLots:F4} lots");

            // Calcola il rapporto tra nuovo volume e volume precedente
            double previousLots = Symbol.VolumeInUnitsToQuantity(lastPosition.VolumeInUnits);
            if (previousLots < 0.001) // Protezione valori troppo piccoli
            {
                Print($"• Volume precedente troppo piccolo ({previousLots:F6}) → uso distanza base: {baseDistance:F1} pips");
                return baseDistance;
            }

            double lotRatio = nextLots / previousLots;

            // Cap sul ratio per sicurezza
            double maxSafeRatio = 10.0;
            if (lotRatio > maxSafeRatio)
            {
                Print($"⚠️ Ratio volumi eccessivo ({lotRatio:F2}) → limitato a {maxSafeRatio:F1}x");
                lotRatio = maxSafeRatio;
            }

            // Calcola il moltiplicatore di distanza in base al tipo selezionato
            double distanceMultiplier = DDCalcType switch
            {
                DDCalculationType.Conservativo => Math.Sqrt(lotRatio),       // Radice quadrata (più conservativo)
                DDCalculationType.Enhanced => Math.Pow(lotRatio, 1.0 / 3.0), // Radice cubica (medio)
                DDCalculationType.Aggressive => lotRatio,                // Lineare 1:1 (più aggressivo)
                _ => Math.Sqrt(lotRatio)
            };

            // Limita il moltiplicatore finale a un valore massimo ragionevole
            double maxMultiplier = 5.0;
            if (distanceMultiplier > maxMultiplier)
            {
                Print($"⚠️ Moltiplicatore distanza eccessivo ({distanceMultiplier:F2}) → limitato a {maxMultiplier:F1}x");
                distanceMultiplier = maxMultiplier;
            }

            // Nuovo fattore di scaling basato sul volume totale
            // Formula logaritmica: cresce rapidamente all'inizio ma poi rallenta con volumi maggiori
            double volumeScalingFactor = 1.0 + Math.Log10(1.0 + totalOpenLots);
            Print($"• Fattore scaling volume totale: {volumeScalingFactor:F2}x");

            // Calcola la distanza finale applicando entrambi i moltiplicatori
            double dynamicDistance = baseDistance * distanceMultiplier * volumeScalingFactor;

            Print($"• Volumi: precedente={previousLots:F4}, nuovo={nextLots:F4}, ratio={lotRatio:F2}x, totale={totalOpenLots:F4}");
            Print($"• Calcolo distanza dinamica: base={baseDistance:F1} × ratio_factor={distanceMultiplier:F2} × volume_factor={volumeScalingFactor:F2} = {dynamicDistance:F1} pips");

            return dynamicDistance;
        }

        private bool CheckMinDistanceFromBE(List<Position> positions, double calculatedLots)
        {
            if (!EnableDistanceFilter || positions.Count == 0)
                return true;

            var lastPos = positions.OrderByDescending(p => p.EntryTime).FirstOrDefault();
            if (lastPos == null)
                return true;

            // Calcola la distanza minima dinamica dal BE
            double dynamicBEDistance = CalculateDynamicDistanceFilter(MinDistanceBEpips, lastPos, calculatedLots);

            // Calcola prezzo BE
            double breakEvenPrice = GetBreakEvenPrice(positions);

            // Calcola distanza attuale
            double currentDistance = Math.Abs(Symbol.Bid - breakEvenPrice) / Symbol.PipSize;

            Print($"• Distanza dal BreakEven: {currentDistance:F1} pips");
            Print($"• Distanza minima dinamica dal BE: {dynamicBEDistance:F1} pips (Base: {MinDistanceBEpips:F1})");

            return currentDistance >= dynamicBEDistance;
        }

        private string GetDynamicDistancesDebugInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("\n=== DISTANZE DINAMICHE ===");

            var positions = Positions.Where(p => p.SymbolName == SymbolName).ToList();
            if (positions.Count == 0)
            {
                sb.AppendLine("• Nessuna posizione aperta");
                return sb.ToString();
            }

            var lastPos = positions.OrderByDescending(p => p.EntryTime).FirstOrDefault();
            double nextLots = CalculateRecoveryLots(lastPos, RecoveryMultiplier);

            sb.AppendLine($"• Modalità calcolo: {DDCalcType}");
            sb.AppendLine($"• Moltiplicatore base: {RecoveryMultiplier:F2}");
            sb.AppendLine($"• Volume attuale: {Symbol.VolumeInUnitsToQuantity(lastPos.VolumeInUnits):F2} lots");
            sb.AppendLine($"• Prossimo volume: {nextLots:F2} lots");

            double dynamicMinDistance = CalculateDynamicDistanceFilter(MinDistancePips, lastPos, nextLots);
            double dynamicCooldown = CalculateDynamicDistanceFilter(RecoveryCooldownPips, lastPos, nextLots);
            double dynamicBEDistance = CalculateDynamicDistanceFilter(MinDistanceBEpips, lastPos, nextLots);

            sb.AppendLine($"• Distanza minima: {MinDistancePips:F1} → {dynamicMinDistance:F1} pips");
            sb.AppendLine($"• Cooldown: {RecoveryCooldownPips:F1} → {dynamicCooldown:F1} pips");
            sb.AppendLine($"• Distanza BE: {MinDistanceBEpips:F1} → {dynamicBEDistance:F1} pips");

            return sb.ToString();
        }

        // Example usage of maxProfitAfterTrigger
        private void UpdateMaxProfitAfterTrigger(double currentProfit)
        {
            if (currentProfit > maxProfitAfterTrigger)
            {
                maxProfitAfterTrigger = currentProfit;
                Print($"🔄 maxProfitAfterTrigger aggiornato: {maxProfitAfterTrigger}");
            }
        }

        // Example usage of the field to avoid CS0414 warning
        private void UpdateTrailingTPLastProfit(double newProfit)
        {
            trailingTPLastProfit = newProfit;
            Print($"Trailing TP Last Profit updated to: {trailingTPLastProfit}");
        }

        // Utilizzo della variabile per evitare l'errore CS0414
        private void UpdateTrailingTPExpectedMin(double newValue)
        {
            trailingTPExpectedMin = newValue;
            Print($"🔄 Aggiornato trailingTPExpectedMin: {trailingTPExpectedMin}");
        }




    }
}